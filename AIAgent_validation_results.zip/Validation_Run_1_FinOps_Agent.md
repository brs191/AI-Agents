# Validation Run 1 — FinOps AI Agent

**Module:** AaraMinds AI Agent Blueprint v0.7 (validated under this run, promoted to v1.0)
**Date:** May 17, 2026
**Prompt:** *Building a FinOps AI Agent — Practical Enterprise Blueprint*
**Verdict:** PASS without rework

---

## 1. Job-to-be-done

Continuously reconcile multi-cloud spend against tagged cost centers, surface anomalies and savings opportunities, and route recommendations to accountable owners — reducing FinOps lead manual review time by at least 60% without taking any automated action against cloud accounts.

## 2. Scope and boundary

In scope:
- Invoice ingestion from AWS, Azure, and GCP billing exports
- Tag-to-cost-center reconciliation against the central tag taxonomy
- Anomaly detection on daily spend using rolling-window statistics
- Reserved-instance and savings-plan recommendations from utilization patterns
- Chargeback report drafting per cost center
- Alert routing to accountable owners via Slack and Teams

Out of scope:
- Contract negotiation and vendor commitment decisions
- Budget approvals and exception handling
- Any write action against cloud accounts

Human-only:
- Final approval on RI/SP commitments
- Exceptions to chargeback policy
- Dispute resolution with finance

## 3. Agent decomposition

Decision: Single-agent.

Rationale: The job is sequential analysis — ingest, reconcile, detect, recommend, route. Each step depends on the prior step's output. The work has no parallel cognitive roles or distinct domains that would justify multi-agent coordination overhead.

Rejected alternative: Two-agent split (Reconciler + Recommender). Rejected because the recommender depends entirely on reconciler output, which would force tight coupling via inter-agent state-passing. LangGraph nodes give the same separation of concerns with simpler state semantics.

Capabilities:
- **Invoice parsing** — Normalize AWS CUR, Azure EA billing, and GCP billing-export rows into a unified schema
- **Tag reconciliation** — Map invoice line items to cost centers using the central tag taxonomy; flag untagged spend by service and owner
- **Anomaly detection** — Apply 30-day rolling-window statistics to identify spend deviations beyond configurable z-score thresholds
- **RI/SP recommendation** — Generate purchase recommendations from 90-day utilization patterns with break-even analysis
- **Chargeback drafting** — Produce per-cost-center narrative reports with line-item attribution
- **Owner routing** — Lookup accountable owner from ServiceNow CMDB and deliver alerts via channel

## 4. Foundation and tool stack

Foundation:
- **Claude** — workhorse for anomaly narrative generation and RI/SP rationale; chosen for structured reasoning over financial context
- **Haiku** — high-volume classification (tag normalization, anomaly category labeling); chosen for cost efficiency at scale
- **pgvector** — similarity search over historical anomaly patterns; chosen because Postgres is the org standard and anomaly volume fits comfortably
- **Azure SQL** — invoice and tag-state storage with row-level security
- **Azure Data Lake Storage Gen2** — raw billing export retention for 7 years (SOX audit requirement)
- **Microsoft Entra ID** — identity and RBAC
- **Azure Key Vault** — cloud-provider API credentials and signing keys

Stack:
- **LangGraph** — sequential workflow orchestration with retry on data fetch failures; chosen for native HITL gates
- **Apache Airflow on AKS** — nightly batch orchestration; chosen because finance data is inherently batch and Airflow is the org's data-pipeline standard
- **MCP servers** — AWS Cost Explorer (RO), Azure Cost Management (RO), GCP Billing (RO), ServiceNow (RO), Slack/Teams (channel-scoped write)
- **Braintrust** — eval platform with native GitHub Action for CI gates
- **LangSmith** — execution tracing
- **Application Insights** — operational metrics and the agent's own cost telemetry
- **Power BI** — FinOps dashboard surfaced to finance stakeholders

## 5. Cross-cutting concerns

Pattern: Defense-in-depth with seven concurrent control layers, plus deterministic-math-where-it-matters as a discipline.

Controls:
- **Input validation** — Each cloud's billing schema validated on ingest; non-conforming rows quarantined with alert to platform team
- **Output validation** — Every recommendation must carry cost-center attribution, confidence score, supporting evidence trace, and reproducible computation
- **Tool-call allowlist** — Cloud APIs read-only forever; ServiceNow read-only; Slack/Teams scoped to specific FinOps channels
- **PII handling** — Usernames in audit logs hashed; account IDs partially masked in cross-team reports
- **Audit** — Immutable log in Azure Storage with WORM policy; finance audit trail satisfies SOX requirements
- **Observability** — Per-request LangSmith trace, App Insights metrics, the agent's own monthly cost tracked against a $1,500 budget
- **Human-in-loop** — Any anomaly with projected monthly impact over $10K and any RI/SP recommendation requires FinOps lead approval before alert delivery
- **Deterministic math** — Dollar calculations performed by Python, never by LLM; LLM is used only for narrative explanation of computed numbers

## 6. Evaluation and feedback loop

Golden set: 100 cases — 50 historical anomalies with known root cause, 30 RI/SP cases with known optimal outcome, 20 chargeback reports validated by finance. Refreshed quarterly with rejection cases from production.

Scorers:
- **Anomaly precision and recall** — LLM-as-judge against documented root cause, plus rule-based ground truth
- **RI/SP savings accuracy** — Measured against realized 90-day savings post-deployment
- **Chargeback completeness** — Schema validation plus LLM-as-judge on narrative quality

CI gate: Braintrust GitHub Action blocks PR merge on any scorer regression below baseline.

Feedback loop: Every FinOps-lead-rejected recommendation auto-creates an eval case with the rejection reason as structured tags. Quarterly review re-baselines the golden set against new anomaly patterns and policy changes.

## 7. Lifecycle and deployment

- **Plan** (Sprint 1) — Tag taxonomy audit, invoice schema mapping across three clouds, golden set assembly from the last four quarters
- **Build** (Sprints 2–4) — LangGraph workflow, MCP servers for each cloud, anomaly detection logic, deterministic-math layer
- **Test** (Sprint 5) — Golden set validation plus a 30-day shadow run against last quarter's data with side-by-side comparison
- **Deploy** — Azure Container Apps for the LangGraph runtime; Airflow on AKS for batch orchestration
- **Monitor** — App Insights and LangSmith dashboards; daily report on agent decisions vs. FinOps lead overrides during the first quarter
- **Learn** — Monthly eval review; quarterly golden set re-baseline; semi-annual policy alignment review with finance

Hosting: Azure Container Apps plus AKS for Airflow.
Cost ceiling: $1,500/month for the agent itself, with alerts at 80%.
Rollback: container revision rollback restores prior agent behavior within minutes; Airflow DAG version pin allows pipeline rollback independent of agent rollback.

## 8. Principles, anti-patterns, phased rollout

Principles:
- Read-only on cloud APIs forever — the agent never spends money
- Dollar math is deterministic, never inferred from LLM judgment
- Every recommendation traces back to source invoice line items
- Confidence score visible on every output
- Anomaly thresholds are explicit and tunable, never learned-and-hidden
- The FinOps lead owns final accountability for every decision

Anti-patterns:
- **Auto-applying RI/SP purchases** — concentrates blast radius; one wrong recommendation becomes a wrong purchase
- **Aggregating across cost centers to hide ownership** — breaks accountability and confuses chargeback
- **Using LLM judgment for dollar-value math** — silent precision loss is worse than visible failure
- **Treating tag inconsistency as the agent's problem to silently fix** — masks an org-level data hygiene issue that needs human ownership

Phased rollout:
- **v0.1** — Anomaly detection plus chargeback drafting; alerts to FinOps lead only; no owner routing yet
- **v1.0** — Adds RI/SP recommendations and multi-stakeholder routing via ServiceNow owner lookup
- **Out of scope** — Automated purchasing, budget enforcement, contract analysis, vendor management

## 9. Workflow sequence diagram

```mermaid
sequenceDiagram
    autonumber
    participant AF as Airflow (nightly)
    participant LG as LangGraph
    participant AG as FinOps Agent
    participant AWS as AWS Cost MCP
    participant AZ as Azure Cost MCP
    participant GCP as GCP Billing MCP
    participant CALC as Deterministic Math
    participant LLM as Claude
    participant SN as ServiceNow MCP
    participant SL as Slack/Teams MCP
    actor FL as FinOps Lead
    participant EV as Braintrust
    participant LS as LangSmith

    AF->>LG: Trigger nightly run
    LG->>LS: Open trace
    par Fetch billing in parallel
        LG->>AWS: Pull yesterday CUR
        AWS-->>LG: Invoice rows
    and
        LG->>AZ: Pull EA usage
        AZ-->>LG: Invoice rows
    and
        LG->>GCP: Pull billing export
        GCP-->>LG: Invoice rows
    end
    LG->>AG: Reconcile against tag taxonomy
    AG->>CALC: Compute spend deltas (deterministic)
    CALC-->>AG: Numeric deltas
    AG->>AG: Detect anomalies (rolling window)
    AG->>LLM: Draft narrative + categorization
    LLM-->>AG: Drafts with confidence
    AG->>EV: Score against golden criteria
    EV-->>AG: Quality scores
    alt Projected impact > $10K
        AG-->>FL: Surface for approval
        FL-->>AG: Approve / Reject
        alt Rejected
            AG->>EV: Auto-create new eval case
        end
    end
    AG->>SN: Lookup accountable owner
    SN-->>AG: Owner identity
    AG->>SL: Route alert to owner channel
    AG-->>LG: Run complete
    LG->>LS: Close trace
```

## 10. Architecture poster

Reference asset: `/mnt/user-data/outputs/finops_architecture.svg`

Five-zone layout (1600×1000, white enterprise theme):
- **Header** — Title, subtitle, four capability tags (RECONCILE · DETECT · ROUTE · REPORT)
- **Left panel** — Cloud billing sources (AWS CUR, Azure EA, GCP Billing), ownership and routing (ServiceNow CMDB, Slack/Teams), tag taxonomy and policy, Entra ID and security, FinOps lead console
- **Center panel** — LangGraph + Airflow orchestration strip, FinOps Agent box (single-agent, sequential pipeline) with six capability cards, **Deterministic Math Layer callout** between agent and MCP, MCP Gateway + six MCP server boxes
- **Right panel** — Observability and evaluation (eight items including $1,500/mo budget telemetry), Key Capabilities (nine items), Anti-Patterns callout (three explicit ones)
- **Foundation strip** — Security and Compliance, Reliability and Resilience, Scalability and Performance, Data and Storage, Deployment and Runtime
- **Typical flow strip** — Seven pill-shaped stages: Fetch Billing → Reconcile Tags → Detect Anomalies → Compute Recs → Approve > $10K → Route to Owner → Chargeback Report, with dashed teal feedback loop

Semantic color discipline:
- Green = agent / build / security
- Blue = orchestration / Microsoft / API
- Orange = runtime / specialist work
- Purple = MCP / observability
- Teal = HITL / trace sources
- Amber = cost / data / deployment
- Red = anti-patterns

Defining operational discipline: **Deterministic Math Layer** — dollar calculations performed by Python, never by LLM. This callout sits in the horizontal strip between agent and MCP layer, marking the load-bearing principle of this specific agent.

---

## Validation scoring · 22-point Quality Checklist + Base Pre-Flight

| Item | Result | Notes |
|---|---|---|
| 1. JTBD one-sentence, named beneficiary, measurable | ✅ | "60% reduction" measurable; FinOps lead named beneficiary |
| 2. Three labeled scope lists | ✅ | In / Out / Human-only all distinct |
| 3. Decision before Rationale + Rejected alternative | ✅ | Two-agent split explicitly rejected with reason |
| 4. Single vs multi-agent justified | ✅ | Sequential pipeline rationale |
| 5. Capabilities discrete and testable | ✅ | Six bolded capabilities |
| 6. Foundation/Stack distinct with reasons | ✅ | Each item has "chosen for…" |
| 7. Cross-cutting names a pattern | ✅ | "Defense-in-depth + deterministic-math-where-it-matters" |
| 8. Eval has four labels | ✅ | Golden set / Scorers / CI gate / Feedback loop |
| 9. Six lifecycle stages + hosting/cost/rollback | ✅ | All six stages plus the three meta items |
| 10. Principles + anti-patterns specific with reasons | ✅ | Six principles, four anti-patterns each with reason |
| 11. Reads as peer brief | ✅ | Named alternatives, tradeoffs visible |
| 12. Named patterns used | ✅ | Defense-in-depth, deterministic-math, rolling-window |
| 13. Workflow covers happy + alt + HITL + feedback | ✅ | $10K gate + rejection branch + parallel fetch |
| 14. Mermaid syntactically valid | ✅ | par/alt blocks valid |
| 15. Canvas 1600×1000, five-zone layout | ✅ | Header + L/C/R + foundation + flow strip |
| 16. Semantic color palette consistent | ✅ | Per spec, applied across all components |
| 17. Typography hierarchy applied | ✅ | 28/13/11/13/11/10/9pt as specified |
| 18. Visual hierarchy L1-L4 | ✅ | Agent + Gateway primary-shadow; specialists card-shadow |
| 19. Icons inline geometric SVG paths | ✅ | 18 distinct icons drawn inline, consistent style |
| 20. No text below 8.5pt | ✅ | Smallest is 9pt |
| 21. Typical flow strip with feedback loop | ✅ | 7 stages + dashed teal loop |
| 22. Architecture labeled honestly | ✅ | No board-deck claim made |
| **Base Pre-Flight (12-point)** | ✅ All | Clear, practical, grounded, decisive, tradeoffs visible |

**Verdict: PASS without rework.** All 22 checklist items + Base Pre-Flight met.

---

## Distinctive characteristics of this run

- Agent type: **Single-agent, sequential pipeline**
- Defining operational discipline: **Deterministic-math-where-it-matters**
- HITL gate: $10K projected impact threshold
- Cost ceiling: $1,500/month
- SOX audit trail with WORM policy (regulatory constraint surfaced)
- Cloud APIs read-only forever (load-bearing principle)
- Parallel data ingest from three cloud providers (latency optimization without multi-agent complexity)
