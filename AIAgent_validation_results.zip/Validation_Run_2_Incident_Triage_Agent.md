# Validation Run 2 — Incident Triage Agent

**Module:** AaraMinds AI Agent Blueprint v0.7 (validated under this run, promoted to v1.0)
**Date:** May 17, 2026
**Prompt:** *Build an Incident Triage agent that handles alert intake, classifies severity, recommends runbooks, and manages on-call handoff for enterprise ops teams*
**Verdict:** PASS without rework

---

## 1. Job-to-be-done

Convert raw monitoring alerts into severity-classified, runbook-attached, owner-routed incidents within 30 seconds P95 — so on-call engineers spend their cognitive budget on response, not on triage.

## 2. Scope and boundary

In scope:
- Alert ingestion from Datadog, Grafana, and Azure Monitor
- Deduplication and correlation against open incidents within configurable windows
- Severity classification (Sev1 through Sev4)
- Runbook recommendation from the internal runbook library
- On-call lookup and routing via PagerDuty
- Post-incident eval-case generation when on-call overrides agent decisions

Out of scope:
- Executing runbooks (production systems are read-only)
- Public outage declarations
- Post-mortem authorship
- Capacity planning and forecasting

Human-only:
- Declaring Sev1 (agent surfaces candidates; human confirms)
- Paging executive leadership
- Customer communication and status-page updates

## 3. Agent decomposition

Decision: Single-agent.

Rationale: The pipeline is tight — normalize → dedupe → classify → recommend → route — with a hard P95 latency budget of 30 seconds. Each stage depends on the prior. LangGraph nodes provide the separation of concerns; multi-agent coordination overhead would risk the latency budget.

Rejected alternative: Three-specialist multi-agent (Classifier + Runbook Recommender + Router). Rejected because inter-agent messaging adds non-trivial latency on a sub-second-sensitive path, the cognitive work isn't truly independent across stages, and the operational complexity of monitoring three agents would exceed the value.

Capabilities:
- **Alert normalization** — Map alerts from each monitoring source into a unified incident schema
- **Deduplication** — Match against open incidents within configurable time windows using Redis-backed signature matching
- **Severity classification** — Apply deterministic rules first; defer to LLM judgment only for ambiguous cases
- **Runbook recommendation** — Semantic search over runbook library; surface top-3 candidates with confidence
- **On-call resolution** — Lookup primary and secondary on-call from PagerDuty schedule
- **Routing** — Create PagerDuty incident, page on-call, post to incident channel

## 4. Foundation and tool stack

Foundation:
- **Claude** — workhorse for ambiguous severity reasoning and runbook-match narrative; chosen for nuanced judgment on edge cases where deterministic rules fail
- **Haiku** — high-volume classification for routine alerts matching known patterns; chosen for sub-second latency at scale
- **pgvector** — semantic search over runbook library and historical incidents; chosen for Postgres standardization
- **Azure SQL** — incident state and audit trail
- **Redis** — deduplication windows with TTL; chosen because the access pattern is millisecond key lookup at high throughput
- **Microsoft Entra ID** — identity and RBAC
- **Azure Key Vault** — monitoring-tool API credentials

Stack:
- **LangGraph** — pipeline orchestration with strict latency budget enforcement; chosen for native HITL gates on Sev1
- **MCP servers** — Datadog (RO), Grafana (RO), Azure Monitor (RO), PagerDuty (incident write only), ServiceNow (CMDB RO, incident write), Confluence (runbook RO)
- **Braintrust** — eval platform with CI gate; chosen for trajectory-level scoring on multi-step triage
- **LangSmith** — execution tracing with latency SLO alerts on the agent's own behavior
- **Application Insights** — operational metrics
- **Microsoft Teams** — dedicated incident channels per service domain

## 5. Cross-cutting concerns

Pattern: Defense-in-depth with eight control layers, plus latency-as-a-feature as an operational discipline.

Controls:
- **Input validation** — Alert schemas enforced per source; malformed alerts go to dead-letter queue with platform-team alert
- **Output validation** — Every routed incident must carry severity rationale, runbook ID, on-call identity, and confidence score
- **Tool-call allowlist** — Production monitoring read-only; PagerDuty write scoped to incident namespace; ServiceNow CMDB read-only; Confluence runbook fetch read-only; no tool can act on the systems being monitored
- **PII handling** — Customer identifiers masked in non-secure channels (Teams); full identifiers retained only in secure incident records
- **Audit** — Immutable log of every triage decision with full reasoning trace
- **Observability** — Per-request LangSmith trace with latency SLO alerts; App Insights metrics; the agent's own performance treated as an SLO
- **Cost telemetry** — Tracked per alert routed, monthly against budget
- **Human-in-loop** — Any Sev1 candidate requires on-call confirmation before paging executives; any runbook recommendation below confidence threshold (default 0.7) is surfaced as "ambiguous — engineer must select" rather than auto-attached

## 6. Evaluation and feedback loop

Golden set: 200 historical alerts from the last 12 months, labeled with correct severity, correct runbook, and correct on-call routing. Sampled to over-represent rare Sev1 patterns relative to natural frequency. Refreshed monthly with new alert patterns.

Scorers:
- **Severity classification accuracy** — Exact match on Sev1/Sev2 (high-stakes); ±1 tolerance acceptable on Sev3/Sev4
- **Runbook precision** — Precision@1 and Precision@3 against the human-labeled correct runbook
- **Routing accuracy** — Correct on-call engineer identified

CI gate: Braintrust GitHub Action blocks PR merge on regression in any scorer; Sev1 accuracy regression below threshold is a hard block, not a warning.

Feedback loop: Every incident where the on-call engineer changed severity or selected a different runbook auto-creates an eval case. Weekly review of false positives and false negatives during the first quarter. Monthly golden set additions from new alert patterns.

## 7. Lifecycle and deployment

- **Plan** (Sprint 1) — Alert source inventory, runbook library audit, golden set assembly from incident history
- **Build** (Sprints 2–3) — LangGraph pipeline, MCP servers, severity rules engine, runbook semantic index
- **Test** (Sprint 4) — Golden set validation plus 14-day shadow run alongside existing manual triage; latency budget validation under peak load
- **Deploy** — Azure Container Apps with autoscaling tuned for alert burst patterns
- **Monitor** — App Insights and LangSmith dashboards; daily report on agent decisions vs. on-call overrides; weekly latency SLO review
- **Learn** — Weekly eval review during first quarter; biweekly thereafter; golden set additions from any incident where the agent was overridden

Hosting: Azure Container Apps with autoscaling.
Cost ceiling: $800/month with alerts at 80%.
P95 latency budget: 30 seconds end-to-end, monitored as a Tier-1 SLO.
Rollback: container revision rollback; feature flag to disable the agent entirely and revert to manual triage in under one minute.

## 8. Principles, anti-patterns, phased rollout

Principles:
- Read-only on monitored systems forever — the agent never acts on production
- Latency is a feature, not a tradeoff — the 30-second budget is load-bearing
- Confidence threshold is explicit and tunable per severity tier
- On-call engineer always has override authority with one click
- Every agent decision carries a full reasoning trace
- Runbook recommendations cite source documents, never fabricate

Anti-patterns:
- **Auto-declaring Sev1 without human confirmation** — Sev1 has executive paging consequences; never automate the escalation
- **Aggressive dedup that merges distinct incidents** — silent loss of signal; better to surface a false duplicate than to merge real incidents
- **Learning severity thresholds from history without explicit recalibration** — concept drift hides as accuracy improvement until a major incident is misclassified
- **Recommending runbooks without surfacing alternatives** — single-recommendation tunnel vision is a known failure mode in operator decision-making

Phased rollout:
- **v0.1** — Sev3 and Sev4 only with engineer-confirmed severity (training-wheels mode); runbook recommendations as suggestions, not auto-attached
- **v1.0** — Full severity range with confidence-gated auto-routing; auto-attached runbooks above confidence threshold
- **Out of scope** — Auto-remediation, post-mortem authorship, capacity planning, status-page updates

## 9. Workflow sequence diagram

```mermaid
sequenceDiagram
    autonumber
    participant MON as Monitoring (DD/Graf/AzMon)
    participant LG as LangGraph
    participant DD as Dedup (Redis)
    participant AG as Triage Agent
    participant LLM as Claude/Haiku
    participant CF as Confluence MCP
    participant PD as PagerDuty MCP
    participant TM as Teams MCP
    actor OC as On-Call Engineer
    participant EV as Braintrust
    participant LS as LangSmith

    MON->>LG: Alert payload
    LG->>LS: Open trace (SLO timer start)
    LG->>DD: Check dedup window
    alt Duplicate
        DD-->>LG: Open incident exists
        LG-->>MON: Attach to existing, end
    else New incident
        DD-->>LG: No match
        LG->>AG: Normalize + classify
        AG->>LLM: Severity (if ambiguous)
        LLM-->>AG: Severity + rationale + confidence
        AG->>CF: Semantic search runbook
        CF-->>AG: Top-3 candidates
        AG->>LLM: Pick best runbook with reasoning
        LLM-->>AG: Selected runbook + confidence
        alt Confidence below threshold
            AG-->>TM: Post as "ambiguous — engineer to select"
        else Confidence acceptable
            AG->>PD: Resolve on-call
            PD-->>AG: On-call identity
            alt Sev1 candidate
                AG-->>OC: Request confirmation before exec page
                OC-->>AG: Confirm or downgrade
            end
            AG->>PD: Create incident + page
            AG->>TM: Post to incident channel
        end
        AG->>EV: Score this routing decision
        AG-->>LG: Complete
        LG->>LS: Close trace
        alt OC overrides severity or runbook
            OC->>EV: Auto-create eval case (feedback loop)
        end
    end
```

## 10. Architecture poster

Reference asset: `/mnt/user-data/outputs/incident_triage_architecture.svg`

Five-zone layout (1600×1000, white enterprise theme):
- **Header** — Title, subtitle, four capability tags (NORMALIZE · CLASSIFY · RECOMMEND · ROUTE)
- **Left panel** — Monitoring platforms (Datadog, Grafana, Azure Monitor), on-call and routing (PagerDuty, MS Teams), runbook library (Confluence, ServiceNow CMDB), Entra ID and security, on-call engineer console
- **Center panel** — LangGraph Orchestrator with **P95 SLO 30s tag**, Triage Agent box (single-agent, sequential pipeline) with six capability cards, **Latency-as-a-Feature callout** (red) between agent and MCP, MCP Gateway + six MCP server boxes
- **Right panel** — Observability and evaluation (eight items including latency SLO alerts and Sev1 false-positive Tier-1 metric), Key Capabilities (nine items), Anti-Patterns callout (three explicit ones)
- **Foundation strip** — Security and Compliance, Reliability and Resilience, Scalability and Performance, Data and Storage, Deployment and Runtime
- **Typical flow strip** — Seven pill-shaped stages: Alert Arrives → Dedup Window → Classify Severity → Recommend Runbook → Sev1 Confirm → Page + Channel → Score + Trace, with dashed teal feedback loop

Semantic color discipline (extended palette to communicate severity):
- Green = agent / build / security
- Blue = orchestration / Microsoft / API
- Orange = alerts / monitoring sources
- Purple = MCP / observability
- Teal = HITL / on-call
- Amber = data / deployment
- **Red = Sev1 / urgency / anti-patterns** (used semantically for the latency callout and Sev1 confirmation gate)

Defining operational discipline: **Latency-as-a-Feature** — pipeline budget is load-bearing, rules-first classification keeps median sub-second, LLM defer only on ambiguity. This callout sits in the horizontal strip between agent and MCP layer.

---

## Validation scoring · 22-point Quality Checklist + Base Pre-Flight

| Item | Result | Notes |
|---|---|---|
| 1. JTBD one-sentence, named beneficiary, measurable | ✅ | "30 seconds P95" measurable; on-call engineers named beneficiary |
| 2. Three labeled scope lists | ✅ | In / Out / Human-only distinct |
| 3. Decision before Rationale + Rejected alternative | ✅ | Three-specialist alternative rejected with latency reasoning |
| 4. Single vs multi-agent justified | ✅ | Latency budget anchors the single-agent decision |
| 5. Capabilities discrete and testable | ✅ | Six bolded capabilities |
| 6. Foundation/Stack distinct with reasons | ✅ | "chosen for…" on every item |
| 7. Cross-cutting names a pattern | ✅ | "Defense-in-depth + latency-as-a-feature" |
| 8. Eval has four labels | ✅ | Golden set / Scorers / CI gate / Feedback loop |
| 9. Six lifecycle stages + hosting/cost/rollback | ✅ | All six + hosting + $800/mo + feature flag rollback |
| 10. Principles + anti-patterns specific with reasons | ✅ | Six principles, four anti-patterns each with reason |
| 11. Reads as peer brief | ✅ | Decision-first, tradeoffs visible, named alternatives |
| 12. Named patterns used | ✅ | Defense-in-depth, latency-as-a-feature, rules-first |
| 13. Workflow covers happy + alt + HITL + feedback | ✅ | Duplicate / new / ambiguous / Sev1 branches + override loop |
| 14. Mermaid syntactically valid | ✅ | Nested alt blocks valid |
| 15. Canvas 1600×1000, five-zone layout | ✅ | Header + L/C/R + foundation + flow strip |
| 16. Semantic color palette consistent | ✅ | Red used consistently for Sev1 / urgency / anti-patterns |
| 17. Typography hierarchy applied | ✅ | 28/13/11/13/11/10/9 per spec |
| 18. Visual hierarchy L1-L4 | ✅ | Agent + Gateway primary-shadow; specialists card-shadow |
| 19. Icons inline geometric SVG paths | ✅ | 18 icons consistent style, additions: ic-bell, ic-book, ic-cache |
| 20. No text below 8.5pt | ✅ | Smallest is 9pt |
| 21. Typical flow strip with feedback loop | ✅ | 7 stages + dashed teal loop with on-call override semantics |
| 22. Architecture labeled honestly | ✅ | No board-deck claim made |
| **Base Pre-Flight (12-point)** | ✅ All | Clear, practical, grounded, decisive |

**Verdict: PASS without rework.** All 22 checklist items + Base Pre-Flight met.

---

## Distinctive characteristics of this run

- Agent type: **Single-agent, sequential pipeline** (different rationale than FinOps — latency-driven rather than data-flow-driven)
- Defining operational discipline: **Latency-as-a-feature** (P95 30s SLO is load-bearing)
- HITL gate: Sev1 confirmation before executive paging
- Cost ceiling: $800/month
- Rollback: one-minute feature-flag disable to manual triage (faster than FinOps' container revision rollback because incident response cannot wait)
- Rules-first classification with LLM fallback (latency optimization through tiered cognitive cost)
- Three-specialist multi-agent alternative explicitly rejected to preserve latency budget
- Architecture poster introduces red semantic color for Sev1 / urgency, demonstrating palette extensibility
