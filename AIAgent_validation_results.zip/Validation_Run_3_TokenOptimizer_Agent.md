# Validation Run 3 — TokenOptimizer Agent

**Module:** AaraMinds AI Agent Blueprint v0.7 (validated under this run, promoted to v1.0)
**Date:** May 17, 2026
**Prompt:** *Build a TokenOptimizer agent that reduces unnecessary token usage across prompts, context, memory, RAG results, tool outputs, and multi-agent communication while preserving accuracy and intent*
**Verdict:** PASS without rework

---

## 1. Job-to-be-done

Analyze production LLM traces and surface ranked, owner-routed token-reduction recommendations across six waste domains — reducing aggregate token spend by at least 20% over a rolling 90-day window without measurable accuracy regression on the golden set.

## 2. Scope and boundary

In scope:
- Trace ingestion from LangSmith and Langfuse for the prior seven days on a nightly cycle
- Analysis across six token-waste domains: prompts, context, memory, RAG results, tool outputs, inter-agent messages
- Recommendation drafting with quantified estimated savings and accuracy-risk assessment
- Draft pull request generation to the relevant repository
- Owner notification and review queue management
- Self-measurement against a 60-day self-funding requirement

Out of scope:
- Direct modification of production code or configurations
- Per-request runtime optimization (this is offline analysis)
- Model selection or routing decisions
- Prompt engineering for net-new features

Human-only:
- Merging draft PRs (the agent never merges)
- Overriding accuracy regression alerts
- Pausing or unpausing the optimizer itself

## 3. Agent decomposition

Decision: Multi-agent (orchestrator-specialist with six specialists).

Rationale: The six waste domains have genuinely distinct cognitive work — prompt analysis is text-pattern recognition, RAG analysis is retrieval-quality reasoning, inter-agent compression is schema design. Each domain has its own expert evaluation criteria and its own failure modes. Decomposing into specialists allows independent scoring against each domain's golden subset and avoids the prompt-bloat that a single-agent doing all six would require.

Rejected alternative: Single-agent with six prompted sub-tasks. Rejected because (a) the single prompt would itself become a token-waste anti-example, (b) per-domain evaluation would be tangled in scorer output, and (c) parallel execution of specialists is straightforward in multi-agent but awkward in single-agent.

Specialists:
- **Prompt Analyzer** — Identifies redundancy, verbose system prompts, and few-shot repetition in trace prompt payloads
- **Context Pruner** — Detects unused context-window items where prior turns or injected content don't influence outputs
- **Memory Compressor** — Flags unsummarized memory growth and long-running entries that would benefit from TTL or summarization
- **RAG Optimizer** — Recommends chunk re-ranking, retrieval pruning, and chunk-size tuning based on retrieved-but-unused patterns
- **Tool Output Truncator** — Identifies tool responses where only a fraction of returned tokens are consumed downstream
- **Inter-Agent Compressor** — Spots message payload bloat in multi-agent workflows where schema-based compression would preserve information

Plus orchestration roles:
- **Planner** — Ingests traces, routes to specialists, coordinates fan-out
- **Reviewer** — Aggregates findings, deduplicates cross-domain recommendations, ranks by impact-to-risk ratio, scores against golden set

## 4. Foundation and tool stack

Foundation:
- **Claude** — workhorse for nuanced analysis where pattern recognition requires reasoning over intent (Prompt Analyzer, Context Pruner, RAG Optimizer); chosen for its handling of long traces and structured reasoning
- **Haiku** — high-volume scanning for surface-level patterns (Tool Output Truncator, Inter-Agent Compressor); chosen for cost efficiency on bulk trace scanning
- **pgvector** — similarity search over historical recommendation patterns to avoid re-recommending things owners have rejected; chosen for Postgres standardization
- **Postgres** — recommendation history, owner feedback, scoring outcomes
- **Redis** — short-term agent state and run-coordination cache
- **Azure Data Lake Storage Gen2** — sampled trace retention with PII redaction
- **Microsoft Entra ID** — identity and RBAC
- **Azure Key Vault** — trace platform API credentials and GitHub PAT for draft PR creation

Stack:
- **LangGraph** — multi-agent orchestration with fan-out / fan-in semantics; chosen for native state coordination across parallel specialists
- **MCP servers** — LangSmith (RO), Langfuse (RO), Braintrust (eval correlation), GitHub (draft PR only), Slack (owner channel write), OpenAPI Connector (extensible REST)
- **Braintrust** — eval platform with native CI gate; chosen for trajectory-level scoring on multi-step optimizer behavior
- **LangSmith** — execution tracing of the optimizer itself (the optimizer is observed by the same tooling it optimizes)
- **Application Insights** — operational metrics and the agent's own cost telemetry
- **Power BI** — savings dashboard surfaced to finance and engineering leadership

## 5. Cross-cutting concerns

Pattern: Defense-in-depth with seven concurrent control layers, plus self-funding-economic-discipline as a load-bearing operational constraint.

Controls:
- **Input validation** — Every trace payload validated against expected schema per source; malformed traces quarantined with platform-team alert
- **Output validation** — Every recommendation must carry trace ID, estimated savings, accuracy-risk score, suggested implementation, and golden-set impact projection
- **Tool-call allowlist** — Trace platforms read-only forever; GitHub scoped to draft-PR-only on allowlisted repos; Slack scoped to owner channels; no tool can modify production code paths
- **PII handling** — Trace contents PII-redacted via deterministic rules before any LLM call; full traces retained in WORM storage with retention policy
- **Audit** — Immutable log of every recommendation and every owner decision with full reasoning trace
- **Observability** — Per-request LangSmith trace, App Insights metrics, the optimizer's own monthly cost tracked against a $500 budget
- **Human-in-loop** — All recommendations are draft PRs; humans merge or reject; recommendations above a defined accuracy-risk threshold require senior engineer review before draft PR is even generated
- **Economic discipline** — Self-funding check runs daily: agent's own cost vs. measured production savings; auto-pause if not net positive after 60 days; quarterly justification report

## 6. Evaluation and feedback loop

Golden set: 80 cases — 50 historical optimization patterns with known good/bad outcomes from prior manual reviews, 20 accuracy-preservation trap cases where naive optimization would break correctness, 10 negative cases where no optimization is the correct answer. Refreshed monthly with new patterns from production overrides.

Scorers:
- **Recommendation precision** — Owner-accepted recommendations as a fraction of total recommendations (Tier-1 metric)
- **Estimated-vs-actual savings ratio** — Measured 30 days post-merge against the optimizer's pre-merge estimate (calibration metric)
- **Accuracy preservation** — Golden-set accuracy delta between pre-optimization and post-optimization on the same trace patterns (must be ≥ 0 or recommendation is rejected)
- **Trap-case avoidance** — Did the agent correctly refuse to recommend on the 20 trap cases?

CI gate: Braintrust GitHub Action blocks PR merge on regression in any scorer; trap-case avoidance below 100% is a hard block.

Feedback loop: Every owner-rejected recommendation auto-creates an eval case tagged with the rejection reason. Every merged recommendation creates a 30-day post-merge measurement that becomes a training signal for the savings-calibration scorer. Quarterly golden set re-baseline against new pattern types.

## 7. Lifecycle and deployment

- **Plan** (Sprint 1) — Trace platform schema mapping, golden set assembly from prior manual optimization reviews, baseline production token spend by domain
- **Build** (Sprints 2–4) — LangGraph orchestrator, six specialists, MCP servers, Reviewer aggregation logic, draft-PR generator
- **Test** (Sprint 5) — Golden set validation, 14-day shadow run alongside manual review, accuracy-regression validation on top-100 production patterns
- **Deploy** — Azure Container Apps for the LangGraph runtime; nightly trigger via Logic Apps
- **Monitor** — App Insights and LangSmith dashboards; daily report on recommendation accept-rate during the first quarter; weekly self-funding ledger update
- **Learn** — Monthly eval review; quarterly golden set re-baseline; semi-annual scope review (are the six domains still the right six?)

Hosting: Azure Container Apps.
Cost ceiling: $500/month with alerts at 70% (tighter than other agents because self-funding requires it).
Rollback: container revision rollback restores prior agent behavior within minutes; feature flag disables the optimizer entirely while preserving trace ingestion for audit continuity.

## 8. Principles, anti-patterns, phased rollout

Principles:
- Read-only on trace platforms forever — the optimizer never modifies its own observation surface
- Recommendations are drafts, never auto-merges — humans always retain merge authority
- Accuracy delta is measured, not assumed — every recommendation has a pre-merge accuracy projection
- The optimizer measures itself — its own cost and savings are tracked as a Tier-1 metric
- Self-funding is enforced — if the agent doesn't earn its keep, it auto-pauses
- Estimated savings carry uncertainty bands, never point estimates

Anti-patterns:
- **Auto-merging draft PRs above a confidence threshold** — even a 99% accurate optimizer would silently break correctness on the 1%; the human merge gate is load-bearing
- **Optimizing the optimizer's own prompts using itself** — recursive bootstrapping introduces measurement contamination and is forbidden during the first six months
- **Recommending optimizations without trace citations** — unsourced recommendations cannot be audited and cannot generate trap cases when wrong
- **Treating accuracy regression as a tunable parameter** — accuracy preservation is the constraint, not the objective; ≥ 0 delta is a hard floor

Phased rollout:
- **v0.1** — Prompt Analyzer and Tool Output Truncator only (the two highest-precision domains); recommendations to Slack only, no draft PRs yet
- **v1.0** — Full six specialists with draft PRs to allowlisted repos; self-funding ledger active
- **Out of scope** — Auto-merge, runtime optimization, model routing, agent prompt-engineering for net-new features

## 9. Workflow sequence diagram

```mermaid
sequenceDiagram
    autonumber
    participant SC as Scheduler (nightly)
    participant LG as LangGraph
    participant PL as Planner Agent
    participant S1 as Prompt Analyzer
    participant S2 as Context Pruner
    participant S3 as Memory Compressor
    participant S4 as RAG Optimizer
    participant S5 as Tool Truncator
    participant S6 as Inter-Agent Compressor
    participant RV as Reviewer Agent
    participant LS as LangSmith MCP
    participant LF as Langfuse MCP
    participant GH as GitHub MCP
    participant SL as Slack MCP
    actor OW as Owner
    participant EV as Braintrust
    participant SF as Self-Funding Ledger

    SC->>LG: Trigger nightly run
    LG->>PL: Ingest last 7 days of traces
    par Parallel trace fetch
        PL->>LS: Pull LangSmith traces
        LS-->>PL: Traces (PII-redacted)
    and
        PL->>LF: Pull Langfuse traces
        LF-->>PL: Traces (PII-redacted)
    end
    par Fan-out to specialists
        PL->>S1: Domain slice (prompts)
        S1-->>PL: Findings + confidence
    and
        PL->>S2: Domain slice (context)
        S2-->>PL: Findings + confidence
    and
        PL->>S3: Domain slice (memory)
        S3-->>PL: Findings + confidence
    and
        PL->>S4: Domain slice (RAG)
        S4-->>PL: Findings + confidence
    and
        PL->>S5: Domain slice (tool outputs)
        S5-->>PL: Findings + confidence
    and
        PL->>S6: Domain slice (inter-agent)
        S6-->>PL: Findings + confidence
    end
    PL->>RV: Aggregate all findings
    RV->>RV: Deduplicate cross-domain
    RV->>RV: Rank by impact/risk
    RV->>EV: Score against golden set + trap cases
    EV-->>RV: Scores + trap-case avoidance result
    alt Trap case triggered or accuracy delta < 0
        RV->>SL: Alert engineers · do NOT generate PR
    else Accuracy preserved
        alt Risk above senior-review threshold
            RV-->>OW: Surface for senior engineer review
            OW-->>RV: Approve / Reject
        end
        alt Approved or below threshold
            RV->>GH: Create draft PR
            GH-->>RV: PR URL
            RV->>SL: Notify owner channel with PR + savings estimate
            OW->>GH: Review · Merge or Reject
            alt Rejected
                OW->>EV: Auto-create eval case with rejection reason
            else Merged
                GH->>EV: Schedule 30-day post-merge measurement
            end
        end
    end
    RV->>SF: Update self-funding ledger
    alt Net negative > 60 days
        SF->>SL: Auto-pause optimizer + alert
    end
```

## 10. Architecture poster

Reference asset: `/mnt/user-data/outputs/tokenoptimizer_final_architecture.svg`

Five-zone layout (1600×1000, white enterprise theme):
- **Header** — Title, subtitle, four capability tags (ANALYZE · RECOMMEND · REVIEW · DEPLOY)
- **Left panel** — LLM trace platforms (LangSmith, Langfuse), PR delivery and routing (GitHub, Slack), eval and recommendation history (Braintrust, pgvector), Entra ID and security, owner review interface
- **Center panel** — LangGraph Orchestrator with **DURABLE tag**, AI Agent Layer (multi-agent, orchestrator-specialist) with green-bordered Planner on left, six orange-bordered specialists in 3×2 grid in the middle, purple-bordered Reviewer on right; fan-out arrows (green→orange) and fan-in arrows (orange→purple) visible; **Self-Funding Economic Discipline callout** between agent and MCP, MCP Gateway + six MCP server boxes
- **Right panel** — Observability and evaluation (nine items including trap cases and accuracy delta ≥ 0 hard floor), Key Capabilities (nine items), Anti-Patterns callout (three explicit ones)
- **Foundation strip** — Security and Compliance, Reliability and Resilience, Scalability and Performance, Data and Storage, Deployment and Runtime
- **Typical flow strip** — Seven pill-shaped stages: Ingest Traces → Plan + Fan-out → Analyze 6 Domains → Rank + Score → Owner Review → Draft PR → Measure 30-Day, with dashed teal feedback loop carrying three feedback semantics (rejections → eval cases · merges → savings calibration · net-negative → auto-pause)

Semantic color discipline:
- **Rose / dark crimson = multi-agent indicator** (the agent layer header is rose-bordered, signaling multi-agent vs the green-bordered single-agent layers in FinOps and Incident Triage)
- Green = Planner / orchestrator role within multi-agent
- Orange = specialist work
- Purple = Reviewer / MCP / observability
- Teal = HITL / trace sources
- Amber = self-funding / cost / deployment
- Red = anti-patterns

Defining operational discipline: **Self-Funding Economic Discipline** — optimizer's own cost vs. measured production savings tracked as Tier-1 metric, auto-pause if net negative > 60 days, $500/mo ceiling enforces the discipline. This callout sits in the horizontal strip between agent and MCP layer.

---

## Validation scoring · 22-point Quality Checklist + Base Pre-Flight

| Item | Result | Notes |
|---|---|---|
| 1. JTBD one-sentence, named beneficiary, measurable | ✅ | "20% reduction over 90 days" measurable; production token spend named |
| 2. Three labeled scope lists | ✅ | In / Out / Human-only distinct |
| 3. Decision before Rationale + Rejected alternative | ✅ | Single-agent with sub-prompts explicitly rejected with three reasons |
| 4. Single vs multi-agent justified | ✅ | Six genuinely distinct cognitive domains justify multi-agent |
| 5. Capabilities discrete and testable | ✅ | Six specialists + Planner + Reviewer, each scoped |
| 6. Foundation/Stack distinct with reasons | ✅ | "chosen for…" on every item; Claude vs Haiku split rationale |
| 7. Cross-cutting names a pattern | ✅ | "Defense-in-depth + self-funding-economic-discipline" |
| 8. Eval has four labels | ✅ | Golden set / Scorers / CI gate / Feedback loop |
| 9. Six lifecycle stages + hosting/cost/rollback | ✅ | All six + $500/mo + feature-flag rollback |
| 10. Principles + anti-patterns specific with reasons | ✅ | Six principles, four anti-patterns each with reason |
| 11. Reads as peer brief | ✅ | Decisions first, tradeoffs explicit, "the optimizer measures itself" |
| 12. Named patterns used | ✅ | Orchestrator-specialist, fan-out/fan-in, self-funding |
| 13. Workflow covers happy + alt + HITL + feedback | ✅ | Parallel ingest + parallel fan-out + trap-case alt + senior review + auto-pause |
| 14. Mermaid syntactically valid | ✅ | Nested par/alt blocks valid |
| 15. Canvas 1600×1000, five-zone layout | ✅ | Header + L/C/R + foundation + flow strip |
| 16. Semantic color palette consistent | ✅ | Rose introduced for multi-agent indicator, used consistently |
| 17. Typography hierarchy applied | ✅ | 28/13/11/13/11/10/9/8.5pt as specified |
| 18. Visual hierarchy L1-L4 | ✅ | Agent Layer primary-shadow; Planner/Reviewer thick border; specialists card-shadow |
| 19. Icons inline geometric SVG paths | ✅ | 18 icons consistent geometric style |
| 20. No text below 8.5pt | ✅ | Smallest is 8.5pt in specialist sub-labels |
| 21. Typical flow strip with feedback loop | ✅ | 7 stages + dashed teal loop with three feedback semantics |
| 22. Architecture labeled honestly | ✅ | No board-deck claim made |
| **Base Pre-Flight (12-point)** | ✅ All | Clear, practical, grounded, decisive |

**Verdict: PASS without rework.** All 22 checklist items + Base Pre-Flight met.

---

## Distinctive characteristics of this run

- Agent type: **Multi-agent, orchestrator-specialist with fan-out / fan-in** (first multi-agent run in the validation set; tests the module's handling of more complex decomposition)
- Defining operational discipline: **Self-funding economic discipline** (the optimizer must earn its keep; auto-pause if it doesn't)
- HITL gate: All recommendations are draft PRs; humans always merge
- Cost ceiling: $500/month (tightest of the three; self-funding requires it)
- Self-referential observability: the optimizer is observed by the same tooling it optimizes (LangSmith)
- Six specialists genuinely distinct (text-pattern recognition, retrieval-quality reasoning, schema design — different cognitive work, not just different inputs)
- Single-agent alternative explicitly rejected with three reasons (prompt-bloat, scorer tangling, parallel-execution awkwardness)
- Architecture poster introduces **rose / dark crimson** as the semantic color for the multi-agent indicator, distinguishing it visually from single-agent layers in FinOps and Incident Triage
- The "operational discipline callout" slot, which emerged consistently across all three validation runs, is documented in v1.0 of the module as a permanent structural element
