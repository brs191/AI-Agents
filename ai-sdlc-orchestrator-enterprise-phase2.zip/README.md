# AI SDLC Orchestrator - Enterprise Scaffold

Enterprise-oriented scaffold for an AI-driven SDLC orchestration platform.

## What this version adds
- Durable orchestration design with checkpoint-ready structure
- Environment-specific config
- Postgres/Redis-ready architecture stubs
- OTel-friendly observability hooks
- Policy packs and approval gates
- API versioning and health/readiness endpoints
- GitHub Actions with deployment environments and concurrency controls
- Kubernetes and Azure Container Apps starters
- Security, audit, and governance structure
- Better test layout
- Prompts, schemas, adapters, and runbooks

## Architecture principles
- Shared state with resumable workflow execution
- Structured JSON outputs for all LLM-generated artifacts
- Manual/human approval before protected deployments
- Separation of orchestration, policy, integrations, and runtime APIs
- Pluggable adapters for GitHub, Jira, Azure DevOps, ServiceNow
- Config-driven promotion across dev, stage, prod

## Quick start
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn api.main:app --reload
```

## Local run
```bash
curl -X POST http://127.0.0.1:8000/api/v1/runs \
  -H "Content-Type: application/json" \
  -d '{
    "project_name":"enterprise-finops-agent",
    "goal":"Build and govern a cloud cost optimization service",
    "prd":"Analyze Azure cost, generate backlog, architecture and implementation plan.",
    "constraints":["Azure","PII-safe","GitHub Actions","Enterprise approval gates"],
    "target_env":"dev",
    "business_unit":"platform-engineering"
  }'
```

## Recommended next steps
1. Replace file state store with Postgres + Redis
2. Wire OpenAI API key and real structured outputs
3. Implement GitHub/Jira adapters
4. Add Azure OIDC deployment and Key Vault integration
5. Add policy approvals in GitHub environments / change management

## Repo layout
- `api/` runtime API
- `orchestrator/` graph and nodes
- `services/` llm, policy, scoring, audit, telemetry, adapters
- `shared/` schemas, prompts, config, utilities
- `configs/` environment config
- `policies/` policy packs
- `deploy/` k8s and Azure Container Apps
- `infra/terraform/` cloud infrastructure starter
- `tests/` unit and API tests
- `docs/` architecture, ADR, ops runbooks
