from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional
import uuid

from orchestrator.graph import build_graph
from shared.store import get_state_store
from shared.config import settings

app = FastAPI(title="AI SDLC Orchestrator", version="1.0.0")
graph = build_graph()
store = get_state_store()

class RunRequest(BaseModel):
    project_name: str
    goal: str
    prd: str
    constraints: List[str] = Field(default_factory=list)
    target_env: str = "dev"
    business_unit: str = "default"
    template_id: Optional[str] = None

class ApprovalRequest(BaseModel):
    gate: str

@app.get("/health")
def health():
    return {"status": "ok", "env": settings.service_env}

@app.get("/ready")
def ready():
    return {"status": "ready"}

@app.post("/api/v1/runs")
def create_run(req: RunRequest):
    run_id = f"run_{uuid.uuid4().hex[:12]}"
    state = {
        "request_id": run_id,
        "project_name": req.project_name,
        "goal": req.goal,
        "prd": req.prd,
        "constraints": req.constraints,
        "target_env": req.target_env,
        "business_unit": req.business_unit,
        "template_id": req.template_id,
        "approvals": {"product": False, "architecture": False, "release": False},
        "scores": {},
        "artifacts": {},
        "audit": [],
        "trace": [],
        "status": "started"
    }
    result = graph.invoke(state)
    store.save(run_id, result)
    return {"run_id": run_id, "status": result.get("status", "started"), "result": result}

@app.get("/api/v1/runs/{run_id}")
def get_run(run_id: str):
    state = store.load(run_id)
    if not state:
        raise HTTPException(status_code=404, detail="run not found")
    return state

@app.post("/api/v1/runs/{run_id}/approve")
def approve_run(run_id: str, req: ApprovalRequest):
    state = store.load(run_id)
    if not state:
        raise HTTPException(status_code=404, detail="run not found")
    state.setdefault("approvals", {})[req.gate] = True
    state["next_action"] = ""
    result = graph.invoke(state)
    store.save(run_id, result)
    return {"run_id": run_id, "status": result.get("status", "updated"), "result": result}
