# ADR 001 - Runtime Choice

## Decision
Use LangGraph for orchestrated workflow runtime and FastAPI for service ingress.

## Rationale
- Shared state graph model
- Human approval checkpoints
- Durability-oriented design
- Easy separation of nodes and services
