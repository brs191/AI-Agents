# Enterprise Architecture

## Core components
- FastAPI entrypoint
- LangGraph orchestrator
- OpenAI client for structured artifact generation
- Policy and scoring services
- Audit and telemetry hooks
- Adapter layer for delivery systems
- Config and policy packs
- Deployment workflows and infrastructure

## Enterprise upgrade path
- Replace file state with durable DB-backed state store
- Add real checkpointer and resumable threads
- Add OTel exporter and centralized logs
- Add approval UI / chatops integration
- Add multi-tenant authz and tenancy boundaries
