# Operations Runbook

## Incident: run blocked at approval gate
1. Inspect /api/v1/runs/{run_id}
2. Review `artifacts.policy_evaluation`
3. Approve gate if valid
4. Re-run approval endpoint

## Incident: LLM output invalid
1. Review structured output schema
2. Check prompt template
3. Inspect fallback response path
4. Add stricter schema or retries
