# Security Notes

- Use managed identities / OIDC for cloud deployment
- Store secrets in Key Vault or equivalent
- Protect production workflows with environment approvals
- Protect main branch with required reviews and status checks
- Log audit events for every orchestration step
