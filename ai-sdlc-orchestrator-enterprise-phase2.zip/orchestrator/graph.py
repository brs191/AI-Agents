from langgraph.graph import StateGraph, END
from orchestrator.types import OrchestratorState
from orchestrator.nodes import (
    intake_node,
    requirements_node,
    backlog_node,
    architecture_node,
    policy_node,
    scoring_node,
    approval_gate_node,
    implementation_node,
    release_plan_node,
    finalize_node,
)

def build_graph():
    graph = StateGraph(OrchestratorState)
    graph.add_node("intake", intake_node)
    graph.add_node("requirements", requirements_node)
    graph.add_node("backlog", backlog_node)
    graph.add_node("architecture", architecture_node)
    graph.add_node("policy", policy_node)
    graph.add_node("scoring", scoring_node)
    graph.add_node("approval_gate", approval_gate_node)
    graph.add_node("implementation", implementation_node)
    graph.add_node("release_plan", release_plan_node)
    graph.add_node("finalize", finalize_node)

    graph.set_entry_point("intake")
    graph.add_edge("intake", "requirements")
    graph.add_edge("requirements", "backlog")
    graph.add_edge("backlog", "architecture")
    graph.add_edge("architecture", "policy")
    graph.add_edge("policy", "scoring")
    graph.add_edge("scoring", "approval_gate")

    def route_after_approval(state: OrchestratorState):
        return END if state.get("next_action") == "await_architecture_approval" else "implementation"

    graph.add_conditional_edges(
        "approval_gate",
        route_after_approval,
        {END: END, "implementation": "implementation"},
    )
    graph.add_edge("implementation", "release_plan")
    graph.add_edge("release_plan", "finalize")
    graph.add_edge("finalize", END)
    return graph.compile()
