from orchestrator.types import OrchestratorState
from shared.schemas import validate_artifact
from shared.utils import utc_now
from services.llm.client import generate_requirements, generate_architecture, generate_backlog
from services.policy.engine import compute_scores, evaluate_policy
from services.audit.logger import audit_event

def _trace(state: OrchestratorState, step: str, status: str):
    state.setdefault("trace", []).append({
        "step": step,
        "status": status,
        "timestamp": utc_now()
    })

def intake_node(state: OrchestratorState) -> OrchestratorState:
    state["status"] = "processing"
    audit_event(state, "intake_started", {"project_name": state.get("project_name")})
    _trace(state, "intake", "ok")
    return state

def requirements_node(state: OrchestratorState) -> OrchestratorState:
    artifact = generate_requirements(state["goal"], state["prd"], state.get("constraints", []))
    validate_artifact("requirements", artifact)
    state.setdefault("artifacts", {})["requirements"] = artifact
    audit_event(state, "requirements_generated", {"count": len(artifact.get("user_stories", []))})
    _trace(state, "requirements", "ok")
    return state

def backlog_node(state: OrchestratorState) -> OrchestratorState:
    artifact = generate_backlog(state["goal"], state["prd"], state["artifacts"].get("requirements", {}))
    validate_artifact("backlog", artifact)
    state["artifacts"]["backlog"] = artifact
    audit_event(state, "backlog_generated", {"epics": len(artifact.get("epics", []))})
    _trace(state, "backlog", "ok")
    return state

def architecture_node(state: OrchestratorState) -> OrchestratorState:
    artifact = generate_architecture(state["goal"], state["prd"], state.get("constraints", []))
    validate_artifact("architecture", artifact)
    state["artifacts"]["architecture"] = artifact
    audit_event(state, "architecture_generated", {"services": len(artifact.get("services", []))})
    _trace(state, "architecture", "pending_approval")
    return state

def policy_node(state: OrchestratorState) -> OrchestratorState:
    result = evaluate_policy(state)
    state["artifacts"]["policy_evaluation"] = result
    audit_event(state, "policy_evaluated", {"status": result.get("status")})
    _trace(state, "policy", result.get("status", "ok"))
    return state

def scoring_node(state: OrchestratorState) -> OrchestratorState:
    state["scores"] = compute_scores(state)
    audit_event(state, "scores_computed", state["scores"])
    _trace(state, "scoring", "ok")
    return state

def approval_gate_node(state: OrchestratorState) -> OrchestratorState:
    if not state.get("approvals", {}).get("architecture", False):
        state["next_action"] = "await_architecture_approval"
        state["status"] = "awaiting_approval"
        audit_event(state, "approval_blocked", {"gate": "architecture"})
        _trace(state, "approval_gate", "blocked")
        return state
    audit_event(state, "approval_passed", {"gate": "architecture"})
    _trace(state, "approval_gate", "approved")
    return state

def implementation_node(state: OrchestratorState) -> OrchestratorState:
    state["artifacts"]["implementation_plan"] = {
        "repo_structure": [
            "/api", "/orchestrator", "/services", "/shared", "/configs",
            "/policies", "/infra/terraform", "/deploy/k8s", "/tests"
        ],
        "pipelines": ["ci.yml", "deploy-dev.yml", "deploy-prod.yml"],
        "quality_gates": ["tests", "lint", "security-scan", "approval"],
        "runtime": {"primary": "FastAPI", "workflow": "LangGraph", "llm_api": "OpenAI Responses"}
    }
    audit_event(state, "implementation_planned", {"env": state.get("target_env")})
    _trace(state, "implementation", "ok")
    return state

def release_plan_node(state: OrchestratorState) -> OrchestratorState:
    state["artifacts"]["release_plan"] = {
        "strategy": "promote-dev-stage-prod",
        "controls": ["environment-approval", "branch-protection", "manual-prod-approval"],
        "rollback": "redeploy-previous-image"
    }
    audit_event(state, "release_plan_created", {"strategy": "promote-dev-stage-prod"})
    _trace(state, "release_plan", "ok")
    return state

def finalize_node(state: OrchestratorState) -> OrchestratorState:
    state["status"] = "completed" if state.get("approvals", {}).get("architecture") else state.get("status", "processing")
    audit_event(state, "run_finalized", {"status": state["status"]})
    _trace(state, "finalize", "ok")
    return state
