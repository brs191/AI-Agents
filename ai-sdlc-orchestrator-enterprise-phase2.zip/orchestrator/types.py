from typing import TypedDict, Any

class OrchestratorState(TypedDict, total=False):
    request_id: str
    project_name: str
    goal: str
    prd: str
    constraints: list[str]
    target_env: str
    business_unit: str
    template_id: str | None
    artifacts: dict[str, Any]
    approvals: dict[str, bool]
    scores: dict[str, float]
    audit: list[dict[str, Any]]
    trace: list[dict[str, Any]]
    next_action: str
    status: str
