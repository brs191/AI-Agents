from typing import Any

class AzureDevOpsAdapter:
    def queue_pipeline(self, pipeline_name: str) -> dict[str, Any]:
        return {"status": "stub", "provider": "azure-devops", "action": "queue_pipeline", "pipeline_name": pipeline_name}
