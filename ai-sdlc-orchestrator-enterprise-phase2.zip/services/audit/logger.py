from shared.utils import utc_now

def audit_event(state: dict, event_type: str, payload: dict) -> None:
    state.setdefault("audit", []).append({
        "event_type": event_type,
        "timestamp": utc_now(),
        "payload": payload
    })
