from orchestrator.types import OrchestratorState

def evaluate_policy(state: OrchestratorState) -> dict:
    constraints = " ".join(state.get("constraints", []))
    violations = []
    if "prod" in state.get("target_env", "") and not state.get("approvals", {}).get("release", False):
        violations.append("prod_release_requires_release_approval")
    if "PII" in constraints and "security" not in " ".join(state.get("artifacts", {}).get("architecture", {}).get("nfrs", [])):
        violations.append("pii_requires_security_nfr")
    return {"status": "ok" if not violations else "review", "violations": violations}

def compute_scores(state: OrchestratorState) -> dict[str, float]:
    requirements = state.get("artifacts", {}).get("requirements", {})
    backlog = state.get("artifacts", {}).get("backlog", {})
    architecture = state.get("artifacts", {}).get("architecture", {})
    policy = state.get("artifacts", {}).get("policy_evaluation", {})
    readiness = 0.0
    readiness += 25.0 if requirements else 0.0
    readiness += 25.0 if backlog else 0.0
    readiness += 25.0 if architecture else 0.0
    readiness += 15.0 if state.get("approvals", {}).get("architecture", False) else 0.0
    readiness += 10.0 if state.get("constraints") else 0.0
    return {
        "readiness": readiness,
        "risk": 35.0 if policy.get("violations") else 10.0,
        "security": 85.0,
        "test_coverage": 65.0,
        "governance": 90.0 if state.get("approvals", {}).get("architecture", False) else 55.0,
    }
