def emit_metric(name: str, value: float, dimensions: dict | None = None) -> None:
    # Replace with OpenTelemetry / Azure Monitor integration
    _ = (name, value, dimensions)
