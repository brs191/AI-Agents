import os
from pydantic import BaseModel

class Settings(BaseModel):
    service_env: str = os.getenv("SERVICE_ENV", "dev")
    log_level: str = os.getenv("LOG_LEVEL", "INFO")
    enable_telemetry: bool = os.getenv("ENABLE_TELEMETRY", "false").lower() == "true"
    approval_provider: str = os.getenv("APPROVAL_PROVIDER", "manual")

settings = Settings()
