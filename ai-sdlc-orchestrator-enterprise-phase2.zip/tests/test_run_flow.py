from fastapi.testclient import TestClient
from api.main import app

client = TestClient(app)

def test_create_run():
    payload = {
        "project_name": "demo",
        "goal": "Build an AI SDLC orchestrator",
        "prd": "Create backlog and architecture from a PRD",
        "constraints": ["Azure", "GitHub Actions"],
        "target_env": "dev",
        "business_unit": "platform-engineering"
    }
    response = client.post("/api/v1/runs", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "run_id" in data
    assert "result" in data

def test_approval_endpoint():
    payload = {
        "project_name": "demo",
        "goal": "Build an AI SDLC orchestrator",
        "prd": "Create backlog and architecture from a PRD",
        "constraints": ["Azure"],
        "target_env": "dev",
        "business_unit": "platform-engineering"
    }
    create_resp = client.post("/api/v1/runs", json=payload)
    run_id = create_resp.json()["run_id"]
    approve_resp = client.post(f"/api/v1/runs/{run_id}/approve", json={"gate": "architecture"})
    assert approve_resp.status_code == 200
