# AI SDLC Orchestrator

Production-oriented scaffold for an AI-powered SDLC orchestrator.

## What this repo includes
- FastAPI API service
- LangGraph orchestrator with approval gate flow
- OpenAI client wrapper for structured generation
- GitHub/Jira adapter stubs
- Policy engine and scoring
- JSON schemas for artifacts
- Prompt templates
- Terraform starter
- Docker + docker-compose
- Basic tests
- GitHub Actions CI

## Quick start
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn api.main:app --reload
```

## Example request
```bash
curl -X POST http://127.0.0.1:8000/runs \
  -H "Content-Type: application/json" \
  -d '{
    "project_name":"ai-finops-agent",
    "goal":"Create a cloud cost optimization service",
    "prd":"Build a service that analyzes Azure spend and recommends savings opportunities.",
    "constraints":["Azure","Go services for runtime workloads","GitHub Actions"],
    "target_env":"dev"
  }'
```

## Notes
This is a scaffold: some integrations are implemented as stubs so you can plug in your enterprise systems safely.
