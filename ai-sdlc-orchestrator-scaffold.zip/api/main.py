from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List
import uuid

from orchestrator.graph import build_graph
from shared.store import FileStateStore

app = FastAPI(title="AI SDLC Orchestrator", version="0.1.0")
graph = build_graph()
store = FileStateStore()

class RunRequest(BaseModel):
    project_name: str
    goal: str
    prd: str
    constraints: List[str] = Field(default_factory=list)
    target_env: str = "dev"

class ApprovalRequest(BaseModel):
    gate: str

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/runs")
def create_run(req: RunRequest):
    run_id = f"run_{uuid.uuid4().hex[:10]}"
    state = {
        "request_id": run_id,
        "project_name": req.project_name,
        "goal": req.goal,
        "prd": req.prd,
        "constraints": req.constraints,
        "target_env": req.target_env,
        "approvals": {"product": False, "architecture": False, "release": False},
        "scores": {},
        "artifacts": {},
        "trace": [],
        "status": "started"
    }
    result = graph.invoke(state)
    store.save(run_id, result)
    return {"run_id": run_id, "status": result.get("status", "started"), "result": result}

@app.get("/runs/{run_id}")
def get_run(run_id: str):
    state = store.load(run_id)
    if not state:
        raise HTTPException(status_code=404, detail="run not found")
    return state

@app.post("/runs/{run_id}/approve")
def approve_run(run_id: str, req: ApprovalRequest):
    state = store.load(run_id)
    if not state:
        raise HTTPException(status_code=404, detail="run not found")
    state.setdefault("approvals", {})[req.gate] = True
    state["next_action"] = ""
    result = graph.invoke(state)
    store.save(run_id, result)
    return {"run_id": run_id, "status": result.get("status", "updated"), "result": result}
