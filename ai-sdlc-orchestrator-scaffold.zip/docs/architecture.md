# Architecture

## Components
- API Gateway / FastAPI service
- Orchestrator runtime
- LLM service wrapper
- Policy engine
- Adapter layer
- State store
- CI/CD and deployment workflows

## Flow
1. Intake request
2. Requirements generation
3. Backlog generation
4. Architecture generation
5. Scoring and approval gate
6. Implementation planning
7. Delivery integration
