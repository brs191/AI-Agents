# Roadmap

## Phase 1
- Local execution
- File-based state store
- Manual approval API
- Artifact generation

## Phase 2
- Postgres + Redis
- Real GitHub/Jira integrations
- Prompt versioning
- Human review UI

## Phase 3
- Multi-tenant support
- Enterprise policy packs
- Observability dashboards
- Automated release governance
