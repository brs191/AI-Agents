from orchestrator.types import OrchestratorState
from shared.schemas import validate_artifact
from shared.utils import utc_now
from services.llm.client import generate_requirements, generate_architecture, generate_backlog
from services.policy.engine import compute_scores

def _trace(state: OrchestratorState, step: str, status: str):
    state.setdefault("trace", []).append({
        "step": step,
        "status": status,
        "timestamp": utc_now()
    })

def intake_node(state: OrchestratorState) -> OrchestratorState:
    state["status"] = "processing"
    _trace(state, "intake", "ok")
    return state

def requirements_node(state: OrchestratorState) -> OrchestratorState:
    artifact = generate_requirements(state["goal"], state["prd"], state.get("constraints", []))
    validate_artifact("requirements", artifact)
    state.setdefault("artifacts", {})["requirements"] = artifact
    _trace(state, "requirements", "ok")
    return state

def backlog_node(state: OrchestratorState) -> OrchestratorState:
    artifact = generate_backlog(state["goal"], state["prd"], state["artifacts"].get("requirements", {}))
    validate_artifact("backlog", artifact)
    state["artifacts"]["backlog"] = artifact
    _trace(state, "backlog", "ok")
    return state

def architecture_node(state: OrchestratorState) -> OrchestratorState:
    artifact = generate_architecture(state["goal"], state["prd"], state.get("constraints", []))
    validate_artifact("architecture", artifact)
    state["artifacts"]["architecture"] = artifact
    _trace(state, "architecture", "pending_approval")
    return state

def scoring_node(state: OrchestratorState) -> OrchestratorState:
    state["scores"] = compute_scores(state)
    _trace(state, "scoring", "ok")
    return state

def approval_gate_node(state: OrchestratorState) -> OrchestratorState:
    if not state.get("approvals", {}).get("architecture", False):
        state["next_action"] = "await_architecture_approval"
        state["status"] = "awaiting_approval"
        _trace(state, "approval_gate", "blocked")
        return state
    _trace(state, "approval_gate", "approved")
    return state

def implementation_node(state: OrchestratorState) -> OrchestratorState:
    state["artifacts"]["implementation_plan"] = {
        "repo_structure": [
            "/api", "/orchestrator", "/services", "/shared", "/infra/terraform", "/tests"
        ],
        "pipelines": ["ci.yml", "deploy.yml"],
        "quality_gates": ["tests", "lint", "security-scan", "approval"]
    }
    _trace(state, "implementation", "ok")
    return state

def finalize_node(state: OrchestratorState) -> OrchestratorState:
    state["status"] = "completed"
    _trace(state, "finalize", "ok")
    return state
