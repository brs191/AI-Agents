from typing import Any

class GitHubAdapter:
    def create_issue(self, title: str, body: str) -> dict[str, Any]:
        return {"status": "stub", "action": "create_issue", "title": title}

    def create_pull_request(self, branch: str, title: str, body: str) -> dict[str, Any]:
        return {"status": "stub", "action": "create_pull_request", "branch": branch}
