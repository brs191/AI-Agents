from typing import Any

class JiraAdapter:
    def create_epic(self, title: str, description: str) -> dict[str, Any]:
        return {"status": "stub", "action": "create_epic", "title": title}
