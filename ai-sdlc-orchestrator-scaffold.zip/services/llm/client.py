import json
import os
from typing import Any
from openai import OpenAI

from shared.prompts import REQUIREMENTS_PROMPT, BACKLOG_PROMPT, ARCHITECTURE_PROMPT

def _fallback_requirements(goal: str, prd: str, constraints: list[str]) -> dict[str, Any]:
    return {
        "summary": goal,
        "user_stories": [
            {"title": "As a platform owner, I want automated SDLC orchestration so delivery is faster."}
        ],
        "acceptance_criteria": [
            "Generate requirements, backlog, and architecture artifacts",
            "Pause for architecture approval before implementation"
        ],
        "constraints": constraints,
    }

def _fallback_backlog(goal: str, prd: str, requirements: dict[str, Any]) -> dict[str, Any]:
    return {
        "epics": [
            {"id": "E1", "title": "Build orchestration engine", "priority": "P1"},
            {"id": "E2", "title": "Add approval workflow", "priority": "P1"},
            {"id": "E3", "title": "Add CI/CD and telemetry", "priority": "P2"}
        ]
    }

def _fallback_architecture(goal: str, prd: str, constraints: list[str]) -> dict[str, Any]:
    return {
        "services": ["api", "orchestrator", "policy-engine", "adapter-layer"],
        "deployment_target": "Azure Container Apps",
        "nfrs": ["auditability", "security", "resumability"],
        "constraints": constraints,
    }

def _chat_json(prompt: str) -> dict[str, Any]:
    api_key = os.getenv("OPENAI_API_KEY")
    model = os.getenv("OPENAI_MODEL", "gpt-5")
    if not api_key:
        return {}
    client = OpenAI(api_key=api_key)
    response = client.responses.create(
        model=model,
        input=prompt,
        text={"format": {"type": "json_object"}}
    )
    text = getattr(response, "output_text", "") or ""
    try:
        return json.loads(text)
    except Exception:
        return {}

def generate_requirements(goal: str, prd: str, constraints: list[str]) -> dict[str, Any]:
    prompt = REQUIREMENTS_PROMPT.format(goal=goal, prd=prd, constraints=", ".join(constraints))
    return _chat_json(prompt) or _fallback_requirements(goal, prd, constraints)

def generate_backlog(goal: str, prd: str, requirements: dict[str, Any]) -> dict[str, Any]:
    prompt = BACKLOG_PROMPT.format(goal=goal, prd=prd, requirements=json.dumps(requirements))
    return _chat_json(prompt) or _fallback_backlog(goal, prd, requirements)

def generate_architecture(goal: str, prd: str, constraints: list[str]) -> dict[str, Any]:
    prompt = ARCHITECTURE_PROMPT.format(goal=goal, prd=prd, constraints=", ".join(constraints))
    return _chat_json(prompt) or _fallback_architecture(goal, prd, constraints)
