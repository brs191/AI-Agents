from orchestrator.types import OrchestratorState

def compute_scores(state: OrchestratorState) -> dict[str, float]:
    requirements = state.get("artifacts", {}).get("requirements", {})
    backlog = state.get("artifacts", {}).get("backlog", {})
    architecture = state.get("artifacts", {}).get("architecture", {})
    readiness = 0.0
    readiness += 30.0 if requirements else 0.0
    readiness += 30.0 if backlog else 0.0
    readiness += 30.0 if architecture else 0.0
    readiness += 10.0 if len(state.get("constraints", [])) > 0 else 0.0
    return {
        "readiness": readiness,
        "risk": 25.0 if "PII" in " ".join(state.get("constraints", [])) else 10.0,
        "security": 80.0,
        "test_coverage": 60.0,
    }
