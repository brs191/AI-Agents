from typing import Any

REQUIRED_KEYS = {
    "requirements": ["summary", "user_stories", "acceptance_criteria", "constraints"],
    "backlog": ["epics"],
    "architecture": ["services", "deployment_target", "nfrs", "constraints"],
}

def validate_artifact(kind: str, artifact: dict[str, Any]) -> None:
    required = REQUIRED_KEYS.get(kind, [])
    missing = [k for k in required if k not in artifact]
    if missing:
        raise ValueError(f"{kind} artifact missing keys: {missing}")
