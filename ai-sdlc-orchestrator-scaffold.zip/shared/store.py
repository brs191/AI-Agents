import json
import os
from typing import Any

class FileStateStore:
    def __init__(self, path: str = None):
        self.path = path or os.getenv("STATE_STORE_PATH", "data/runs.json")
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        if not os.path.exists(self.path):
            with open(self.path, "w", encoding="utf-8") as f:
                json.dump({}, f)

    def _read_all(self) -> dict[str, Any]:
        with open(self.path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _write_all(self, data: dict[str, Any]) -> None:
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def save(self, run_id: str, state: dict[str, Any]) -> None:
        data = self._read_all()
        data[run_id] = state
        self._write_all(data)

    def load(self, run_id: str) -> dict[str, Any] | None:
        return self._read_all().get(run_id)
