from fastapi.testclient import TestClient
from api.main import app

client = TestClient(app)

def test_create_run():
    payload = {
        "project_name": "demo",
        "goal": "Build an AI SDLC orchestrator",
        "prd": "Create backlog and architecture from a PRD",
        "constraints": ["Azure", "GitHub Actions"],
        "target_env": "dev"
    }
    response = client.post("/runs", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "run_id" in data
    assert "result" in data
