# Azure DevOps AI Agent

A production-oriented starter repo for building an Azure-specific DevOps AI Agent using LangChain-style agents, modular skills, Azure CLI tools, and a VS Code-friendly workflow.

## What this repo gives you

- Azure DevOps skill library with 27 reusable skills
- Agent identity and system prompts
- Skill router for mapping user questions to skills
- Safe Azure CLI tool wrappers
- LangChain-compatible starter agent
- VS Code setup files
- Examples for AKS, Azure Pipelines, Terraform, monitoring, security, cost, and incidents

## Architecture

```text
User / VS Code / CLI
        ↓
Agent Runtime
        ↓
Skill Router
        ↓
Azure DevOps Skills
        ↓
Tools: az CLI, kubectl, terraform, logs
        ↓
Azure: AKS, Azure DevOps, Monitor, Key Vault, Networking, Cost Management
```

## Folder structure

```text
azure-devops-ai-agent/
├── agent/
│   ├── agent.md
│   ├── skill_router.py
│   └── runtime.py
├── skills/azure_devops/
│   ├── aks/
│   ├── pipelines/
│   ├── terraform/
│   ├── monitoring/
│   ├── networking/
│   ├── security/
│   ├── cost/
│   ├── incident/
│   └── general/
├── prompts/
├── tools/
├── config/
├── examples/
├── docs/
└── tests/
```

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python -m agent.runtime "AKS pods are failing after deployment in payments namespace"
```

## Safety model

This starter agent is read-only by default. Tool wrappers are designed for inspection and diagnosis. Any destructive operation such as delete, apply, scale, restart, or rollback should be added only with human approval gates.

## Skill format

Each skill follows this structure:

```md
# Skill: <Name>

## When to Use
## Signals
## Decision Tree
## Common Causes
## Fix Strategies
## Azure Tools / Commands
## Risk Level
```

## Recommended next steps

1. Add your Azure subscription, AKS cluster, and Azure DevOps project metadata in `config/agent_config.yaml`.
2. Connect tools to real Azure CLI, kubectl, Terraform, and Azure DevOps APIs.
3. Add approval workflow using LangGraph for any write/remediation action.
4. Add incident memory from real postmortems.
5. Add LangSmith/OpenTelemetry tracing.
