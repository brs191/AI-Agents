import sys
from agent.skill_router import select_skills, load_skill


def run(query: str) -> str:
    skills = select_skills(query)
    skill_text = "\n\n---\n\n".join(load_skill(skill) for skill in skills)

    return f"""# Azure DevOps AI Agent Response

## User Query
{query}

## Selected Skills
{chr(10).join(f'- {skill}' for skill in skills)}

## Skill Context Loaded
{skill_text}

## Next Step
Connect this runtime to LangChain/OpenAI and pass the selected skill context into the system prompt.
"""


if __name__ == "__main__":
    query = " ".join(sys.argv[1:]).strip() or "Check Azure system health"
    print(run(query))
