from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parents[1] / "skills" / "azure_devops"

KEYWORD_MAP = {
    "aks/pod_failure_analysis.md": ["pod", "crashloop", "oomkilled", "imagepull", "restart"],
    "aks/node_pool_scaling.md": ["nodepool", "node pool", "scale", "autoscale"],
    "aks/networking_issues.md": ["aks network", "cni", "pod network"],
    "aks/ingress_failure.md": ["ingress", "gateway", "nginx", "app gateway"],
    "aks/cluster_upgrade_issues.md": ["upgrade", "version", "aks upgrade"],
    "pipelines/pipeline_failure.md": ["pipeline", "build failed", "yaml"],
    "pipelines/release_failure.md": ["release", "deployment failed", "stage failed"],
    "pipelines/artifact_missing.md": ["artifact", "package missing"],
    "pipelines/agent_pool_issues.md": ["agent pool", "self-hosted agent", "hosted agent"],
    "terraform/plan_analysis.md": ["terraform plan", "plan"],
    "terraform/state_drift.md": ["drift", "state"],
    "terraform/apply_failure.md": ["terraform apply", "apply failed"],
    "monitoring/high_cpu.md": ["cpu", "processor"],
    "monitoring/high_latency.md": ["latency", "slow", "response time"],
    "monitoring/log_analysis.md": ["log", "exception", "error"],
    "monitoring/app_insights_failures.md": ["application insights", "app insights", "failed request"],
    "networking/vnet_connectivity.md": ["vnet", "connectivity", "nsg"],
    "networking/private_endpoint_issues.md": ["private endpoint", "private link"],
    "networking/dns_resolution.md": ["dns", "resolution"],
    "security/managed_identity_issues.md": ["managed identity", "identity", "rbac"],
    "security/keyvault_access.md": ["key vault", "keyvault", "secret"],
    "security/secrets_exposure.md": ["secret exposed", "credential", "leak"],
    "cost/cost_spike.md": ["cost", "bill", "spend"],
    "cost/resource_optimization.md": ["optimize", "rightsizing", "finops"],
    "incident/root_cause_analysis.md": ["root cause", "rca"],
    "incident/service_outage.md": ["outage", "down", "sev"],
    "general/system_health_check.md": ["health", "status", "check"],
}


def select_skills(query: str, max_results: int = 5) -> list[str]:
    query_lower = query.lower()
    scored = []
    for rel_path, keywords in KEYWORD_MAP.items():
        score = sum(1 for keyword in keywords if keyword in query_lower)
        if score:
            scored.append((score, rel_path))
    scored.sort(reverse=True)
    selected = [rel for _, rel in scored[:max_results]]
    if not selected:
        selected = ["general/system_health_check.md"]
    return selected


def load_skill(rel_path: str) -> str:
    return (SKILL_ROOT / rel_path).read_text(encoding="utf-8")
