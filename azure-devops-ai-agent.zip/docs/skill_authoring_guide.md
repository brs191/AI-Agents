# Skill Authoring Guide

A skill should be operational, evidence-driven, and reusable.

## Good skill characteristics

- Clear trigger signals
- Step-by-step decision tree
- Azure-native commands
- Common causes
- Safe remediation options
- Risk classification

## Anti-patterns

- Generic advice without signals
- Destructive commands without approval
- No mention of Azure-native services
- No prevention guidance
