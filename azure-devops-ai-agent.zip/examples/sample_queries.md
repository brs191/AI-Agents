# Sample Queries

- AKS pods are restarting after deployment in payments namespace.
- Azure DevOps pipeline failed during release stage.
- Terraform plan is trying to recreate a subnet. Is this risky?
- Application Insights shows high failed requests after the latest deployment.
- Azure cost increased suddenly this week. Help me investigate.
- Managed identity cannot access Key Vault secrets.
- Private endpoint is configured but app cannot reach the database.
