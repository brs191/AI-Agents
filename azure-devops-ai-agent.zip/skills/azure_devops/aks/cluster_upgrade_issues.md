# Skill: AKS Cluster Upgrade Issues

## When to Use
AKS upgrade fails or workloads degrade after upgrade.

## Signals
- Upgrade failed
- node image mismatch
- deprecated APIs
- pods evicted

## Decision Tree
1. Check AKS version
2. inspect upgrade errors
3. validate deprecated APIs
4. review PDBs and node pools

## Common Causes
- Deprecated Kubernetes APIs
- strict PDB
- unsupported add-ons
- node pool quota issues

## Fix Strategies
- Run preflight checks
- update manifests
- relax PDB carefully
- upgrade node pools sequentially

## Azure Tools / Commands
- az aks get-upgrades
- az aks show
- kubectl api-resources
- kubectl get pdb

## Risk Level
High
