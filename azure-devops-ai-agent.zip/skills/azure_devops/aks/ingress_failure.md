# Skill: AKS Ingress Failure

## When to Use
External traffic cannot reach AKS workloads.

## Signals
- HTTP 404/502/503
- TLS errors
- ingress has no address
- App Gateway backend unhealthy

## Decision Tree
1. Inspect ingress
2. check controller logs
3. validate service endpoints
4. check TLS secret and DNS

## Common Causes
- Wrong ingress rules
- missing backend endpoints
- TLS secret mismatch
- App Gateway/NGINX misconfig

## Fix Strategies
- Fix ingress rules
- correct service selector
- rotate TLS secret
- validate health probes

## Azure Tools / Commands
- kubectl get ingress
- kubectl describe ingress
- kubectl logs
- az network application-gateway show

## Risk Level
High
