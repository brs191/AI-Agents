# Skill: AKS Networking Issues

## When to Use
Pods/services cannot communicate inside or outside AKS.

## Signals
- Connection timeout
- DNS failure
- service unreachable
- network policy blocks traffic

## Decision Tree
1. Check service/endpoints
2. test DNS
3. inspect network policies
4. validate CNI and routes

## Common Causes
- Network policy deny
- wrong service selector
- DNS/CoreDNS issue
- UDR/NSG block
- subnet IP exhaustion

## Fix Strategies
- Fix selectors
- adjust network policies
- validate NSG/UDR
- scale subnet IP capacity

## Azure Tools / Commands
- kubectl get svc,endpoints
- kubectl get networkpolicy
- az network nsg rule list

## Risk Level
High
