# Skill: AKS Node Pool Scaling

## When to Use
Pods are pending or cluster capacity is insufficient.

## Signals
- Pending pods
- Insufficient cpu/memory
- node pressure
- autoscaler not scaling

## Decision Tree
1. Check pending pods
2. check node capacity
3. inspect cluster autoscaler events
4. review node pool min/max

## Common Causes
- Max nodes reached
- quota exhausted
- wrong VM SKU
- taints/tolerations mismatch
- unavailable zone capacity

## Fix Strategies
- Increase node pool max
- request quota
- change SKU
- fix scheduling constraints

## Azure Tools / Commands
- kubectl get nodes
- kubectl describe pod
- az aks nodepool show
- az vm list-usage

## Risk Level
High
