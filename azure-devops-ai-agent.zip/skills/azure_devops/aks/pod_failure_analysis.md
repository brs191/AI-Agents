# Skill: AKS Pod Failure Analysis

## When to Use
Pods are restarting, failing readiness, or stuck in waiting states.

## Signals
- CrashLoopBackOff
- OOMKilled
- ImagePullBackOff
- Pending
- readiness probe failed

## Decision Tree
1. Check pod status
2. describe pod
3. inspect events
4. inspect recent logs
5. correlate with deployment and config changes

## Common Causes
- Bad image tag or ACR auth
- insufficient memory
- bad config map or secret
- failing probes
- RBAC or managed identity issue

## Fix Strategies
- Fix image or ACR permissions
- tune resources
- validate configs/secrets
- adjust probes
- rollback only with approval

## Azure Tools / Commands
- kubectl get pods -A
- kubectl describe pod
- kubectl logs
- az aks show

## Risk Level
Medium
