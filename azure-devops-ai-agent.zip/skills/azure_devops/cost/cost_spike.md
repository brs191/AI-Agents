# Skill: Azure Cost Spike Analysis

## When to Use
Azure spend increases unexpectedly.

## Signals
- Daily spend jump
- high compute/storage/network cost
- budget alert

## Decision Tree
1. Open Cost Management
2. group by service/resource tag
3. compare period
4. map to deployment or traffic

## Common Causes
- Over-provisioning
- autoscale runaway
- orphaned resources
- high egress
- expensive SKU

## Fix Strategies
- Rightsize
- stop/delete orphaned resources with approval
- add budgets
- improve tags

## Azure Tools / Commands
- Azure Cost Management
- Azure Advisor
- az consumption usage list

## Risk Level
Medium
