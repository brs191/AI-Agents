# Skill: Azure Resource Optimization

## When to Use
Resources appear underused or expensive.

## Signals
- Low CPU/memory
- idle disks
- unattached public IPs
- oversized DB tier

## Decision Tree
1. Review utilization
2. check Advisor
3. classify criticality
4. estimate savings
5. define safe change window

## Common Causes
- Oversized SKU
- no autoscale
- idle non-prod
- forgotten disks/snapshots

## Fix Strategies
- Rightsize
- schedule shutdown
- reserved savings plan
- remove unused resources with approval

## Azure Tools / Commands
- Azure Advisor
- Cost Management
- Azure Monitor metrics

## Risk Level
Medium
