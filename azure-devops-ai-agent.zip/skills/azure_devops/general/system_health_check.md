# Skill: Azure System Health Check

## When to Use
General health check across Azure app stack.

## Signals
- Unknown issue
- routine check
- pre/post-deployment validation

## Decision Tree
1. Check Service Health
2. Resource Health
3. app metrics
4. logs
5. recent deployments
6. cost/security alerts

## Common Causes
- Regional issue
- unhealthy resource
- deployment regression
- identity/network failure

## Fix Strategies
- Summarize health
- highlight risks
- recommend targeted skill follow-up

## Azure Tools / Commands
- Azure Service Health
- Resource Health
- Azure Monitor
- Azure DevOps releases

## Risk Level
Low
