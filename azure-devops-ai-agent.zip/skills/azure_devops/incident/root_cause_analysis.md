# Skill: Azure Incident Root Cause Analysis

## When to Use
Need structured RCA for Azure incident.

## Signals
- Customer impact
- alert storm
- outage
- repeated failure

## Decision Tree
1. Define impact window
2. collect timeline
3. identify trigger
4. separate root cause vs contributing factors

## Common Causes
- Bad deployment
- capacity issue
- dependency failure
- config drift
- expired secret

## Fix Strategies
- Mitigate first
- identify durable fix
- add preventive controls
- produce postmortem

## Azure Tools / Commands
- Azure Monitor
- App Insights
- Service Health
- Activity Log
- Azure DevOps deployments

## Risk Level
High
