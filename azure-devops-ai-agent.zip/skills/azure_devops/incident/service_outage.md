# Skill: Azure Service Outage Triage

## When to Use
Service is unavailable or degraded.

## Signals
- 5xx spike
- health checks fail
- alerts fire
- user reports outage

## Decision Tree
1. Confirm impact
2. check Azure Service Health
3. inspect app/infra metrics
4. verify recent changes
5. initiate comms

## Common Causes
- Azure regional issue
- app regression
- infra failure
- dependency outage

## Fix Strategies
- Mitigate
- failover if designed
- rollback with approval
- communicate status

## Azure Tools / Commands
- Azure Service Health
- Resource Health
- App Insights
- Traffic Manager/Front Door

## Risk Level
Critical
