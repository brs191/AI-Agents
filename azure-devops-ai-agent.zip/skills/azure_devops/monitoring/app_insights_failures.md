# Skill: Application Insights Failure Analysis

## When to Use
App Insights reports failed requests or dependency failures.

## Signals
- HTTP 5xx
- dependency failure
- exception telemetry
- availability test failure

## Decision Tree
1. Inspect failures blade
2. query exceptions
3. inspect dependency map
4. correlate with release annotations

## Common Causes
- Code exception
- downstream outage
- connection string issue
- auth failure

## Fix Strategies
- Patch code/config
- fix dependency
- scale resource
- add synthetic checks

## Azure Tools / Commands
- Application Insights failures, application map, transaction search, KQL

## Risk Level
High
