# Skill: Azure High CPU Analysis

## When to Use
Azure resource or AKS workload has sustained high CPU.

## Signals
- CPU >80%
- throttling
- pod CPU saturation
- latency rise

## Decision Tree
1. Identify resource
2. correlate with deployment/traffic
3. inspect scaling
4. check hot paths/logs

## Common Causes
- Traffic spike
- inefficient code
- missing autoscale
- noisy neighbor
- under-provisioned SKU

## Fix Strategies
- Scale out/up
- tune limits
- optimize code
- enable autoscale alerts

## Azure Tools / Commands
- Azure Monitor metrics
- App Insights
- kubectl top pods
- az monitor metrics list

## Risk Level
High
