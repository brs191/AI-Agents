# Skill: Azure High Latency Analysis

## When to Use
Application response time increases.

## Signals
- High p95/p99
- dependency latency
- failed requests
- queue buildup

## Decision Tree
1. Check App Insights transaction
2. split app vs dependency time
3. correlate with deploys
4. inspect DB/cache/network

## Common Causes
- DB slow queries
- downstream API latency
- thread/connection pool exhaustion
- cold starts

## Fix Strategies
- Scale bottleneck
- tune queries
- increase pool carefully
- add cache
- rollback with approval

## Azure Tools / Commands
- Application Insights
- Azure Monitor
- Log Analytics KQL

## Risk Level
High
