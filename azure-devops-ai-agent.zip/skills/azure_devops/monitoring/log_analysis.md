# Skill: Azure Log Analysis

## When to Use
Logs show errors, exceptions, or abnormal patterns.

## Signals
- Exception spike
- repeated warnings
- auth failures
- timeout errors

## Decision Tree
1. Group errors by signature
2. correlate timestamp
3. identify new vs old pattern
4. map to deployment/config

## Common Causes
- Bad config
- dependency outage
- expired secret
- regression
- quota/throttle

## Fix Strategies
- Fix config
- rotate secret
- mitigate dependency
- create alert rule

## Azure Tools / Commands
- Log Analytics
- App Insights Logs
- Azure Monitor Workbooks

## Risk Level
Medium
