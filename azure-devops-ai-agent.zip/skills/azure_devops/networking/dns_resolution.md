# Skill: Azure DNS Resolution Issues

## When to Use
Services fail due to name resolution problems.

## Signals
- NXDOMAIN
- resolves public instead of private IP
- intermittent DNS

## Decision Tree
1. Test nslookup from workload
2. check private DNS zones
3. inspect VNet links
4. review custom DNS forwarders

## Common Causes
- Missing private DNS link
- bad custom DNS
- stale record
- split-horizon issue

## Fix Strategies
- Create/repair records
- link VNet
- fix forwarders
- flush cache/restart pods only with approval

## Azure Tools / Commands
- nslookup
- az network private-dns
- kubectl exec

## Risk Level
Medium
