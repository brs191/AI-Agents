# Skill: Azure Private Endpoint Issues

## When to Use
Private endpoint exists but service is unreachable.

## Signals
- Public endpoint works
- private IP unreachable
- DNS resolves public IP

## Decision Tree
1. Check PE connection state
2. validate private DNS zone link
3. verify NSG/UDR
4. inspect service firewall

## Common Causes
- Pending PE approval
- missing DNS zone link
- wrong VNet
- service firewall config

## Fix Strategies
- Approve PE
- fix DNS link
- update firewall
- validate name resolution

## Azure Tools / Commands
- az network private-endpoint
- az network private-dns
- nslookup

## Risk Level
High
