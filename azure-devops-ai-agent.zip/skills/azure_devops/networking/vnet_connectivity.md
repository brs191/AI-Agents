# Skill: Azure VNet Connectivity Issues

## When to Use
Azure resources cannot reach each other across VNets/subnets.

## Signals
- Timeout
- unreachable host
- NSG deny
- asymmetric routing

## Decision Tree
1. Check NSG effective rules
2. validate route tables
3. test Network Watcher
4. inspect peering/private DNS

## Common Causes
- NSG block
- UDR misroute
- missing peering
- firewall deny
- DNS mismatch

## Fix Strategies
- Update NSG/UDR
- fix peering
- validate firewall rules
- test from source subnet

## Azure Tools / Commands
- Azure Network Watcher
- az network nsg
- az network route-table

## Risk Level
High
