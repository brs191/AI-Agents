# Skill: Azure DevOps Agent Pool Issues

## When to Use
Pipeline jobs are queued or fail on self-hosted/hosted agents.

## Signals
- Job queued
- agent offline
- capability mismatch
- disk full

## Decision Tree
1. Check agent pool status
2. inspect agent logs
3. verify demands
4. validate network and disk

## Common Causes
- Agent offline
- missing capability
- exhausted parallel jobs
- blocked outbound connectivity

## Fix Strategies
- Restart agent
- add capacity
- fix capabilities
- clean disk
- validate firewall

## Azure Tools / Commands
- Azure DevOps Agent Pools
- agent diagnostics
- az pipelines agent

## Risk Level
Medium
