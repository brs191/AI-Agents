# Skill: Azure Pipeline Artifact Missing

## When to Use
Release cannot find or download build artifacts.

## Signals
- Artifact not found
- package version missing
- download task failed

## Decision Tree
1. Check build publish step
2. verify artifact name
3. inspect retention
4. validate feed/package permissions

## Common Causes
- Artifact not published
- retention cleanup
- wrong artifact alias
- feed permission issue

## Fix Strategies
- Fix publish task
- adjust retention
- correct alias/version
- grant feed permissions

## Azure Tools / Commands
- Azure Artifacts
- az artifacts
- pipeline logs

## Risk Level
Low
