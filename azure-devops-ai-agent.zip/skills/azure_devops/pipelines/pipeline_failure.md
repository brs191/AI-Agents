# Skill: Azure DevOps Pipeline Failure

## When to Use
Build or validation pipeline fails.

## Signals
- Failed job
- YAML parse error
- task failure
- missing variable

## Decision Tree
1. Identify failed stage/job/task
2. inspect logs
3. validate YAML
4. check variables and service connection

## Common Causes
- Bad YAML
- missing secrets
- dependency failure
- permission issue
- unavailable hosted agent image

## Fix Strategies
- Fix YAML
- restore variables
- update task versions
- validate service connection/RBAC

## Azure Tools / Commands
- Azure DevOps UI
- az pipelines runs show
- az pipelines build show

## Risk Level
Low
