# Skill: Azure DevOps Release Failure

## When to Use
Deployment or release stage fails.

## Signals
- Deployment task failed
- approval blocked
- environment lock
- Azure auth failure

## Decision Tree
1. Check release logs
2. inspect environment approvals
3. validate service connection
4. correlate with target resource health

## Common Causes
- Bad service connection
- missing approval
- failed deployment script
- target infra unhealthy

## Fix Strategies
- Fix service connection
- complete approval
- validate infra
- redeploy with approval

## Azure Tools / Commands
- az pipelines release
- Azure DevOps Environments
- Azure Resource Health

## Risk Level
Medium
