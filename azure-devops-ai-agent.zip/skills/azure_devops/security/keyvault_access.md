# Skill: Azure Key Vault Access Issue

## When to Use
Application cannot read secrets/certificates/keys from Key Vault.

## Signals
- 403 Forbidden
- secret not found
- certificate expired
- firewall deny

## Decision Tree
1. Check access model
2. validate RBAC/access policy
3. inspect firewall/private endpoint
4. check secret version

## Common Causes
- Missing role/policy
- blocked network
- disabled/expired secret
- wrong vault URI

## Fix Strategies
- Grant least privilege
- fix firewall/PE
- rotate or enable secret
- update app config

## Azure Tools / Commands
- az keyvault secret show
- az role assignment list
- Key Vault diagnostics

## Risk Level
High
