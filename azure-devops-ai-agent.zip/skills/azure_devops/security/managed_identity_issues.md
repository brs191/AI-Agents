# Skill: Managed Identity Failure

## When to Use
Azure workload cannot authenticate using managed identity.

## Signals
- 403
- CredentialUnavailable
- MSI endpoint timeout
- token acquisition failed

## Decision Tree
1. Check identity assignment
2. verify role assignment
3. validate scope
4. test token retrieval

## Common Causes
- Identity not assigned
- wrong client ID
- missing RBAC
- propagation delay

## Fix Strategies
- Assign identity
- fix client ID
- grant least-privilege role
- wait/retry after propagation

## Azure Tools / Commands
- az identity show
- az role assignment list
- Azure Instance Metadata Service

## Risk Level
High
