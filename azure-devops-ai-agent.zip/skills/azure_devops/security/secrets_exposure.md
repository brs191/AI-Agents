# Skill: Secrets Exposure Response

## When to Use
Credentials, tokens, or secrets may be exposed in code/logs/pipelines.

## Signals
- Secret in repo
- pipeline log leak
- exposed connection string
- leaked token

## Decision Tree
1. Identify scope
2. revoke/rotate secret
3. scan repos/logs
4. assess access
5. document incident

## Common Causes
- Hardcoded secret
- verbose logs
- unmasked pipeline variable
- misconfigured Key Vault reference

## Fix Strategies
- Rotate immediately
- purge logs if possible
- add secret scanning
- enforce variable masking

## Azure Tools / Commands
- Azure Key Vault
- Azure DevOps variable groups
- Defender for Cloud
- Git secret scanning

## Risk Level
Critical
