# Skill: Terraform Azure Apply Failure

## When to Use
Terraform apply fails against Azure.

## Signals
- Authorization failed
- conflict
- timeout
- quota exceeded
- name unavailable

## Decision Tree
1. Read exact provider error
2. validate identity permissions
3. check Azure quotas and locks
4. retry only safe idempotent ops

## Common Causes
- RBAC missing
- resource lock
- quota shortage
- API throttling
- provider bug

## Fix Strategies
- Fix RBAC
- remove/adjust locks with approval
- request quota
- pin provider
- split apply

## Azure Tools / Commands
- terraform apply
- az role assignment list
- az lock list
- az quota

## Risk Level
High
