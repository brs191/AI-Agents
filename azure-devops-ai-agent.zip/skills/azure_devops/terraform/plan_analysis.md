# Skill: Terraform Azure Plan Analysis

## When to Use
Terraform plan shows unexpected Azure changes.

## Signals
- Resource recreate
- delete before create
- networking/IAM changes
- provider diff

## Decision Tree
1. Review plan by resource type
2. identify destructive changes
3. compare with expected change
4. check dependencies

## Common Causes
- State drift
- provider upgrade
- changed immutable field
- manual portal changes

## Fix Strategies
- Do not apply blindly
- refresh state
- import resource
- pin provider
- get approval

## Azure Tools / Commands
- terraform plan
- terraform show
- az resource show

## Risk Level
High
