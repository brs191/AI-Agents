# Skill: Terraform Azure State Drift

## When to Use
Azure resources differ from Terraform state.

## Signals
- Plan shows unexpected changes
- portal edits
- missing resources

## Decision Tree
1. Run refresh-only plan
2. compare Azure resource properties
3. inspect state
4. identify manual change

## Common Causes
- Manual portal change
- failed previous apply
- resource recreated externally
- state backend issue

## Fix Strategies
- Import or correct state
- revert manual changes
- lock down portal permissions

## Azure Tools / Commands
- terraform plan -refresh-only
- terraform state list
- az resource show

## Risk Level
High
