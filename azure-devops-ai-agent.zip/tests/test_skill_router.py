from agent.skill_router import select_skills


def test_aks_pod_query_routes_to_pod_skill():
    skills = select_skills("AKS pod is in CrashLoopBackOff")
    assert "aks/pod_failure_analysis.md" in skills


def test_cost_query_routes_to_cost_skill():
    skills = select_skills("Azure bill and cost spike")
    assert "cost/cost_spike.md" in skills
