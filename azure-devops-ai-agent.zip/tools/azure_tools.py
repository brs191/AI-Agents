from tools.safe_shell import run_readonly_command


def az_account_show() -> str:
    return run_readonly_command(["az", "account", "show"])


def az_resource_health(resource_id: str) -> str:
    return run_readonly_command(["az", "resource", "show", "--ids", resource_id])


def az_aks_show(resource_group: str, cluster_name: str) -> str:
    return run_readonly_command(["az", "aks", "show", "-g", resource_group, "-n", cluster_name])
