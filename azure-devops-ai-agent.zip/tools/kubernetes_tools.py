from tools.safe_shell import run_readonly_command


def get_pods(namespace: str = "default") -> str:
    return run_readonly_command(["kubectl", "get", "pods", "-n", namespace, "-o", "wide"])


def describe_pod(namespace: str, pod_name: str) -> str:
    return run_readonly_command(["kubectl", "describe", "pod", pod_name, "-n", namespace])


def get_events(namespace: str = "default") -> str:
    return run_readonly_command(["kubectl", "get", "events", "-n", namespace, "--sort-by=.lastTimestamp"])
