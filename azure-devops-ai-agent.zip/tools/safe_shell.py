import subprocess
from typing import Sequence

BLOCKED_TOKENS = {
    "delete", "rm", "destroy", "apply", "restart", "scale", "patch", "create", "update", "set"
}


def run_readonly_command(command: Sequence[str], timeout: int = 30) -> str:
    lowered = " ".join(command).lower()
    if any(token in lowered for token in BLOCKED_TOKENS):
        return f"Blocked unsafe command: {' '.join(command)}"

    result = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
    if result.returncode != 0:
        return f"Command failed: {' '.join(command)}\nSTDERR:\n{result.stderr}"
    return result.stdout.strip()
