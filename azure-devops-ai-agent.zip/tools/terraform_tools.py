from tools.safe_shell import run_readonly_command


def terraform_plan(directory: str = ".") -> str:
    return run_readonly_command(["terraform", f"-chdir={directory}", "plan", "-no-color"])


def terraform_validate(directory: str = ".") -> str:
    return run_readonly_command(["terraform", f"-chdir={directory}", "validate"])
