# Azure FinOps Orchestrator Runtime (Go)

A production-oriented Go runtime service that automatically executes the orchestrated Azure FinOps flow.

## What it does

This service provides:
- an HTTP API to run FinOps workflows
- orchestration logic for:
  - spend summary
  - anomaly investigation
  - forecast review
  - savings plan
- specialist agents implemented as workflow stages
- a minimal MCP stdio client that calls your Azure Cloud Cost MCP server automatically
- optional Azure OpenAI summarization for executive-style outputs

## Architecture

Request -> Orchestrator -> Specialist stages -> Azure Cost MCP tools -> merged response

Stages:
- analyst
- correlation
- reviewer
- planner
- executive summary

## Why this design

- keeps MCP as the source of truth for cost facts
- makes the flow executable from a service, not just inside VS Code
- keeps agent outputs structured and composable
- allows Azure OpenAI to handle summarization, not data retrieval

## Endpoints

### POST /api/v1/run
Run an orchestrated workflow.

Example request:
```json
{
  "mode": "anomaly_investigation",
  "question": "Why did Azure cost increase this month?",
  "baseline_start_date": "2026-02-01",
  "baseline_end_date": "2026-02-29",
  "comparison_start_date": "2026-03-01",
  "comparison_end_date": "2026-03-31",
  "start_date": "2026-03-01",
  "end_date": "2026-03-31",
  "group_by": "ServiceName",
  "repo_hints": ["aks", "cdn", "network", "scale", "region"]
}
```

### GET /healthz
Basic runtime health.

## Environment

The runtime launches your Azure Cost MCP server as a subprocess using:
- `MCP_SERVER_COMMAND`
- `MCP_SERVER_ARGS`
- `MCP_SERVER_WORKDIR`

The runtime passes Azure cost env vars through to that process.

## Notes

- This runtime is read-only.
- It does not auto-remediate.
- Correlation stage is heuristic unless you integrate real repo/deployment connectors.
- Azure OpenAI use is optional. If not configured, the service still returns structured results.

## Run

```bash
go mod tidy
go run ./cmd/orchestrator
```
