package main

import (
	"context"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/your-org/azure-finops-orchestrator-runtime-go/internal/azureopenai"
	"github.com/your-org/azure-finops-orchestrator-runtime-go/internal/config"
	"github.com/your-org/azure-finops-orchestrator-runtime-go/internal/httpapi"
	"github.com/your-org/azure-finops-orchestrator-runtime-go/internal/mcpclient"
	"github.com/your-org/azure-finops-orchestrator-runtime-go/internal/orchestrator"
)

func main() {
	cfg := config.Load()

	mcp := mcpclient.New(cfg)
	llm, _ := azureopenai.New(cfg)

	orch := orchestrator.New(cfg, mcp, llm)
	h := httpapi.New(cfg, orch)

	srv := &http.Server{
		Addr:         ":" + cfg.Port,
		Handler:      h.Routes(),
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 60 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	go func() {
		<-ctx.Done()
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		_ = srv.Shutdown(shutdownCtx)
	}()

	log.Printf("azure finops orchestrator runtime listening on %s", srv.Addr)
	if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		log.Fatal(err)
	}
}
