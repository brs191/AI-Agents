module github.com/your-org/azure-finops-orchestrator-runtime-go

go 1.23.0

require (
	github.com/Azure/azure-sdk-for-go/sdk/azcore v1.17.0
	github.com/Azure/azure-sdk-for-go/sdk/azidentity v1.10.1
)
