package azureopenai

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"

	"github.com/your-org/azure-finops-orchestrator-runtime-go/internal/config"
)

type Client struct {
	endpoint   string
	deployment string
	apiVersion string
	apiKey     string
	http       *http.Client
}

func New(cfg config.Config) (*Client, error) {
	if cfg.AzureOpenAIEndpoint == "" || cfg.AzureOpenAIDeployment == "" || cfg.AzureOpenAIAPIKey == "" {
		return nil, fmt.Errorf("azure openai not configured")
	}
	return &Client{
		endpoint: strings.TrimRight(cfg.AzureOpenAIEndpoint, "/"),
		deployment: cfg.AzureOpenAIDeployment,
		apiVersion: cfg.AzureOpenAIAPIVersion,
		apiKey: cfg.AzureOpenAIAPIKey,
		http: &http.Client{},
	}, nil
}

func (c *Client) Respond(ctx context.Context, prompt string) (string, error) {
	url := c.endpoint + "/openai/v1/responses?api-version=" + c.apiVersion
	payload := map[string]any{
		"model": c.deployment,
		"input": prompt,
	}
	b, _ := json.Marshal(payload)

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, url, bytes.NewReader(b))
	if err != nil { return "", err }
	req.Header.Set("api-key", c.apiKey)
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.http.Do(req)
	if err != nil { return "", err }
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil { return "", err }
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return "", fmt.Errorf("azure openai status %d: %s", resp.StatusCode, string(body))
	}

	var out struct {
		Output []struct {
			Content []struct {
				Text string `json:"text"`
			} `json:"content"`
		} `json:"output"`
	}
	if err := json.Unmarshal(body, &out); err != nil { return "", err }
	for _, item := range out.Output {
		for _, c := range item.Content {
			if c.Text != "" {
				return c.Text, nil
			}
		}
	}
	return "", fmt.Errorf("no text output returned")
}
