package config

import (
	"os"
	"strings"
	"time"
)

type Config struct {
	Port     string
	LogLevel string

	AzureOpenAIEndpoint   string
	AzureOpenAIDeployment string
	AzureOpenAIAPIVersion string
	AzureOpenAIAPIKey     string
	AzureOpenAIUseEntra   bool

	MCPServerCommand string
	MCPServerArgs    []string
	MCPServerWorkdir string

	AzureCostScope    string
	AzureAPIVersion   string
	QueryTimeout      string
	DefaultCurrency   string
	AzureTenantID     string
	AzureClientID     string
	AzureClientSecret string

	RequestTimeout time.Duration
}

func Load() Config {
	return Config{
		Port:                    getenv("PORT", "8080"),
		LogLevel:                getenv("LOG_LEVEL", "info"),
		AzureOpenAIEndpoint:     getenv("AZURE_OPENAI_ENDPOINT", ""),
		AzureOpenAIDeployment:   getenv("AZURE_OPENAI_DEPLOYMENT", ""),
		AzureOpenAIAPIVersion:   getenv("AZURE_OPENAI_API_VERSION", "preview"),
		AzureOpenAIAPIKey:       getenv("AZURE_OPENAI_API_KEY", ""),
		AzureOpenAIUseEntra:     getBool("AZURE_OPENAI_USE_ENTRA", false),
		MCPServerCommand:        getenv("MCP_SERVER_COMMAND", "go"),
		MCPServerArgs:           splitCSV(getenv("MCP_SERVER_ARGS", "run,./cmd/server")),
		MCPServerWorkdir:        getenv("MCP_SERVER_WORKDIR", "../azure-cloud-cost-mcp-go"),
		AzureCostScope:          getenv("AZURE_COST_SCOPE", ""),
		AzureAPIVersion:         getenv("AZURE_API_VERSION", "2025-03-01"),
		QueryTimeout:            getenv("QUERY_TIMEOUT", "20s"),
		DefaultCurrency:         getenv("DEFAULT_CURRENCY", "USD"),
		AzureTenantID:           getenv("AZURE_TENANT_ID", ""),
		AzureClientID:           getenv("AZURE_CLIENT_ID", ""),
		AzureClientSecret:       getenv("AZURE_CLIENT_SECRET", ""),
		RequestTimeout:          getDuration("REQUEST_TIMEOUT", 45*time.Second),
	}
}

func getenv(k, fallback string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return fallback
}

func splitCSV(v string) []string {
	parts := strings.Split(v, ",")
	out := make([]string, 0, len(parts))
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

func getBool(k string, fallback bool) bool {
	v := strings.ToLower(strings.TrimSpace(os.Getenv(k)))
	switch v {
	case "1", "true", "yes", "y":
		return true
	case "0", "false", "no", "n":
		return false
	default:
		return fallback
	}
}

func getDuration(k string, fallback time.Duration) time.Duration {
	if v := os.Getenv(k); v != "" {
		d, err := time.ParseDuration(v)
		if err == nil {
			return d
		}
	}
	return fallback
}
