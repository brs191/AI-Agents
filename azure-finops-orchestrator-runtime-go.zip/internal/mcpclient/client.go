package mcpclient

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"sync/atomic"
	"time"

	"github.com/your-org/azure-finops-orchestrator-runtime-go/internal/config"
)

type Client struct {
	cfg config.Config
	id  int64
}

func New(cfg config.Config) *Client {
	return &Client{cfg: cfg}
}

func (c *Client) CallTool(ctx context.Context, toolName string, args map[string]any) (map[string]any, error) {
	callCtx, cancel := context.WithTimeout(ctx, c.cfg.RequestTimeout)
	defer cancel()

	cmd := exec.CommandContext(callCtx, c.cfg.MCPServerCommand, c.cfg.MCPServerArgs...)
	cmd.Dir = c.cfg.MCPServerWorkdir
	cmd.Env = append(os.Environ(),
		"AZURE_COST_SCOPE="+c.cfg.AzureCostScope,
		"AZURE_API_VERSION="+c.cfg.AzureAPIVersion,
		"QUERY_TIMEOUT="+c.cfg.QueryTimeout,
		"DEFAULT_CURRENCY="+c.cfg.DefaultCurrency,
		"AZURE_TENANT_ID="+c.cfg.AzureTenantID,
		"AZURE_CLIENT_ID="+c.cfg.AzureClientID,
		"AZURE_CLIENT_SECRET="+c.cfg.AzureClientSecret,
	)

	stdin, err := cmd.StdinPipe()
	if err != nil { return nil, err }
	stdout, err := cmd.StdoutPipe()
	if err != nil { return nil, err }
	stderr, _ := cmd.StderrPipe()

	if err := cmd.Start(); err != nil {
		return nil, err
	}
	defer cmd.Process.Kill()

	_ = stderr // available for extension later

	r := bufio.NewReader(stdout)
	w := bufio.NewWriter(stdin)

	write := func(v any) error {
		b, err := json.Marshal(v)
		if err != nil { return err }
		if _, err := w.Write(append(b, '\n')); err != nil { return err }
		return w.Flush()
	}

	readResp := func() (map[string]any, error) {
		line, err := r.ReadBytes('\n')
		if err != nil { return nil, err }
		var out map[string]any
		if err := json.Unmarshal(line, &out); err != nil { return nil, err }
		return out, nil
	}

	initID := c.nextID()
	if err := write(map[string]any{
		"jsonrpc": "2.0",
		"id": initID,
		"method": "initialize",
		"params": map[string]any{
			"protocolVersion": "2025-03-26",
			"capabilities": map[string]any{},
			"clientInfo": map[string]any{"name": "azure-finops-orchestrator-runtime", "version": "0.1.0"},
		},
	}); err != nil { return nil, err }

	if _, err := readResp(); err != nil { return nil, err }

	_ = write(map[string]any{"jsonrpc": "2.0", "method": "notifications/initialized", "params": map[string]any{}})

	callID := c.nextID()
	if err := write(map[string]any{
		"jsonrpc": "2.0",
		"id": callID,
		"method": "tools/call",
		"params": map[string]any{
			"name": toolName,
			"arguments": args,
		},
	}); err != nil { return nil, err }

	deadline := time.After(c.cfg.RequestTimeout)
	for {
		select {
		case <-callCtx.Done():
			return nil, callCtx.Err()
		case <-deadline:
			return nil, fmt.Errorf("mcp tool call timeout")
		default:
			resp, err := readResp()
			if err != nil {
				return nil, err
			}
			if id, ok := resp["id"].(float64); ok && int64(id) == callID {
				if e, ok := resp["error"].(map[string]any); ok {
					return nil, fmt.Errorf("mcp error: %v", e["message"])
				}
				result, _ := resp["result"].(map[string]any)
				return decodeToolText(result)
			}
		}
	}
}

func (c *Client) nextID() int64 {
	return atomic.AddInt64(&c.id, 1)
}

func decodeToolText(result map[string]any) (map[string]any, error) {
	content, _ := result["content"].([]any)
	for _, item := range content {
		m, ok := item.(map[string]any)
		if !ok { continue }
		text, _ := m["text"].(string)
		if text == "" { continue }
		var out map[string]any
		if err := json.Unmarshal([]byte(text), &out); err != nil {
			return map[string]any{"raw_text": text}, nil
		}
		return out, nil
	}
	return map[string]any{}, nil
}
