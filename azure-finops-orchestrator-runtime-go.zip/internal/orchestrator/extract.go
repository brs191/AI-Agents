package orchestrator

import "fmt"

func extractTopBuckets(tool map[string]any) []BucketAmount {
	entriesRaw, _ := tool["entries"].([]any)
	out := make([]BucketAmount, 0, len(entriesRaw))
	for _, row := range entriesRaw {
		m, ok := row.(map[string]any)
		if !ok { continue }
		out = append(out, BucketAmount{
			Bucket: asString(m["bucket"]),
			Amount: asFloat(m["amount"]),
			Currency: coalesceString(asString(m["currency"]), asString(m["unit"])),
		})
		if len(out) >= 5 { break }
	}
	return out
}

func extractAnomalyReasoning(tool map[string]any) ([]Hypothesis, []string) {
	deltasRaw, _ := tool["top_deltas"].([]any)
	hyps := []Hypothesis{}
	evidence := []string{}
	for _, row := range deltasRaw {
		m, ok := row.(map[string]any)
		if !ok { continue }
		bucket := asString(m["bucket"])
		pct := asFloat(m["percent_delta"])
		curr := asString(m["currency"])
		abs := asFloat(m["absolute_delta"])
		evidence = append(evidence, fmt.Sprintf("%s changed by %.2f %s (%.1f%%).", bucket, abs, curr, pct))
		hyps = append(hyps, Hypothesis{
			Text: bucket + " appears to be a primary driver of the selected cost change.",
			Confidence: "medium",
		})
		if len(hyps) >= 3 { break }
	}
	if len(hyps) == 0 {
		hyps = append(hyps, Hypothesis{Text: "No strong anomaly driver was extracted from the period comparison.", Confidence: "low"})
	}
	return hyps, evidence
}

func extractForecastSummary(tool map[string]any) (float64, string) {
	return asFloat(tool["amount"]), coalesceString(asString(tool["currency"]), "USD")
}

func asString(v any) string {
	s, _ := v.(string)
	return s
}

func asFloat(v any) float64 {
	switch t := v.(type) {
	case float64:
		return t
	case float32:
		return float64(t)
	case int:
		return float64(t)
	case int64:
		return float64(t)
	default:
		return 0
	}
}

func coalesceString(v, fallback string) string {
	if v != "" { return v }
	return fallback
}
