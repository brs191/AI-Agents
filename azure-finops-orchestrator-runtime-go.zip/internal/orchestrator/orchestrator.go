package orchestrator

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"

	"github.com/your-org/azure-finops-orchestrator-runtime-go/internal/azureopenai"
	"github.com/your-org/azure-finops-orchestrator-runtime-go/internal/config"
	"github.com/your-org/azure-finops-orchestrator-runtime-go/internal/mcpclient"
)

type Orchestrator struct {
	cfg config.Config
	mcp *mcpclient.Client
	llm *azureopenai.Client
}

func New(cfg config.Config, mcp *mcpclient.Client, llm *azureopenai.Client) *Orchestrator {
	return &Orchestrator{cfg: cfg, mcp: mcp, llm: llm}
}

func (o *Orchestrator) Run(ctx context.Context, req RunRequest) (RunResponse, error) {
	mode := normalizeMode(req.Mode)
	resp := RunResponse{
		Mode: mode,
		Classification: mode,
	}

	analyst, err := o.runAnalyst(ctx, mode, req)
	if err != nil {
		return RunResponse{}, err
	}
	resp.Analyst = &analyst

	switch mode {
	case "spend_summary":
		exec, err := o.runExecutiveSummary(ctx, analyst, nil, nil)
		if err != nil { return RunResponse{}, err }
		resp.ExecutiveSummary = &exec
		resp.FinalSummary = exec.Headline + " Next action: " + exec.NextAction
	case "forecast_review":
		reviewer := o.runReviewer(analyst, nil)
		resp.Reviewer = &reviewer
		exec, err := o.runExecutiveSummary(ctx, analyst, nil, &reviewer)
		if err != nil { return RunResponse{}, err }
		resp.ExecutiveSummary = &exec
		resp.FinalSummary = exec.Headline + " Top risk: " + exec.TopRisk
	case "savings_plan":
		reviewer := o.runReviewer(analyst, nil)
		planner := o.runPlanner(analyst, nil, &reviewer)
		resp.Reviewer = &reviewer
		resp.Planner = &planner
		resp.FinalSummary = buildFinalSummary(mode, analyst, nil, &reviewer, &planner)
	default:
		corr := o.runCorrelation(req)
		reviewer := o.runReviewer(analyst, &corr)
		planner := o.runPlanner(analyst, &corr, &reviewer)
		resp.Correlation = &corr
		resp.Reviewer = &reviewer
		resp.Planner = &planner
		resp.FinalSummary = buildFinalSummary(mode, analyst, &corr, &reviewer, &planner)
	}

	return resp, nil
}

func normalizeMode(v string) string {
	switch strings.ToLower(strings.TrimSpace(v)) {
	case "spend_summary", "forecast_review", "savings_plan", "anomaly_investigation":
		return strings.ToLower(strings.TrimSpace(v))
	default:
		return "anomaly_investigation"
	}
}

func (o *Orchestrator) runAnalyst(ctx context.Context, mode string, req RunRequest) (AnalystOutput, error) {
	out := AnalystOutput{
		FindingType: mode,
		Confidence: "medium",
		ToolData: map[string]any{},
	}

	switch mode {
	case "forecast_review":
		forecast, err := o.mcp.CallTool(ctx, "forecast_cost", map[string]any{
			"start_date": req.StartDate,
			"end_date": req.EndDate,
			"granularity": "Monthly",
		})
		if err != nil { return out, err }
		out.ToolData["forecast_cost"] = forecast
		amt, currency := extractForecastSummary(forecast)
		out.Evidence = []string{fmt.Sprintf("Forecast for selected period is %.2f %s.", amt, currency)}
		out.Hypotheses = []Hypothesis{{Text: "Forecast should be reviewed against recent traffic and deployment changes.", Confidence: "medium"}}
		out.TopBuckets = []BucketAmount{{Bucket: "Forecast", Amount: amt, Currency: currency}}
	case "savings_plan":
		breakdown, err := o.mcp.CallTool(ctx, "get_cost_breakdown", map[string]any{
			"start_date": req.StartDate, "end_date": req.EndDate, "granularity": "None", "group_by": defaultGroupBy(req.GroupBy),
		})
		if err != nil { return out, err }
		savings, err := o.mcp.CallTool(ctx, "recommend_savings", map[string]any{
			"start_date": req.StartDate, "end_date": req.EndDate, "group_by": defaultGroupBy(req.GroupBy),
		})
		if err != nil { return out, err }
		out.ToolData["get_cost_breakdown"] = breakdown
		out.ToolData["recommend_savings"] = savings
		out.TopBuckets = extractTopBuckets(breakdown)
		out.Evidence = []string{fmt.Sprintf("Top spend bucket is %s.", firstBucket(out.TopBuckets))}
		out.Hypotheses = []Hypothesis{{Text: "Concentrated spend likely offers the fastest initial savings opportunity.", Confidence: "medium"}}
	default:
		breakdown, err := o.mcp.CallTool(ctx, "get_cost_breakdown", map[string]any{
			"start_date": coalesce(req.StartDate, req.ComparisonStartDate),
			"end_date": coalesce(req.EndDate, req.ComparisonEndDate),
			"granularity": "None",
			"group_by": defaultGroupBy(req.GroupBy),
		})
		if err != nil { return out, err }
		anoms, err := o.mcp.CallTool(ctx, "detect_cost_anomalies", map[string]any{
			"baseline_start_date": req.BaselineStartDate,
			"baseline_end_date": req.BaselineEndDate,
			"comparison_start_date": req.ComparisonStartDate,
			"comparison_end_date": req.ComparisonEndDate,
			"group_by": defaultGroupBy(req.GroupBy),
		})
		if err != nil { return out, err }
		out.ToolData["get_cost_breakdown"] = breakdown
		out.ToolData["detect_cost_anomalies"] = anoms
		out.TopBuckets = extractTopBuckets(breakdown)
		hyp, ev := extractAnomalyReasoning(anoms)
		out.Hypotheses = hyp
		out.Evidence = ev
	}

	if len(out.Evidence) == 0 {
		out.Evidence = []string{"No strong evidence extracted from tool outputs."}
	}
	if len(out.Hypotheses) == 0 {
		out.Hypotheses = []Hypothesis{{Text: "Further validation is needed.", Confidence: "low"}}
	}
	return out, nil
}

func (o *Orchestrator) runCorrelation(req RunRequest) CorrelationOutput {
	correlations := []string{}
	for _, hint := range req.RepoHints {
		h := strings.ToLower(strings.TrimSpace(hint))
		switch h {
		case "aks", "scale", "autoscale":
			correlations = append(correlations, "Scaling-related changes may correlate with higher compute or network costs.")
		case "cdn", "cache", "caching":
			correlations = append(correlations, "Caching and CDN configuration changes may correlate with data transfer changes.")
		case "network", "region":
			correlations = append(correlations, "Region or networking changes may correlate with egress or cross-region traffic costs.")
		case "data", "replication":
			correlations = append(correlations, "Data movement or replication changes may correlate with storage and network spend.")
		}
	}
	if len(correlations) == 0 {
		correlations = append(correlations, "No repository hints were provided, so infrastructure correlation remains weak.")
	}
	strength := "weak"
	if len(correlations) >= 2 {
		strength = "moderate"
	}
	return CorrelationOutput{
		PossibleCorrelations: correlations,
		EvidenceStrength: strength,
		Notes: []string{"This stage is heuristic unless you integrate actual repo, deployment, or telemetry connectors."},
	}
}

func (o *Orchestrator) runReviewer(analyst AnalystOutput, corr *CorrelationOutput) ReviewerOutput {
	risks := []string{}
	validations := []string{}
	confidence := analyst.Confidence

	if corr != nil && corr.EvidenceStrength == "weak" {
		risks = append(risks, "Correlation evidence is weak; causation is not established.")
		validations = append(validations, "Check deployment and infrastructure timelines against the anomaly window.")
		confidence = "low"
	}
	if len(analyst.TopBuckets) > 0 {
		validations = append(validations, "Validate the top spend bucket with a second time-slice or alternate grouping.")
	}
	if len(risks) == 0 {
		risks = append(risks, "Savings estimates are heuristic and should be validated before action.")
	}
	return ReviewerOutput{
		Verdict: "needs_validation",
		TopRisks: risks,
		MissingValidations: dedupe(validations),
		ConfidenceAdjustment: confidence,
	}
}

func (o *Orchestrator) runPlanner(analyst AnalystOutput, corr *CorrelationOutput, reviewer *ReviewerOutput) PlannerOutput {
	actions := []string{}
	owners := []string{"Platform Engineering", "FinOps"}
	metrics := []string{"Cost by service/day", "Month-over-month delta by grouping"}
	rollback := []string{"Revert traffic-routing or caching changes if reliability regresses."}

	if len(analyst.TopBuckets) > 0 {
		actions = append(actions, "Inspect the top spend bucket first: "+analyst.TopBuckets[0].Bucket)
	}
	for _, h := range analyst.Hypotheses[:min(2, len(analyst.Hypotheses))] {
		actions = append(actions, "Validate hypothesis: "+h.Text)
	}
	if corr != nil {
		actions = append(actions, "Review correlated infrastructure and deployment changes.")
		metrics = append(metrics, "Deployment timestamps vs cost anomaly window")
	}
	if reviewer != nil {
		for _, v := range reviewer.MissingValidations {
			actions = append(actions, v)
		}
	}
	return PlannerOutput{
		Actions: dedupe(actions),
		OwnerSuggestions: owners,
		ValidationMetrics: dedupe(metrics),
		RollbackCriteria: rollback,
	}
}

func (o *Orchestrator) runExecutiveSummary(ctx context.Context, analyst AnalystOutput, corr *CorrelationOutput, reviewer *ReviewerOutput) (ExecutiveSummaryOutput, error) {
	fallback := ExecutiveSummaryOutput{
		Headline: "Azure cost review completed.",
		TopDriver: firstBucket(analyst.TopBuckets),
		TopRisk: firstRisk(reviewer),
		NextAction: defaultNextAction(analyst),
		Confidence: firstConfidence(analyst, reviewer),
	}
	if o.llm == nil {
		return fallback, nil
	}

	payload := map[string]any{
		"analyst": analyst,
		"correlation": corr,
		"reviewer": reviewer,
	}
	b, _ := json.Marshal(payload)
	prompt := "Create a concise executive FinOps summary as JSON with keys headline, top_driver, top_risk, next_action, confidence. Data: " + string(b)
	text, err := o.llm.Respond(ctx, prompt)
	if err != nil {
		return fallback, nil
	}
	var parsed ExecutiveSummaryOutput
	if err := json.Unmarshal([]byte(text), &parsed); err != nil || parsed.Headline == "" {
		return fallback, nil
	}
	return parsed, nil
}

func buildFinalSummary(mode string, analyst AnalystOutput, corr *CorrelationOutput, reviewer *ReviewerOutput, planner *PlannerOutput) string {
	parts := []string{"Mode: " + mode + "."}
	if len(analyst.TopBuckets) > 0 {
		parts = append(parts, "Top bucket: "+analyst.TopBuckets[0].Bucket+".")
	}
	if len(analyst.Hypotheses) > 0 {
		parts = append(parts, "Likely driver: "+analyst.Hypotheses[0].Text)
	}
	if reviewer != nil && len(reviewer.TopRisks) > 0 {
		parts = append(parts, "Top risk: "+reviewer.TopRisks[0])
	}
	if planner != nil && len(planner.Actions) > 0 {
		parts = append(parts, "Next action: "+planner.Actions[0])
	}
	return strings.Join(parts, " ")
}

func firstBucket(b []BucketAmount) string {
	if len(b) == 0 { return "Unknown" }
	return b[0].Bucket
}

func firstRisk(r *ReviewerOutput) string {
	if r == nil || len(r.TopRisks) == 0 { return "Validation is still required." }
	return r.TopRisks[0]
}

func defaultNextAction(a AnalystOutput) string {
	if len(a.TopBuckets) == 0 { return "Review cost breakdown by service." }
	return "Review the top spend bucket and validate the likely driver."
}

func firstConfidence(a AnalystOutput, r *ReviewerOutput) string {
	if r != nil && r.ConfidenceAdjustment != "" { return r.ConfidenceAdjustment }
	if a.Confidence != "" { return a.Confidence }
	return "medium"
}

func coalesce(v, fallback string) string {
	if strings.TrimSpace(v) != "" { return v }
	return fallback
}

func defaultGroupBy(v string) string {
	if strings.TrimSpace(v) == "" { return "ServiceName" }
	return v
}

func dedupe(items []string) []string {
	seen := map[string]struct{}{}
	out := make([]string, 0, len(items))
	for _, item := range items {
		item = strings.TrimSpace(item)
		if item == "" { continue }
		if _, ok := seen[item]; ok { continue }
		seen[item] = struct{}{}
		out = append(out, item)
	}
	return out
}

func min(a, b int) int {
	if a < b { return a }
	return b
}
