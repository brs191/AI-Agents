package orchestrator

import "testing"

func TestNormalizeMode(t *testing.T) {
	if got := normalizeMode("forecast_review"); got != "forecast_review" {
		t.Fatalf("expected forecast_review, got %s", got)
	}
	if got := normalizeMode("something_else"); got != "anomaly_investigation" {
		t.Fatalf("expected anomaly_investigation fallback, got %s", got)
	}
}
