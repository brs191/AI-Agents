package orchestrator

type RunRequest struct {
	Mode                string   `json:"mode"`
	Question            string   `json:"question"`
	StartDate           string   `json:"start_date,omitempty"`
	EndDate             string   `json:"end_date,omitempty"`
	BaselineStartDate   string   `json:"baseline_start_date,omitempty"`
	BaselineEndDate     string   `json:"baseline_end_date,omitempty"`
	ComparisonStartDate string   `json:"comparison_start_date,omitempty"`
	ComparisonEndDate   string   `json:"comparison_end_date,omitempty"`
	GroupBy             string   `json:"group_by,omitempty"`
	RepoHints           []string `json:"repo_hints,omitempty"`
}

type AnalystOutput struct {
	FindingType string              `json:"finding_type"`
	TopBuckets  []BucketAmount      `json:"top_buckets"`
	Hypotheses  []Hypothesis        `json:"hypotheses"`
	Evidence    []string            `json:"evidence"`
	Confidence  string              `json:"confidence"`
	ToolData    map[string]any      `json:"tool_data,omitempty"`
}

type BucketAmount struct {
	Bucket   string  `json:"bucket"`
	Amount   float64 `json:"amount"`
	Currency string  `json:"currency"`
}

type Hypothesis struct {
	Text       string `json:"text"`
	Confidence string `json:"confidence"`
}

type CorrelationOutput struct {
	PossibleCorrelations []string `json:"possible_correlations"`
	EvidenceStrength     string   `json:"evidence_strength"`
	Notes                []string `json:"notes"`
}

type ReviewerOutput struct {
	Verdict              string   `json:"verdict"`
	TopRisks             []string `json:"top_risks"`
	MissingValidations   []string `json:"missing_validations"`
	ConfidenceAdjustment string   `json:"confidence_adjustment"`
}

type PlannerOutput struct {
	Actions           []string `json:"actions"`
	OwnerSuggestions  []string `json:"owner_suggestions"`
	ValidationMetrics []string `json:"validation_metrics"`
	RollbackCriteria  []string `json:"rollback_criteria"`
}

type ExecutiveSummaryOutput struct {
	Headline   string `json:"headline"`
	TopDriver  string `json:"top_driver"`
	TopRisk    string `json:"top_risk"`
	NextAction string `json:"next_action"`
	Confidence string `json:"confidence"`
}

type RunResponse struct {
	Mode             string                 `json:"mode"`
	Classification   string                 `json:"classification"`
	Analyst          *AnalystOutput         `json:"analyst,omitempty"`
	Correlation      *CorrelationOutput     `json:"correlation,omitempty"`
	Reviewer         *ReviewerOutput        `json:"reviewer,omitempty"`
	Planner          *PlannerOutput         `json:"planner,omitempty"`
	ExecutiveSummary *ExecutiveSummaryOutput `json:"executive_summary,omitempty"`
	FinalSummary     string                 `json:"final_summary"`
}
