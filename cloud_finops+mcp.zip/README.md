# Azure Cloud Cost MCP Server (Go)

A production-oriented Azure Cost Management MCP server in Go.

## Tools
- health_check
- get_cost_breakdown
- detect_cost_anomalies
- forecast_cost
- recommend_savings

## Auth
- prefers DefaultAzureCredential
- falls back to ClientSecretCredential when tenant/client/secret are set

## Run
```bash
go mod tidy
go run ./cmd/server
```
