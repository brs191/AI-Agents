package main

import (
	"context"
	"log"
	"os"
	"os/signal"
	"syscall"

	"github.com/modelcontextprotocol/go-sdk/mcp"

	"github.com/your-org/azure-cloud-cost-mcp-go/internal/azure"
	"github.com/your-org/azure-cloud-cost-mcp-go/internal/config"
	"github.com/your-org/azure-cloud-cost-mcp-go/internal/mcpserver"
	"github.com/your-org/azure-cloud-cost-mcp-go/internal/service"
)

func main() {
	cfg := config.Load()

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	client, err := azure.NewClient(cfg)
	if err != nil {
		log.Fatalf("azure client init failed: %v", err)
	}

	svc := service.New(cfg, client)
	srv := mcpserver.New(cfg, svc)

	if err := srv.Run(ctx, &mcp.StdioTransport{}); err != nil {
		log.Fatalf("mcp server failed: %v", err)
	}
}
