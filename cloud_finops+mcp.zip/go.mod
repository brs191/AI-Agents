module github.com/your-org/azure-cloud-cost-mcp-go

go 1.23.0

require (
	github.com/Azure/azure-sdk-for-go/sdk/azcore v1.17.0
	github.com/Azure/azure-sdk-for-go/sdk/azidentity v1.10.1
	github.com/modelcontextprotocol/go-sdk v1.4.1
)
