package azure

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"

	"github.com/Azure/azure-sdk-for-go/sdk/azcore"
	"github.com/Azure/azure-sdk-for-go/sdk/azidentity"

	"github.com/your-org/azure-cloud-cost-mcp-go/internal/config"
)

const armScope = "https://management.azure.com/.default"

type Client struct {
	cred azcore.TokenCredential
	http *http.Client
	cfg  config.Config
}

type QueryRequest struct {
	Type       string        `json:"type"`
	Timeframe  string        `json:"timeframe"`
	TimePeriod QueryPeriod   `json:"timePeriod"`
	Dataset    QueryDataset  `json:"dataset"`
}

type QueryPeriod struct {
	From string `json:"from"`
	To   string `json:"to"`
}

type QueryDataset struct {
	Granularity string                   `json:"granularity"`
	Aggregation map[string]Aggregation   `json:"aggregation"`
	Grouping    []Grouping               `json:"grouping,omitempty"`
}

type Aggregation struct {
	Name     string `json:"name"`
	Function string `json:"function"`
}

type Grouping struct {
	Type string `json:"type"`
	Name string `json:"name"`
}

type QueryResponse struct {
	Properties struct {
		Columns []struct {
			Name string `json:"name"`
			Type string `json:"type"`
		} `json:"columns"`
		Rows [][]any `json:"rows"`
	} `json:"properties"`
}

func NewClient(cfg config.Config) (*Client, error) {
	if cfg.AzureCostScope == "" {
		return nil, fmt.Errorf("AZURE_COST_SCOPE is required")
	}

	var (
		cred azcore.TokenCredential
		err error
	)
	if cfg.AzureTenantID != "" && cfg.AzureClientID != "" && cfg.AzureClientSecret != "" {
		cred, err = azidentity.NewClientSecretCredential(cfg.AzureTenantID, cfg.AzureClientID, cfg.AzureClientSecret, nil)
	} else {
		cred, err = azidentity.NewDefaultAzureCredential(nil)
	}
	if err != nil {
		return nil, fmt.Errorf("create credential: %w", err)
	}

	return &Client{
		cred: cred,
		http: &http.Client{Timeout: cfg.QueryTimeout},
		cfg:  cfg,
	}, nil
}

func (c *Client) Query(ctx context.Context, body QueryRequest) (QueryResponse, error) {
	var out QueryResponse
	url := fmt.Sprintf("https://management.azure.com%s/providers/Microsoft.CostManagement/query?api-version=%s", c.cfg.AzureCostScope, c.cfg.AzureAPIVersion)
	if err := c.post(ctx, url, body, &out); err != nil {
		return QueryResponse{}, err
	}
	return out, nil
}

func (c *Client) Forecast(ctx context.Context, body QueryRequest) (QueryResponse, error) {
	var out QueryResponse
	url := fmt.Sprintf("https://management.azure.com%s/providers/Microsoft.CostManagement/forecast?api-version=%s", c.cfg.AzureCostScope, c.cfg.AzureAPIVersion)
	if err := c.post(ctx, url, body, &out); err != nil {
		return QueryResponse{}, err
	}
	return out, nil
}

func (c *Client) post(ctx context.Context, url string, body any, out any) error {
	tok, err := c.cred.GetToken(ctx, azcore.TokenRequestOptions{Scopes: []string{armScope}})
	if err != nil {
		return fmt.Errorf("get token: %w", err)
	}

	payload, err := json.Marshal(body)
	if err != nil {
		return fmt.Errorf("marshal request: %w", err)
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, url, bytes.NewReader(payload))
	if err != nil {
		return fmt.Errorf("build request: %w", err)
	}
	req.Header.Set("Authorization", "Bearer "+tok.Token)
	req.Header.Set("Content-Type", "application/json")

	resp, err := c.http.Do(req)
	if err != nil {
		return fmt.Errorf("call azure api: %w", err)
	}
	defer resp.Body.Close()

	b, err := io.ReadAll(resp.Body)
	if err != nil {
		return fmt.Errorf("read response: %w", err)
	}
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("azure api status %d: %s", resp.StatusCode, string(b))
	}
	if err := json.Unmarshal(b, out); err != nil {
		return fmt.Errorf("unmarshal response: %w", err)
	}
	return nil
}
