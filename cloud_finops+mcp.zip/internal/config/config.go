package config

import (
	"os"
	"time"
)

type Config struct {
	ServerName        string
	ServerVersion     string
	AzureCostScope    string
	AzureAPIVersion   string
	QueryTimeout      time.Duration
	DefaultCurrency   string
	AzureTenantID     string
	AzureClientID     string
	AzureClientSecret string
}

func Load() Config {
	return Config{
		ServerName:        getenv("MCP_SERVER_NAME", "azure-cloud-cost-intelligence"),
		ServerVersion:     getenv("MCP_SERVER_VERSION", "0.1.0"),
		AzureCostScope:    getenv("AZURE_COST_SCOPE", ""),
		AzureAPIVersion:   getenv("AZURE_API_VERSION", "2025-03-01"),
		QueryTimeout:      getDuration("QUERY_TIMEOUT", 20*time.Second),
		DefaultCurrency:   getenv("DEFAULT_CURRENCY", "USD"),
		AzureTenantID:     getenv("AZURE_TENANT_ID", ""),
		AzureClientID:     getenv("AZURE_CLIENT_ID", ""),
		AzureClientSecret: getenv("AZURE_CLIENT_SECRET", ""),
	}
}

func getenv(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

func getDuration(key string, fallback time.Duration) time.Duration {
	if v := os.Getenv(key); v != "" {
		d, err := time.ParseDuration(v)
		if err == nil {
			return d
		}
	}
	return fallback
}
