package mcpserver

import (
	"context"

	"github.com/modelcontextprotocol/go-sdk/mcp"

	"github.com/your-org/azure-cloud-cost-mcp-go/internal/config"
	"github.com/your-org/azure-cloud-cost-mcp-go/internal/models"
	"github.com/your-org/azure-cloud-cost-mcp-go/internal/service"
)

func New(cfg config.Config, svc *service.Service) *mcp.Server {
	server := mcp.NewServer(&mcp.Implementation{Name: cfg.ServerName, Version: cfg.ServerVersion}, nil)

	mcp.AddTool(server, &mcp.Tool{Name: "health_check", Description: "Check Azure Cost Management connectivity and capabilities."},
		func(ctx context.Context, _ *mcp.CallToolRequest, _ struct{}) (*mcp.CallToolResult, models.HealthOutput, error) {
			out, err := svc.Health(ctx)
			return nil, out, err
		})

	mcp.AddTool(server, &mcp.Tool{Name: "get_cost_breakdown", Description: "Return Azure cost breakdown for a scope, time range, granularity, and grouping dimension."},
		func(ctx context.Context, _ *mcp.CallToolRequest, in models.CostBreakdownInput) (*mcp.CallToolResult, models.CostBreakdownOutput, error) {
			out, err := svc.CostBreakdown(ctx, in)
			return nil, out, err
		})

	mcp.AddTool(server, &mcp.Tool{Name: "detect_cost_anomalies", Description: "Compare two periods and return the largest Azure cost deltas."},
		func(ctx context.Context, _ *mcp.CallToolRequest, in models.CostAnomalyInput) (*mcp.CallToolResult, models.CostAnomalyOutput, error) {
			out, err := svc.DetectAnomalies(ctx, in)
			return nil, out, err
		})

	mcp.AddTool(server, &mcp.Tool{Name: "forecast_cost", Description: "Return Azure Cost Management forecast for a scope and time range."},
		func(ctx context.Context, _ *mcp.CallToolRequest, in models.ForecastInput) (*mcp.CallToolResult, models.ForecastOutput, error) {
			out, err := svc.Forecast(ctx, in)
			return nil, out, err
		})

	mcp.AddTool(server, &mcp.Tool{Name: "recommend_savings", Description: "Return heuristic Azure cost savings recommendations."},
		func(ctx context.Context, _ *mcp.CallToolRequest, in models.SavingsInput) (*mcp.CallToolResult, models.SavingsOutput, error) {
			out, err := svc.RecommendSavings(ctx, in)
			return nil, out, err
		})

	return server
}
