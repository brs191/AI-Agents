package models

type HealthOutput struct {
	Provider     string   `json:"provider"`
	Scope        string   `json:"scope"`
	APIEnabled   bool     `json:"api_enabled"`
	QueryTimeout string   `json:"query_timeout"`
	Capabilities []string `json:"capabilities"`
	Notes        []string `json:"notes,omitempty"`
}

type CostBreakdownInput struct {
	StartDate   string `json:"start_date"`
	EndDate     string `json:"end_date"`
	Granularity string `json:"granularity,omitempty"`
	GroupBy     string `json:"group_by,omitempty"`
}

type BreakdownEntry struct {
	Bucket    string  `json:"bucket"`
	Amount    float64 `json:"amount"`
	Currency  string  `json:"currency"`
}

type CostBreakdownOutput struct {
	Provider    string           `json:"provider"`
	Scope       string           `json:"scope"`
	Granularity string           `json:"granularity"`
	GroupBy     string           `json:"group_by"`
	TotalAmount float64          `json:"total_amount"`
	Currency    string           `json:"currency"`
	Entries     []BreakdownEntry `json:"entries"`
	Notes       []string         `json:"notes,omitempty"`
}

type CostAnomalyInput struct {
	BaselineStartDate   string `json:"baseline_start_date"`
	BaselineEndDate     string `json:"baseline_end_date"`
	ComparisonStartDate string `json:"comparison_start_date"`
	ComparisonEndDate   string `json:"comparison_end_date"`
	GroupBy             string `json:"group_by,omitempty"`
}

type CostDelta struct {
	Bucket         string  `json:"bucket"`
	BaselineAmount float64 `json:"baseline_amount"`
	CurrentAmount  float64 `json:"current_amount"`
	AbsoluteDelta  float64 `json:"absolute_delta"`
	PercentDelta   float64 `json:"percent_delta"`
	Currency       string  `json:"currency"`
}

type CostAnomalyOutput struct {
	Provider  string      `json:"provider"`
	Scope     string      `json:"scope"`
	GroupBy   string      `json:"group_by"`
	TopDeltas []CostDelta `json:"top_deltas"`
	Summary   []string    `json:"summary"`
}

type ForecastInput struct {
	StartDate   string `json:"start_date"`
	EndDate     string `json:"end_date"`
	Granularity string `json:"granularity,omitempty"`
}

type ForecastOutput struct {
	Provider    string   `json:"provider"`
	Scope       string   `json:"scope"`
	Amount      float64  `json:"amount"`
	Currency    string   `json:"currency"`
	Granularity string   `json:"granularity"`
	Notes       []string `json:"notes,omitempty"`
}

type SavingsInput struct {
	StartDate string `json:"start_date"`
	EndDate   string `json:"end_date"`
	GroupBy   string `json:"group_by,omitempty"`
}

type SavingsRecommendation struct {
	Title            string   `json:"title"`
	EstimatedSavings float64  `json:"estimated_savings"`
	Currency         string   `json:"currency"`
	Confidence       string   `json:"confidence"`
	Reasoning        []string `json:"reasoning"`
	SuggestedAction  []string `json:"suggested_action"`
}

type SavingsOutput struct {
	Provider        string                  `json:"provider"`
	Scope           string                  `json:"scope"`
	Recommendations []SavingsRecommendation `json:"recommendations"`
	Notes           []string                `json:"notes,omitempty"`
}
