package service

import (
	"context"
	"fmt"
	"sort"
	"strconv"
	"strings"

	"github.com/your-org/azure-cloud-cost-mcp-go/internal/azure"
	"github.com/your-org/azure-cloud-cost-mcp-go/internal/config"
	"github.com/your-org/azure-cloud-cost-mcp-go/internal/models"
)

type Service struct {
	cfg config.Config
	az  *azure.Client
}

func New(cfg config.Config, az *azure.Client) *Service { return &Service{cfg: cfg, az: az} }

func (s *Service) Health(ctx context.Context) (models.HealthOutput, error) {
	_, err := s.az.Query(ctx, buildRequest("2026-01-01", "2026-01-02", "None", "ServiceName"))
	if err != nil {
		return models.HealthOutput{}, err
	}
	return models.HealthOutput{
		Provider: "azure",
		Scope: s.cfg.AzureCostScope,
		APIEnabled: true,
		QueryTimeout: s.cfg.QueryTimeout.String(),
		Capabilities: []string{"cost_breakdown", "forecast", "delta_anomaly_detection", "savings_recommendations"},
		Notes: []string{"Uses Azure Cost Management Query and Forecast endpoints."},
	}, nil
}

func (s *Service) CostBreakdown(ctx context.Context, in models.CostBreakdownInput) (models.CostBreakdownOutput, error) {
	granularity := normalizeGranularity(in.Granularity)
	groupBy := normalizeGroupBy(in.GroupBy)
	resp, err := s.az.Query(ctx, buildRequest(in.StartDate, in.EndDate, granularity, groupBy))
	if err != nil {
		return models.CostBreakdownOutput{}, err
	}
	entries, total, currency := parseRows(resp.Properties.Columns, resp.Properties.Rows, s.cfg.DefaultCurrency)
	sort.Slice(entries, func(i, j int) bool { return entries[i].Amount > entries[j].Amount })
	return models.CostBreakdownOutput{
		Provider: "azure",
		Scope: s.cfg.AzureCostScope,
		Granularity: granularity,
		GroupBy: groupBy,
		TotalAmount: total,
		Currency: currency,
		Entries: entries,
		Notes: []string{"Billing data freshness depends on Azure Cost Management update latency."},
	}, nil
}

func (s *Service) DetectAnomalies(ctx context.Context, in models.CostAnomalyInput) (models.CostAnomalyOutput, error) {
	groupBy := normalizeGroupBy(in.GroupBy)
	base, err := s.CostBreakdown(ctx, models.CostBreakdownInput{StartDate: in.BaselineStartDate, EndDate: in.BaselineEndDate, Granularity: "None", GroupBy: groupBy})
	if err != nil { return models.CostAnomalyOutput{}, err }
	cmp, err := s.CostBreakdown(ctx, models.CostBreakdownInput{StartDate: in.ComparisonStartDate, EndDate: in.ComparisonEndDate, Granularity: "None", GroupBy: groupBy})
	if err != nil { return models.CostAnomalyOutput{}, err }

	baseMap := map[string]models.BreakdownEntry{}
	for _, e := range base.Entries { baseMap[e.Bucket] = e }

	deltas := make([]models.CostDelta, 0, len(cmp.Entries))
	for _, cur := range cmp.Entries {
		prev := baseMap[cur.Bucket]
		abs := cur.Amount - prev.Amount
		pct := 0.0
		if prev.Amount != 0 { pct = (abs / prev.Amount) * 100 }
		deltas = append(deltas, models.CostDelta{Bucket: cur.Bucket, BaselineAmount: prev.Amount, CurrentAmount: cur.Amount, AbsoluteDelta: abs, PercentDelta: pct, Currency: cur.Currency})
	}
	sort.Slice(deltas, func(i, j int) bool { return deltas[i].AbsoluteDelta > deltas[j].AbsoluteDelta })
	if len(deltas) > 10 { deltas = deltas[:10] }

	summary := []string{}
	for _, d := range deltas[:min(3, len(deltas))] {
		summary = append(summary, fmt.Sprintf("%s changed by %.2f %s (%.1f%%).", d.Bucket, d.AbsoluteDelta, d.Currency, d.PercentDelta))
	}
	return models.CostAnomalyOutput{Provider: "azure", Scope: s.cfg.AzureCostScope, GroupBy: groupBy, TopDeltas: deltas, Summary: summary}, nil
}

func (s *Service) Forecast(ctx context.Context, in models.ForecastInput) (models.ForecastOutput, error) {
	granularity := normalizeGranularity(in.Granularity)
	resp, err := s.az.Forecast(ctx, buildRequest(in.StartDate, in.EndDate, granularity, "ServiceName"))
	if err != nil { return models.ForecastOutput{}, err }
	_, total, currency := parseRows(resp.Properties.Columns, resp.Properties.Rows, s.cfg.DefaultCurrency)
	return models.ForecastOutput{Provider: "azure", Scope: s.cfg.AzureCostScope, Amount: total, Currency: currency, Granularity: granularity, Notes: []string{"Forecast is provider-generated and should be validated against recent workload changes."}}, nil
}

func (s *Service) RecommendSavings(ctx context.Context, in models.SavingsInput) (models.SavingsOutput, error) {
	breakdown, err := s.CostBreakdown(ctx, models.CostBreakdownInput{StartDate: in.StartDate, EndDate: in.EndDate, Granularity: "None", GroupBy: normalizeGroupBy(in.GroupBy)})
	if err != nil { return models.SavingsOutput{}, err }

	recs := []models.SavingsRecommendation{}
	if len(breakdown.Entries) > 0 {
		top := breakdown.Entries[0]
		recs = append(recs, models.SavingsRecommendation{
			Title: "Review highest-spend bucket first",
			EstimatedSavings: top.Amount * 0.10,
			Currency: top.Currency,
			Confidence: "medium",
			Reasoning: []string{
				fmt.Sprintf("%s is the largest cost bucket in the selected period.", top.Bucket),
				"Concentrated spend often provides the fastest optimization return.",
			},
			SuggestedAction: []string{
				"Review rightsizing and commitment opportunities for this bucket.",
				"Compare this bucket with deployment and traffic changes in the same period.",
			},
		})
	}
	for _, e := range breakdown.Entries {
		name := strings.ToLower(e.Bucket)
		if strings.Contains(name, "network") || strings.Contains(name, "bandwidth") || strings.Contains(name, "data transfer") {
			recs = append(recs, models.SavingsRecommendation{
				Title: "Investigate network and egress optimization",
				EstimatedSavings: e.Amount * 0.15,
				Currency: e.Currency,
				Confidence: "low",
				Reasoning: []string{"Network and egress costs often contain avoidable spend from cross-region traffic or chatty services."},
				SuggestedAction: []string{"Review CDN and caching coverage.", "Check cross-region traffic and service-to-service payload sizes."},
			})
			break
		}
	}
	if len(recs) == 0 {
		recs = append(recs, models.SavingsRecommendation{
			Title: "Start with service-level concentration analysis",
			EstimatedSavings: breakdown.TotalAmount * 0.05,
			Currency: breakdown.Currency,
			Confidence: "low",
			Reasoning: []string{"No stronger category-specific heuristic triggered from the selected grouping."},
			SuggestedAction: []string{"Re-run with ServiceName grouping and compare with ResourceGroupName or Location."},
		})
	}
	return models.SavingsOutput{Provider: "azure", Scope: s.cfg.AzureCostScope, Recommendations: recs, Notes: []string{"Estimated savings are heuristic and not guaranteed."}}, nil
}

func buildRequest(startDate, endDate, granularity, groupBy string) azure.QueryRequest {
	req := azure.QueryRequest{
		Type: "Usage",
		Timeframe: "Custom",
		TimePeriod: azure.QueryPeriod{From: startDate + "T00:00:00Z", To: endDate + "T00:00:00Z"},
		Dataset: azure.QueryDataset{
			Granularity: granularity,
			Aggregation: map[string]azure.Aggregation{"totalCost": {Name: "PreTaxCost", Function: "Sum"}},
		},
	}
	if groupBy != "" {
		req.Dataset.Grouping = []azure.Grouping{{Type: "Dimension", Name: groupBy}}
	}
	return req
}

func normalizeGranularity(v string) string {
	switch strings.ToLower(strings.TrimSpace(v)) {
	case "daily":
		return "Daily"
	case "none":
		return "None"
	default:
		return "Monthly"
	}
}

func normalizeGroupBy(v string) string {
	if strings.TrimSpace(v) == "" { return "ServiceName" }
	return strings.TrimSpace(v)
}

func parseRows(cols []struct{Name string `json:"name"`; Type string `json:"type"`}, rows [][]any, defaultCurrency string) ([]models.BreakdownEntry, float64, string) {
	idxCost, idxGroup, idxCurrency := -1, -1, -1
	for i, c := range cols {
		switch strings.ToLower(c.Name) {
		case "pretaxcost", "cost", "costusd", "costinbillingcurrency":
			idxCost = i
		case "currency":
			idxCurrency = i
		default:
			if idxGroup == -1 && c.Name != "Currency" { idxGroup = i }
		}
	}
	entries := make([]models.BreakdownEntry, 0, len(rows))
	total := 0.0
	currency := defaultCurrency
	for _, row := range rows {
		amount := cellFloat(row, idxCost)
		bucket := cellString(row, idxGroup, "Unknown")
		cur := cellString(row, idxCurrency, defaultCurrency)
		if cur != "" { currency = cur }
		entries = append(entries, models.BreakdownEntry{Bucket: bucket, Amount: amount, Currency: cur})
		total += amount
	}
	return entries, total, currency
}

func cellFloat(row []any, idx int) float64 {
	if idx < 0 || idx >= len(row) { return 0 }
	switch v := row[idx].(type) {
	case float64:
		return v
	case string:
		f, _ := strconv.ParseFloat(v, 64)
		return f
	default:
		return 0
	}
}

func cellString(row []any, idx int, fallback string) string {
	if idx < 0 || idx >= len(row) { return fallback }
	if s, ok := row[idx].(string); ok && strings.TrimSpace(s) != "" { return s }
	return fallback
}

func min(a, b int) int { if a < b { return a }; return b }
