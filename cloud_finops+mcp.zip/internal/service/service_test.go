package service

import "testing"

func TestNormalizeGranularity(t *testing.T) {
	if got := normalizeGranularity("daily"); got != "Daily" {
		t.Fatalf("expected Daily, got %s", got)
	}
	if got := normalizeGranularity(""); got != "Monthly" {
		t.Fatalf("expected Monthly, got %s", got)
	}
}

func TestNormalizeGroupBy(t *testing.T) {
	if got := normalizeGroupBy(""); got != "ServiceName" {
		t.Fatalf("expected ServiceName, got %s", got)
	}
}
