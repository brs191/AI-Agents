---
applyTo: "**"
---
# Project guidance for Azure OpenAI-powered FinOps work

- This workspace is specialized for Azure FinOps workflows grounded in the Azure Cloud Cost MCP server.
- For spend questions, always use MCP tools before relying on heuristics.
- Separate observations, inferences, and recommendations.
- When recommending savings, explain:
  - what spend bucket is driving the recommendation
  - expected confidence
  - likely operational trade-offs
  - validation steps before action
- Be careful with anomalies and forecasts because cloud billing data can lag.
- If the task involves infrastructure or code, inspect the workspace for deployment, scaling, caching, networking, and data-transfer clues.
- Keep summaries concrete and executive-friendly when asked.
- Avoid overconfident ROI claims.
