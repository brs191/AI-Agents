---
name: azure-finops
description: Use this skill for Azure cost breakdown, anomalies, forecasts, and savings analysis using the Azure Cloud Cost MCP server.
argument-hint: [Azure FinOps question]
user-invocable: true
---

# Azure FinOps Skill

Use this skill for:
- explaining Azure spend
- comparing spend across periods
- identifying anomalies
- discussing forecasts
- recommending savings opportunities
- building executive summaries

## Required procedure
1. Start with MCP facts.
   - use `get_cost_breakdown` for composition
   - use `detect_cost_anomalies` for deltas
   - use `forecast_cost` for forward-looking analysis
   - use `recommend_savings` for advisory options
2. Summarize findings clearly.
3. State confidence and trade-offs.
4. End with a validation plan.
5. If repository context matters, inspect infrastructure and deployment changes carefully.

## Heuristics
- concentrated spend often provides the best first optimization target
- network and egress costs often justify architecture and caching review
- anomaly analysis should be framed as period-over-period change, not absolute proof of causation
- forecasts depend on provider freshness and recent workload changes

## Example prompts
- `Explain the top Azure spend drivers this month.`
- `Compare this month vs last month and summarize the biggest cost anomalies.`
- `Recommend the safest high-impact savings opportunities.`
- `Prepare a CTO-ready FinOps summary with confidence levels.`
