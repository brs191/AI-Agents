# Example: anomaly review prompt

Prompt:
`Compare this month vs last month and explain the biggest cost anomaly.`

Expected behavior:
1. Run anomaly comparison.
2. Summarize top deltas.
3. Explain likely causes cautiously.
4. Recommend validation steps.
