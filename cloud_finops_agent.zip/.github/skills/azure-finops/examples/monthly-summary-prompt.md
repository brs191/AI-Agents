# Example: monthly summary prompt

Prompt:
`Use the Azure cost MCP server to summarize this month's spend, the main driver, and the safest next action.`

Expected behavior:
1. Get cost breakdown.
2. Summarize the main spend concentration.
3. Recommend the best next review.
4. State confidence and validation steps.
