# Azure OpenAI-powered FinOps Agent Workspace for VS Code

This workspace is designed for **VS Code agent mode** and is optimized to work with:

- an **Azure Cloud Cost MCP Server**
- **Azure OpenAI** deployments
- FinOps investigation and recommendation workflows
- code + cloud cost correlation inside the IDE

## What is included

- `.vscode/mcp.json` to register the Azure Cost MCP server
- `AGENTS.md` for workspace-wide operating rules
- `.github/copilot-instructions.md` for always-on FinOps guidance
- custom agents:
  - `azure-finops-analyst`
  - `azure-finops-reviewer`
  - `azure-finops-implementation-planner`
- reusable FinOps skill files
- helper scripts to launch and verify the MCP server
- `.env.example` for local environment setup
- prompt files for common FinOps tasks

## Assumptions

This workspace assumes the Azure Cloud Cost MCP server repo exists locally and can run with:

```bash
go run ./cmd/server
```

By default, the launcher script expects the server at:

```text
../azure-cloud-cost-mcp-go
```

Override with:
```bash
export MCP_SERVER_DIR=/path/to/azure-cloud-cost-mcp-go
```

## Quick start

1. Open this folder in VS Code.
2. Enable agent mode.
3. Make sure your Azure Cloud Cost MCP server repo exists locally.
4. Copy `.env.example` to `.env` if you want local environment help.
5. Run:

```bash
chmod +x ./scripts/*.sh
./scripts/check-server.sh
```

6. Open chat in Agent mode and choose `azure-finops-analyst`.
7. When prompted by `.vscode/mcp.json`, provide:
   - `AZURE_COST_SCOPE`
   - whether to use API key or Entra-backed server auth path
   - your Azure OpenAI endpoint/deployment details if you also use the helper scripts

## Suggested prompts

- `Use the Azure cost MCP server to explain the top spend drivers this month.`
- `Compare this month vs last month and identify the top cost anomalies.`
- `Recommend the safest high-impact savings opportunities for this subscription.`
- `Correlate these cost changes with recent deployment or traffic changes in the codebase.`
- `Prepare an executive FinOps summary with confidence levels and next steps.`

## Notes

This workspace is intentionally opinionated:
- prefer MCP facts before recommendations
- separate facts, inferences, and advice
- recommend staged validation before automation
- call out scope, data freshness, and confidence limits
