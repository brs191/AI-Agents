# Engineering Cost Investigation

Use MCP first, then inspect the repository.
Explain:
- what spend bucket is changing
- which engineering or infrastructure changes could plausibly relate
- what should be validated next
- the safest optimization plan
