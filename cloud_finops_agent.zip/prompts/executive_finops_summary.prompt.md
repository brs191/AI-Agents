# Executive FinOps Summary

Use the Azure cost MCP server to produce an executive summary with:
- current top spend drivers
- largest period-over-period anomaly
- top 3 savings opportunities
- confidence level for each
- recommended next step this week
