#!/usr/bin/env bash
set -euo pipefail

echo "Checking Go..."
go version

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
SERVER_DIR="${MCP_SERVER_DIR:-$ROOT_DIR/../azure-cloud-cost-mcp-go}"

if [[ ! -d "$SERVER_DIR" ]]; then
  echo "Missing server directory: $SERVER_DIR" >&2
  echo "Set MCP_SERVER_DIR to your Azure Cloud Cost MCP server folder." >&2
  exit 1
fi

test -f "$SERVER_DIR/cmd/server/main.go"
echo "Server sources found: $SERVER_DIR"
echo "Open VS Code and let MCP start from .vscode/mcp.json."
