#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
SERVER_DIR="${MCP_SERVER_DIR:-$ROOT_DIR/../azure-cloud-cost-mcp-go}"

if [[ ! -d "$SERVER_DIR" ]]; then
  echo "MCP server directory not found: $SERVER_DIR" >&2
  echo "Set MCP_SERVER_DIR to the Azure Cloud Cost MCP server repo path." >&2
  exit 1
fi

cd "$SERVER_DIR"
exec go run ./cmd/server
