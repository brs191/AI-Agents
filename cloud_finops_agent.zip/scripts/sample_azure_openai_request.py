import os
import requests

endpoint = os.environ["AZURE_OPENAI_ENDPOINT"].rstrip("/")
deployment = os.environ["AZURE_OPENAI_DEPLOYMENT"]
api_key = os.environ["AZURE_OPENAI_API_KEY"]
api_version = os.environ.get("AZURE_OPENAI_API_VERSION", "preview")

url = f"{endpoint}/openai/v1/responses?api-version={api_version}"

payload = {
    "model": deployment,
    "input": "Summarize the top three Azure cost optimization opportunities for this month.",
}

headers = {
    "api-key": api_key,
    "Content-Type": "application/json",
}

resp = requests.post(url, headers=headers, json=payload, timeout=60)
resp.raise_for_status()
print(resp.json())
