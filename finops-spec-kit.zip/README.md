# FinOps Platform Spec Kit

This repo provides a spec-driven structure for your Azure FinOps platform with concrete specs for:
- Azure Cost MCP
- LangGraph Orchestrator
- Enterprise Azure Deployment

## Structure

```text
finops-spec-kit/
├── specs/
│   ├── azure-cost-mcp/
│   │   ├── spec.md
│   │   ├── plan.md
│   │   └── tasks.md
│   ├── langgraph-orchestrator/
│   │   ├── spec.md
│   │   ├── plan.md
│   │   └── tasks.md
│   └── enterprise-azure-deployment/
│       ├── spec.md
│       ├── plan.md
│       └── tasks.md
├── principles/
│   └── engineering-principles.md
├── templates/
│   ├── spec-template.md
│   ├── plan-template.md
│   └── tasks-template.md
└── README.md
```

## Workflow
1. Define business and platform requirements in `spec.md`.
2. Translate them into architecture and delivery choices in `plan.md`.
3. Break delivery into reviewable tasks in `tasks.md`.
