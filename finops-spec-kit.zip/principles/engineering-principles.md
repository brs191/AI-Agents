# Engineering Principles

## Platform principles
1. MCP servers are the source of truth for tool-based external data access.
2. Orchestration must remain separate from provider integrations.
3. Cloud-facing services are read-only by default unless explicitly approved.
4. Production changes require observability, auditability, and rollback paths.
5. Security is identity-first: Entra ID, managed identity, RBAC, Key Vault.
6. Agent recommendations are advisory unless validated and explicitly approved.
7. Cost, performance, and reliability trade-offs must be made explicit.
