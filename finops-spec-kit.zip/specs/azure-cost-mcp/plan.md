# Plan: Azure Cost MCP

## Architecture overview
A Go MCP server exposing Azure Cost Management capabilities over stdio or service wrapper transport, with Azure auth handled via Azure Identity libraries.

## Components
- MCP server entrypoint
- Azure auth module
- Cost Management query client
- forecast client
- response parser / normalizer
- heuristic recommendation engine
- MCP tool registry

## Data flow
1. Client / agent calls MCP tool.
2. Tool validates inputs.
3. Azure credential is resolved.
4. Query or forecast request is sent to Azure management endpoint.
5. Response is normalized into typed output.
6. MCP tool returns structured content.

## Interfaces and contracts
### Input contracts
- ISO-like dates
- supported grouping dimensions
- scope supplied through environment or service config

### Output contracts
- provider
- scope
- granularity
- currency
- entries or deltas
- notes / confidence caveats

## Security model
- DefaultAzureCredential in Azure-hosted production
- service principal only for non-Azure hosting or controlled integration
- Key Vault for secrets where explicit credentials are required
- RBAC scoped only to allowed cost scopes

## Observability model
- structured JSON logs
- request IDs
- tool invocation metrics
- Azure API latency metrics
- error cardinality by tool and status family

## Scaling strategy
- stateless service
- horizontal scale behind container runtime
- cache safe repeat queries if later needed
- no local persistent state required

## Failure handling
- translate Azure permission and scope failures into readable errors
- return explicit notes for stale or limited forecast confidence
- timeout guard on external calls

## Deployment strategy
- container image
- Azure Container Apps or AKS initially
- managed identity preferred
- config injected by environment / Key Vault references

## Test strategy
- unit tests for parsing and normalization
- contract tests for MCP tool outputs
- integration tests against mocked Azure responses
- smoke test against a real scope in non-production

## Rollout and rollback
- release behind environment-specific scopes
- smoke-test tools after deploy
- rollback by previous image revision if failures exceed threshold
