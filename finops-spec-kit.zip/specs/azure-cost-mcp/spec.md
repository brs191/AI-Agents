# Spec: Azure Cost MCP

## Objective
Provide a production-grade Azure Cloud Cost MCP server that gives agents safe, structured, read-only access to Azure cost intelligence.

## Business outcome
Enable AI agents and engineers to:
- explain Azure spend drivers
- compare spend across periods
- identify anomalies
- retrieve forecasts
- recommend likely savings opportunities

## Primary users
- FinOps analysts
- platform engineering
- SRE / cloud operations
- engineering leadership
- AI agents using MCP

## User scenarios
1. As a FinOps analyst, I want month-over-month cost comparison by service so I can identify major changes.
2. As an engineering leader, I want a forecast for the next billing period so I can anticipate risk.
3. As an AI agent, I want structured cost tool outputs so I can produce grounded recommendations.
4. As a platform engineer, I want safe, read-only access so the system cannot mutate Azure resources.

## Functional requirements
1. Expose MCP tools:
   - `health_check`
   - `get_cost_breakdown`
   - `detect_cost_anomalies`
   - `forecast_cost`
   - `recommend_savings`
2. Support Azure Cost Management scope input:
   - subscription
   - resource group
   - management group
3. Support configurable grouping dimension with sensible defaults.
4. Return structured JSON payloads suitable for agent consumption.
5. Use Azure token-based authentication.
6. Support DefaultAzureCredential and optional service principal auth.
7. Keep all operations read-only.

## Non-functional requirements
- response timeout configurable
- typed outputs
- deterministic tool behavior
- containerizable
- production logging
- auditable request path
- graceful error handling for scope and permission failures

## Security and compliance constraints
- authentication must use Entra ID compatible paths
- secrets must never be hardcoded
- secrets should be sourced from Key Vault or secure environment injection
- least privilege access must be enforced
- requests and errors must avoid leaking credentials or raw sensitive secrets

## Success metrics
- 95% of supported requests succeed within target timeout under normal Azure API health
- tool outputs are parseable by orchestrator without manual intervention
- no write-capable Azure actions exist in the service
- production deployment can be monitored and audited

## Risks
- Azure billing data freshness lag
- insufficient RBAC on cost scopes
- confusion between forecast signals and actual billed values
- overinterpretation of heuristic savings estimates

## Out of scope
- auto-remediation
- direct resource shutdown / resize
- multi-cloud provider support in this service
