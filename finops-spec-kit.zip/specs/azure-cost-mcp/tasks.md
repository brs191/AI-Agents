# Tasks: Azure Cost MCP

## Phase 1: Core service
- [ ] Implement MCP server bootstrap and tool registry
- [ ] Implement Azure credential resolution
- [ ] Implement Cost Management Query client
- [ ] Implement Forecast client
- [ ] Implement typed output models
- [ ] Implement read-only safety guarantees

## Phase 2: Quality and operations
- [ ] Add structured logging
- [ ] Add request correlation IDs
- [ ] Add timeout and retry policy
- [ ] Add error normalization for auth / scope / API failures
- [ ] Containerize service

## Phase 3: Validation
- [ ] Write parser and normalization unit tests
- [ ] Write MCP tool contract tests
- [ ] Run non-production integration test against real Azure scope
- [ ] Validate managed identity and service principal paths

## Release readiness
- [ ] Confirm RBAC scope permissions
- [ ] Confirm Key Vault secret wiring if needed
- [ ] Confirm monitoring dashboards and alerts
- [ ] Document supported scopes, dimensions, and limitations
