# Tasks: Enterprise Azure Deployment

## Phase 1: Core infrastructure
- [ ] Define Azure landing zone assumptions
- [ ] Provision resource groups / subscriptions strategy
- [ ] Provision Key Vault
- [ ] Provision Container Apps or AKS environment
- [ ] Provision Log Analytics workspace
- [ ] Provision APIM or ingress layer

## Phase 2: Identity and security
- [ ] Create managed identities for services
- [ ] Configure RBAC scopes for Azure Cost access
- [ ] Configure Key Vault access policies / RBAC
- [ ] Validate secret references and rotation path
- [ ] Define network access model and private endpoint requirements

## Phase 3: Application deployment
- [ ] Deploy Azure Cost MCP service
- [ ] Deploy LangGraph orchestrator runtime
- [ ] Configure environment-specific settings
- [ ] Configure health probes and autoscaling
- [ ] Configure monitoring dashboards and alerts

## Phase 4: Validation
- [ ] Run non-production smoke tests
- [ ] Validate end-to-end orchestrator -> MCP -> Azure path
- [ ] Validate auth failure and timeout behavior
- [ ] Run rollback drill

## Release readiness
- [ ] Confirm production SLOs / SLIs
- [ ] Confirm alert routing and on-call ownership
- [ ] Confirm runbooks and incident procedures
- [ ] Confirm architecture and security review sign-off
