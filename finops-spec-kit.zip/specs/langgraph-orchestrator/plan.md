# Plan: LangGraph Orchestrator

## Architecture overview
Python FastAPI runtime using LangGraph for stateful workflow control, MCP adapters for tool access, and optional Azure OpenAI for summarization.

## Components
- FastAPI entrypoint
- request / response models
- LangGraph state graph
- MCP tool adapter client
- optional Azure OpenAI wrapper
- deterministic fallback summarizer

## Data flow
1. API receives workflow request.
2. Graph classifies mode.
3. Analyst node calls Azure Cost MCP tools.
4. Correlation node interprets repo hints or later connector data.
5. Reviewer node validates risks and confidence.
6. Planner node builds action sequence and validation metrics.
7. Executive node generates concise summary.
8. Runtime returns consolidated response.

## Interfaces and contracts
### Inbound
- workflow mode
- question
- time windows
- grouping
- repo hints

### Outbound
- stage-level outputs
- final summary
- confidence statement
- validation guidance

## Security model
- Azure credentials live with the MCP server, not inside orchestration logic when possible
- Azure OpenAI key or identity managed securely
- no direct Azure billing API calls from graph nodes if MCP is available

## Observability model
- per-node timing
- workflow mode metrics
- tool call success/failure counters
- request correlation IDs
- graph execution logs

## Scaling strategy
- stateless API service
- horizontal scale across multiple instances
- later: persistent checkpoint store for retries/resume
- later: queue-backed async workflow mode

## Failure handling
- deterministic fallbacks for executive summary
- explicit node failure surfacing
- timeout handling around MCP tool calls
- mode-specific partial failure messaging

## Deployment strategy
- containerized FastAPI service
- Azure Container Apps or AKS
- APIM in front for enterprise ingress
- environment-driven config

## Test strategy
- node unit tests
- graph path tests per mode
- MCP adapter integration tests
- API contract tests
- non-production smoke tests

## Rollout and rollback
- deploy behind versioned route or revision
- validate each mode post-deploy
- rollback by prior image revision if tool or graph error rate rises
