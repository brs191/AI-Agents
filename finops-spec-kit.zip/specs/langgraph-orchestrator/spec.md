# Spec: LangGraph Orchestrator

## Objective
Provide a stateful, production-oriented orchestration runtime that uses MCP tools to execute Azure FinOps workflows automatically.

## Business outcome
Enable reliable multi-agent execution for:
- spend summary
- anomaly investigation
- forecast review
- savings planning
- executive summary generation

## Primary users
- platform services calling the orchestrator API
- VS Code agent workspace
- scheduled FinOps workflows
- engineering and FinOps stakeholders consuming results

## User scenarios
1. As a caller, I want a single API request to execute the full FinOps workflow.
2. As a reviewer, I want findings validated before they are turned into action plans.
3. As leadership, I want executive summaries grounded in cost facts.
4. As engineering, I want structured outputs suitable for downstream automation.

## Functional requirements
1. Expose runtime API endpoint for workflow execution.
2. Support orchestration modes:
   - spend_summary
   - anomaly_investigation
   - forecast_review
   - savings_plan
3. Use Azure Cost MCP tools as the source of truth for cost data.
4. Maintain shared graph state across nodes.
5. Include graph nodes:
   - classify
   - analyst
   - correlation
   - reviewer
   - planner
   - executive_summary
6. Support deterministic fallback summaries if LLM is unavailable.
7. Return structured response combining stage outputs and final summary.

## Non-functional requirements
- request timeout controls
- deterministic routing
- structured typed state
- production logging
- clear stage boundaries
- containerizable service
- compatible with external API gateway

## Security and compliance constraints
- runtime must not bypass MCP to invent cost facts
- runtime must not perform destructive cloud actions
- outbound credentials must be managed securely
- logs must avoid secret leakage

## Success metrics
- end-to-end workflow success for supported modes
- explainable stage outputs
- no ungrounded spend claims
- graceful degradation when LLM summarization is unavailable

## Risks
- stateless MCP sessions may add latency
- heuristic correlation may be mistaken for causation if not framed carefully
- prompt/output drift if structured responses are not enforced

## Out of scope
- autonomous remediation
- write-capable Azure operations
- tenant billing and chargeback engine
