# Tasks: LangGraph Orchestrator

## Phase 1: Core runtime
- [ ] Implement FastAPI service skeleton
- [ ] Implement typed request / response models
- [ ] Implement LangGraph state model
- [ ] Implement classify node
- [ ] Implement analyst node with Azure Cost MCP tools
- [ ] Implement reviewer node
- [ ] Implement planner node
- [ ] Implement executive summary node with deterministic fallback

## Phase 2: Integration and resilience
- [ ] Add MCP adapter integration
- [ ] Add Azure OpenAI optional integration
- [ ] Add per-node timing and structured logs
- [ ] Add request correlation IDs
- [ ] Add timeouts and graceful error handling
- [ ] Containerize service

## Phase 3: Validation
- [ ] Write path tests for each workflow mode
- [ ] Write API contract tests
- [ ] Run integration tests against real Azure Cost MCP server
- [ ] Validate behavior when LLM is unavailable

## Release readiness
- [ ] Confirm mode-by-mode smoke test checklist
- [ ] Confirm monitoring and alerting
- [ ] Document runtime limitations and confidence caveats
- [ ] Review production timeout defaults
