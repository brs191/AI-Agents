# Plan: <capability name>

## Architecture overview
## Components
## Data flow
## Interfaces and contracts
## Security model
## Observability model
## Scaling strategy
## Failure handling
## Deployment strategy
## Test strategy
## Rollout and rollback
