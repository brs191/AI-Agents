# Spec: <capability name>

## Objective
## Business outcome
## Primary users
## User scenarios
## Functional requirements
## Non-functional requirements
## Security and compliance constraints
## Success metrics
## Risks
## Out of scope
