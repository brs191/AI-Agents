from fastapi import FastAPI
from pydantic import BaseModel
import uuid

app = FastAPI()

class RunRequest(BaseModel):
    project_name: str
    goal: str
    prd: str

@app.get("/")
def root():
    return {"status": "ok"}
