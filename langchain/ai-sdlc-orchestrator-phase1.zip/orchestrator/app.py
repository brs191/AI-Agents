from typing import TypedDict, Any
from langgraph.graph import StateGraph, END

class OrchestratorState(TypedDict, total=False):
    request_id: str
    project_name: str
    goal: str
    prd: str
    constraints: list[str]
    artifacts: dict[str, Any]
    approvals: dict[str, bool]
    scores: dict[str, float]
    trace: list[dict[str, Any]]
    next_action: str

def intake_node(state: OrchestratorState) -> OrchestratorState:
    state.setdefault("trace", []).append({"step": "intake"})
    return state

def build_graph():
    graph = StateGraph(OrchestratorState)
    graph.add_node("intake", intake_node)
    graph.set_entry_point("intake")
    graph.add_edge("intake", END)
    return graph.compile()
