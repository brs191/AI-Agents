# LangGraph Azure FinOps Orchestrator

A LangGraph-based orchestrator runtime that uses your **Azure Cloud Cost MCP server**
as the tool layer.

## What this project gives you

- LangGraph workflow with nodes for:
  - classify
  - analyst
  - correlation
  - reviewer
  - planner
  - executive_summary
- MCP tool access through LangChain MCP adapters
- FastAPI runtime with:
  - `GET /healthz`
  - `POST /api/v1/run`
- optional Azure OpenAI model integration
- structured state and typed outputs

## Why this design

- LangGraph is used for **stateful orchestration**
- MCP remains the **source of truth** for cost facts
- Azure OpenAI is optional and used only for reasoning / summarization

## Prerequisites

- Python 3.11+
- your Azure Cloud Cost MCP server available locally
- Azure credentials for the MCP server
- optional Azure OpenAI deployment

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --port 8080
```

## MCP server path

By default, the MCP server is started with:

- command: `go`
- args: `run ./cmd/server`
- workdir: `../azure-cloud-cost-mcp-go`

Override with environment variables in `.env`.

## Example request

```bash
curl -X POST http://localhost:8080/api/v1/run \
  -H "Content-Type: application/json" \
  -d '{
    "mode": "anomaly_investigation",
    "question": "Why did Azure cost increase this month?",
    "baseline_start_date": "2026-02-01",
    "baseline_end_date": "2026-02-29",
    "comparison_start_date": "2026-03-01",
    "comparison_end_date": "2026-03-31",
    "start_date": "2026-03-01",
    "end_date": "2026-03-31",
    "group_by": "ServiceName",
    "repo_hints": ["aks", "network", "cdn", "scale"]
  }'
```

## Notes

- This runtime is read-only.
- Correlation is heuristic unless you connect real repo / deployment sources.
- If Azure OpenAI is not configured, the runtime still works with deterministic summaries.
