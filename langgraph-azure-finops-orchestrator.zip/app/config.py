from __future__ import annotations

import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

@dataclass
class Settings:
    port: int = int(os.getenv("PORT", "8080"))
    log_level: str = os.getenv("LOG_LEVEL", "info")

    azure_openai_endpoint: str = os.getenv("AZURE_OPENAI_ENDPOINT", "")
    azure_openai_deployment: str = os.getenv("AZURE_OPENAI_DEPLOYMENT", "")
    azure_openai_api_version: str = os.getenv("AZURE_OPENAI_API_VERSION", "preview")
    azure_openai_api_key: str = os.getenv("AZURE_OPENAI_API_KEY", "")

    mcp_server_command: str = os.getenv("MCP_SERVER_COMMAND", "go")
    mcp_server_args: list[str] = [x.strip() for x in os.getenv("MCP_SERVER_ARGS", "run,./cmd/server").split(",") if x.strip()]
    mcp_server_workdir: str = os.getenv("MCP_SERVER_WORKDIR", "../azure-cloud-cost-mcp-go")

    azure_cost_scope: str = os.getenv("AZURE_COST_SCOPE", "")
    azure_api_version: str = os.getenv("AZURE_API_VERSION", "2025-03-01")
    query_timeout: str = os.getenv("QUERY_TIMEOUT", "20s")
    default_currency: str = os.getenv("DEFAULT_CURRENCY", "USD")
    azure_tenant_id: str = os.getenv("AZURE_TENANT_ID", "")
    azure_client_id: str = os.getenv("AZURE_CLIENT_ID", "")
    azure_client_secret: str = os.getenv("AZURE_CLIENT_SECRET", "")

settings = Settings()
