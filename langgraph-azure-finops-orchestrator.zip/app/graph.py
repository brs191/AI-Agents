from __future__ import annotations

from typing import Any, TypedDict

from langgraph.graph import StateGraph, END

from app.models import (
    RunRequest,
    AnalystOutput,
    CorrelationOutput,
    ReviewerOutput,
    PlannerOutput,
    ExecutiveSummaryOutput,
    RunResponse,
    BucketAmount,
    Hypothesis,
)
from app.mcp_tools import call_tool
from app.llm import get_llm


class GraphState(TypedDict, total=False):
    request: RunRequest
    classification: str
    analyst: AnalystOutput
    correlation: CorrelationOutput
    reviewer: ReviewerOutput
    planner: PlannerOutput
    executive_summary: ExecutiveSummaryOutput
    final_summary: str


def _default_group_by(v: str | None) -> str:
    return v or "ServiceName"


def _bucket_from_item(item: Any) -> BucketAmount | None:
    if not isinstance(item, dict):
        return None
    return BucketAmount(
        bucket=str(item.get("bucket", "Unknown")),
        amount=float(item.get("amount", 0) or 0),
        currency=str(item.get("currency") or item.get("unit") or "USD"),
    )


async def classify_node(state: GraphState) -> GraphState:
    req = state["request"]
    return {"classification": req.mode}


async def analyst_node(state: GraphState) -> GraphState:
    req = state["request"]
    mode = state["classification"]
    tool_data: dict[str, Any] = {}
    top_buckets: list[BucketAmount] = []
    hypotheses: list[Hypothesis] = []
    evidence: list[str] = []

    if mode == "forecast_review":
        forecast = await call_tool(
            "forecast_cost",
            {
                "start_date": req.start_date,
                "end_date": req.end_date,
                "granularity": "Monthly",
            },
        )
        tool_data["forecast_cost"] = forecast
        amount = float(forecast.get("amount", 0) or 0)
        currency = str(forecast.get("currency", "USD"))
        top_buckets = [BucketAmount(bucket="Forecast", amount=amount, currency=currency)]
        hypotheses = [Hypothesis(text="Forecast should be reviewed against recent workload changes.", confidence="medium")]
        evidence = [f"Forecast for selected period is {amount:.2f} {currency}."]
    elif mode == "savings_plan":
        breakdown = await call_tool(
            "get_cost_breakdown",
            {
                "start_date": req.start_date,
                "end_date": req.end_date,
                "granularity": "None",
                "group_by": _default_group_by(req.group_by),
            },
        )
        savings = await call_tool(
            "recommend_savings",
            {
                "start_date": req.start_date,
                "end_date": req.end_date,
                "group_by": _default_group_by(req.group_by),
            },
        )
        tool_data["get_cost_breakdown"] = breakdown
        tool_data["recommend_savings"] = savings
        for item in breakdown.get("entries", [])[:5]:
            bucket = _bucket_from_item(item)
            if bucket:
                top_buckets.append(bucket)
        if top_buckets:
            evidence.append(f"Top spend bucket is {top_buckets[0].bucket}.")
        hypotheses = [Hypothesis(text="Concentrated spend likely offers the fastest initial savings opportunity.", confidence="medium")]
    else:
        breakdown = await call_tool(
            "get_cost_breakdown",
            {
                "start_date": req.start_date or req.comparison_start_date,
                "end_date": req.end_date or req.comparison_end_date,
                "granularity": "None",
                "group_by": _default_group_by(req.group_by),
            },
        )
        anomalies = await call_tool(
            "detect_cost_anomalies",
            {
                "baseline_start_date": req.baseline_start_date,
                "baseline_end_date": req.baseline_end_date,
                "comparison_start_date": req.comparison_start_date,
                "comparison_end_date": req.comparison_end_date,
                "group_by": _default_group_by(req.group_by),
            },
        )
        tool_data["get_cost_breakdown"] = breakdown
        tool_data["detect_cost_anomalies"] = anomalies
        for item in breakdown.get("entries", [])[:5]:
            bucket = _bucket_from_item(item)
            if bucket:
                top_buckets.append(bucket)
        for item in anomalies.get("top_deltas", [])[:3]:
            if isinstance(item, dict):
                bucket = str(item.get("bucket", "Unknown"))
                abs_delta = float(item.get("absolute_delta", 0) or 0)
                pct = float(item.get("percent_delta", 0) or 0)
                currency = str(item.get("currency", "USD"))
                evidence.append(f"{bucket} changed by {abs_delta:.2f} {currency} ({pct:.1f}%).")
                hypotheses.append(Hypothesis(text=f"{bucket} appears to be a primary driver of the selected cost change.", confidence="medium"))

    if not evidence:
        evidence = ["No strong evidence extracted from tool outputs."]
    if not hypotheses:
        hypotheses = [Hypothesis(text="Further validation is needed.", confidence="low")]

    analyst = AnalystOutput(
        finding_type=mode,
        top_buckets=top_buckets,
        hypotheses=hypotheses,
        evidence=evidence,
        confidence="medium",
        tool_data=tool_data,
    )
    return {"analyst": analyst}


async def correlation_node(state: GraphState) -> GraphState:
    req = state["request"]
    correlations: list[str] = []
    for hint in req.repo_hints:
        h = hint.strip().lower()
        if h in {"aks", "scale", "autoscale"}:
            correlations.append("Scaling-related changes may correlate with higher compute or network costs.")
        elif h in {"cdn", "cache", "caching"}:
            correlations.append("Caching and CDN changes may correlate with data transfer changes.")
        elif h in {"network", "region"}:
            correlations.append("Region or networking changes may correlate with egress or cross-region traffic costs.")
        elif h in {"data", "replication"}:
            correlations.append("Data movement or replication changes may correlate with storage and network spend.")
    if not correlations:
        correlations.append("No repository hints were provided, so infrastructure correlation remains weak.")

    output = CorrelationOutput(
        possible_correlations=correlations,
        evidence_strength="moderate" if len(correlations) >= 2 else "weak",
        notes=["This stage is heuristic unless you integrate actual repo, deployment, or telemetry connectors."],
    )
    return {"correlation": output}


async def reviewer_node(state: GraphState) -> GraphState:
    analyst = state["analyst"]
    corr = state.get("correlation")
    risks: list[str] = []
    validations: list[str] = []
    confidence = analyst.confidence

    if corr and corr.evidence_strength == "weak":
        risks.append("Correlation evidence is weak; causation is not established.")
        validations.append("Check deployment and infrastructure timelines against the anomaly window.")
        confidence = "low"

    if analyst.top_buckets:
        validations.append("Validate the top spend bucket with a second time-slice or alternate grouping.")

    if not risks:
        risks.append("Savings estimates are heuristic and should be validated before action.")

    reviewer = ReviewerOutput(
        verdict="needs_validation",
        top_risks=risks,
        missing_validations=list(dict.fromkeys(validations)),
        confidence_adjustment=confidence,
    )
    return {"reviewer": reviewer}


async def planner_node(state: GraphState) -> GraphState:
    analyst = state["analyst"]
    corr = state.get("correlation")
    reviewer = state.get("reviewer")

    actions: list[str] = []
    if analyst.top_buckets:
        actions.append(f"Inspect the top spend bucket first: {analyst.top_buckets[0].bucket}")
    for hyp in analyst.hypotheses[:2]:
        actions.append(f"Validate hypothesis: {hyp.text}")
    if corr:
        actions.append("Review correlated infrastructure and deployment changes.")
    if reviewer:
        actions.extend(reviewer.missing_validations)

    planner = PlannerOutput(
        actions=list(dict.fromkeys(actions)),
        owner_suggestions=["Platform Engineering", "FinOps"],
        validation_metrics=["Cost by service/day", "Month-over-month delta by grouping", "Deployment timestamps vs cost anomaly window"],
        rollback_criteria=["Revert traffic-routing or caching changes if reliability regresses."],
    )
    return {"planner": planner}


async def executive_summary_node(state: GraphState) -> GraphState:
    analyst = state["analyst"]
    reviewer = state.get("reviewer")
    llm = get_llm()

    fallback = ExecutiveSummaryOutput(
        headline="Azure cost review completed.",
        top_driver=analyst.top_buckets[0].bucket if analyst.top_buckets else "Unknown",
        top_risk=reviewer.top_risks[0] if reviewer and reviewer.top_risks else "Validation is still required.",
        next_action="Review the top spend bucket and validate the likely driver.",
        confidence=reviewer.confidence_adjustment if reviewer else analyst.confidence,
    )

    if llm is None:
        return {"executive_summary": fallback}

    prompt = (
        "Create a concise executive FinOps summary as JSON with keys "
        "headline, top_driver, top_risk, next_action, confidence. "
        f"Analyst: {analyst.model_dump_json()} "
        f"Reviewer: {reviewer.model_dump_json() if reviewer else '{}'}"
    )
    try:
        msg = await llm.ainvoke(prompt)
        import json as _json
        parsed = _json.loads(msg.content)
        summary = ExecutiveSummaryOutput(**parsed)
        return {"executive_summary": summary}
    except Exception:
        return {"executive_summary": fallback}


def route_after_classify(state: GraphState) -> str:
    mode = state["classification"]
    if mode == "spend_summary":
        return "executive_summary"
    return "analyst"


def route_after_analyst(state: GraphState) -> str:
    mode = state["classification"]
    if mode == "spend_summary":
        return "executive_summary"
    if mode == "forecast_review":
        return "reviewer"
    if mode == "savings_plan":
        return "reviewer"
    return "correlation"


def route_after_reviewer(state: GraphState) -> str:
    mode = state["classification"]
    if mode == "forecast_review":
        return "executive_summary"
    return "planner"


async def finalize_node(state: GraphState) -> GraphState:
    analyst = state.get("analyst")
    corr = state.get("correlation")
    reviewer = state.get("reviewer")
    planner = state.get("planner")
    executive = state.get("executive_summary")

    if executive:
        final_summary = f"{executive.headline} Next action: {executive.next_action}"
    else:
        parts = [f"Mode: {state['classification']}."]
        if analyst and analyst.top_buckets:
            parts.append(f"Top bucket: {analyst.top_buckets[0].bucket}.")
        if analyst and analyst.hypotheses:
            parts.append(f"Likely driver: {analyst.hypotheses[0].text}")
        if reviewer and reviewer.top_risks:
            parts.append(f"Top risk: {reviewer.top_risks[0]}")
        if planner and planner.actions:
            parts.append(f"Next action: {planner.actions[0]}")
        final_summary = " ".join(parts)

    return {"final_summary": final_summary}


def build_graph():
    graph = StateGraph(GraphState)

    graph.add_node("classify", classify_node)
    graph.add_node("analyst", analyst_node)
    graph.add_node("correlation", correlation_node)
    graph.add_node("reviewer", reviewer_node)
    graph.add_node("planner", planner_node)
    graph.add_node("executive_summary", executive_summary_node)
    graph.add_node("finalize", finalize_node)

    graph.set_entry_point("classify")
    graph.add_conditional_edges("classify", route_after_classify, {
        "analyst": "analyst",
        "executive_summary": "executive_summary",
    })
    graph.add_conditional_edges("analyst", route_after_analyst, {
        "correlation": "correlation",
        "reviewer": "reviewer",
        "executive_summary": "executive_summary",
    })
    graph.add_edge("correlation", "reviewer")
    graph.add_conditional_edges("reviewer", route_after_reviewer, {
        "planner": "planner",
        "executive_summary": "executive_summary",
    })
    graph.add_edge("planner", "finalize")
    graph.add_edge("executive_summary", "finalize")
    graph.add_edge("finalize", END)

    return graph.compile()


async def run_flow(request: RunRequest) -> RunResponse:
    app = build_graph()
    state = await app.ainvoke({"request": request})
    return RunResponse(
        mode=request.mode,
        classification=state["classification"],
        analyst=state.get("analyst"),
        correlation=state.get("correlation"),
        reviewer=state.get("reviewer"),
        planner=state.get("planner"),
        executive_summary=state.get("executive_summary"),
        final_summary=state["final_summary"],
    )
