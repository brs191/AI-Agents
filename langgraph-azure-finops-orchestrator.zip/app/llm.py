from __future__ import annotations

from langchain_openai import AzureChatOpenAI

from app.config import settings

def get_llm() -> AzureChatOpenAI | None:
    if not (settings.azure_openai_endpoint and settings.azure_openai_deployment and settings.azure_openai_api_key):
        return None
    return AzureChatOpenAI(
        azure_endpoint=settings.azure_openai_endpoint,
        azure_deployment=settings.azure_openai_deployment,
        api_version=settings.azure_openai_api_version,
        api_key=settings.azure_openai_api_key,
        temperature=0,
    )
