from __future__ import annotations

from fastapi import FastAPI, HTTPException

from app.config import settings
from app.graph import run_flow
from app.models import RunRequest, RunResponse

app = FastAPI(title="LangGraph Azure FinOps Orchestrator", version="0.1.0")

@app.get("/healthz")
async def healthz() -> dict:
    return {"ok": True, "port": settings.port}

@app.post("/api/v1/run", response_model=RunResponse)
async def run(req: RunRequest) -> RunResponse:
    try:
        return await run_flow(req)
    except Exception as e:
        raise HTTPException(status_code=502, detail=str(e)) from e
