from __future__ import annotations

import os
from contextlib import asynccontextmanager
from typing import Any

from langchain_mcp_adapters.client import MultiServerMCPClient

from app.config import settings

def _server_env() -> dict[str, str]:
    return {
        "AZURE_COST_SCOPE": settings.azure_cost_scope,
        "AZURE_API_VERSION": settings.azure_api_version,
        "QUERY_TIMEOUT": settings.query_timeout,
        "DEFAULT_CURRENCY": settings.default_currency,
        "AZURE_TENANT_ID": settings.azure_tenant_id,
        "AZURE_CLIENT_ID": settings.azure_client_id,
        "AZURE_CLIENT_SECRET": settings.azure_client_secret,
    }

@asynccontextmanager
async def mcp_client():
    client = MultiServerMCPClient(
        {
            "azure-cloud-cost-intelligence": {
                "command": settings.mcp_server_command,
                "args": settings.mcp_server_args,
                "transport": "stdio",
                "cwd": settings.mcp_server_workdir,
                "env": {**os.environ, **_server_env()},
            }
        }
    )
    try:
        yield client
    finally:
        close_method = getattr(client, "aclose", None)
        if callable(close_method):
            await close_method()

async def call_tool(tool_name: str, arguments: dict[str, Any]) -> Any:
    async with mcp_client() as client:
        tools = await client.get_tools()
        selected = None
        for tool in tools:
            if getattr(tool, "name", "") == tool_name:
                selected = tool
                break
        if selected is None:
            raise ValueError(f"Tool not found: {tool_name}")
        return await selected.ainvoke(arguments)
