from __future__ import annotations

from typing import Any, Literal
from pydantic import BaseModel, Field

Mode = Literal["spend_summary", "anomaly_investigation", "forecast_review", "savings_plan"]

class RunRequest(BaseModel):
    mode: Mode = "anomaly_investigation"
    question: str
    start_date: str | None = None
    end_date: str | None = None
    baseline_start_date: str | None = None
    baseline_end_date: str | None = None
    comparison_start_date: str | None = None
    comparison_end_date: str | None = None
    group_by: str | None = None
    repo_hints: list[str] = Field(default_factory=list)

class BucketAmount(BaseModel):
    bucket: str
    amount: float
    currency: str

class Hypothesis(BaseModel):
    text: str
    confidence: Literal["low", "medium", "high"]

class AnalystOutput(BaseModel):
    finding_type: str
    top_buckets: list[BucketAmount] = Field(default_factory=list)
    hypotheses: list[Hypothesis] = Field(default_factory=list)
    evidence: list[str] = Field(default_factory=list)
    confidence: Literal["low", "medium", "high"] = "medium"
    tool_data: dict[str, Any] = Field(default_factory=dict)

class CorrelationOutput(BaseModel):
    possible_correlations: list[str] = Field(default_factory=list)
    evidence_strength: Literal["weak", "moderate", "strong"] = "weak"
    notes: list[str] = Field(default_factory=list)

class ReviewerOutput(BaseModel):
    verdict: str
    top_risks: list[str] = Field(default_factory=list)
    missing_validations: list[str] = Field(default_factory=list)
    confidence_adjustment: Literal["low", "medium", "high"] = "medium"

class PlannerOutput(BaseModel):
    actions: list[str] = Field(default_factory=list)
    owner_suggestions: list[str] = Field(default_factory=list)
    validation_metrics: list[str] = Field(default_factory=list)
    rollback_criteria: list[str] = Field(default_factory=list)

class ExecutiveSummaryOutput(BaseModel):
    headline: str
    top_driver: str
    top_risk: str
    next_action: str
    confidence: Literal["low", "medium", "high"]

class RunResponse(BaseModel):
    mode: str
    classification: str
    analyst: AnalystOutput | None = None
    correlation: CorrelationOutput | None = None
    reviewer: ReviewerOutput | None = None
    planner: PlannerOutput | None = None
    executive_summary: ExecutiveSummaryOutput | None = None
    final_summary: str
