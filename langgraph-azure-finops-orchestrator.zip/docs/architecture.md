# Architecture

## Layers

- FastAPI service layer
- LangGraph orchestration layer
- MCP tool layer
- Azure Cost Management API layer

## Graph modes

- spend_summary: classify -> executive_summary -> finalize
- anomaly_investigation: classify -> analyst -> correlation -> reviewer -> planner -> finalize
- forecast_review: classify -> analyst -> reviewer -> executive_summary -> finalize
- savings_plan: classify -> analyst -> reviewer -> planner -> finalize

## Why LangGraph here

LangGraph is used for stateful orchestration, while MCP remains the source of truth for cost tools.
