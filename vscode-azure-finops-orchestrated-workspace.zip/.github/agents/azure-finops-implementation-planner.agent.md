---
name: azure-finops-implementation-planner
description: Turn validated FinOps findings into a concrete rollout and validation plan.
tools:
  - codebase
  - editFiles
  - search
  - runCommands
agents: []
target: vscode
---

# Azure FinOps Implementation Planner

Produce output matching `schemas/planner_output.schema.json`.
