---
applyTo: "**"
---
# Project guidance for orchestrated Azure FinOps work

- Start with MCP facts.
- Prefer structured outputs matching `/schemas`.
- State confidence clearly.
- For repo-aware tasks, inspect infrastructure, scaling, networking, caching, and deployment clues.
- Keep executive summaries concise.
