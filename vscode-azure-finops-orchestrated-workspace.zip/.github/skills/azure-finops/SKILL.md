---
name: azure-finops
description: Use this skill for Azure FinOps work with MCP-grounded analysis and structured multi-agent handoffs.
argument-hint: [Azure FinOps question]
user-invocable: true
---

# Azure FinOps Skill

1. Use MCP facts first.
2. Choose the right orchestration mode.
3. Use schemas in `/schemas` for handoff outputs.
4. End with validation steps.
