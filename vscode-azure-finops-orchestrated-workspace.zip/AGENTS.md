# Workspace AI Agent Rules

1. Use MCP tools before making cost claims.
2. Keep facts, inferences, and recommendations separate.
3. Use structured handoffs matching `/schemas`.
4. Include confidence and validation steps.
5. Do not treat correlation as proof unless evidence is strong.
