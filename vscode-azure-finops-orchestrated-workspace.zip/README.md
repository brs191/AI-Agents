# Orchestrated Azure FinOps Agent Workspace for VS Code

This workspace gives you an orchestrated multi-agent Azure FinOps setup for VS Code.

Included:
- `.vscode/mcp.json` for your Azure Cloud Cost MCP server
- orchestrator + specialist agents
- structured handoff schemas
- skills, prompts, and docs
- helper scripts

Default MCP server path:
`../azure-cloud-cost-mcp-go`

Override with:
```bash
export MCP_SERVER_DIR=/path/to/azure-cloud-cost-mcp-go
```

Quick start:
1. Open in VS Code.
2. Enable agent mode.
3. Run:
```bash
chmod +x ./scripts/*.sh
./scripts/check-server.sh
```
4. Choose `finops-orchestrator` in chat.
