# Orchestration Flow

Spend summary:
Orchestrator -> Analyst -> Executive Summary

Anomaly investigation:
Orchestrator -> Analyst -> Correlation -> Reviewer -> Planner

Forecast review:
Orchestrator -> Analyst -> Reviewer -> Executive Summary

Savings plan:
Orchestrator -> Analyst -> Reviewer -> Planner
