# Anomaly Investigation Prompt

Use the orchestrated flow:
- classify the request
- gather MCP facts
- inspect repo correlations
- review the diagnosis
- produce a validated implementation plan
