# Executive Summary Prompt

Use MCP-grounded findings and produce:
- one headline
- one top spend driver
- one top risk
- one recommended next action
- confidence level
