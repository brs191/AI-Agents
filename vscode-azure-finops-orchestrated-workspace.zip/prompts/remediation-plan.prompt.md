# Remediation Plan Prompt

Build a safe implementation plan from validated FinOps findings:
- action sequence
- owner suggestions
- validation metrics
- rollback criteria
