# VS Code FinOps Workspace – Spec Pack

This Spec Kit pack defines the **VS Code FinOps Workspace** that connects developers and FinOps users
to the LangGraph orchestrator and Azure Cost MCP server.

It follows the Spec → Plan → Tasks model for spec-driven delivery.

## Scope
- VS Code agent workspace
- MCP integration (.vscode/mcp.json)
- Prompt/skills library
- Secure configuration
- Developer UX for FinOps workflows

## Outcomes
- One-click FinOps workflows from VS Code
- Grounded answers using MCP tools
- Consistent prompts and structured outputs
- Enterprise-safe configuration
