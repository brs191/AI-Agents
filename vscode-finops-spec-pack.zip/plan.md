# Plan: VS Code FinOps Workspace

## Architecture overview
VS Code workspace acting as a thin client:
- interacts with LangGraph orchestrator via API
- uses MCP configuration for tool discovery
- leverages prompt templates for consistent workflows

## Components
- VS Code workspace folder
- `.vscode/mcp.json`
- prompt templates
- skills definitions
- environment configuration
- API integration layer

## Data flow
1. User enters prompt in VS Code.
2. Prompt template formats request.
3. Request sent to orchestrator API.
4. Orchestrator executes LangGraph workflow.
5. MCP tools fetch cost data.
6. Response returned to VS Code.
7. Output rendered to user.

## Interfaces and contracts
### Input
- natural language query
- optional structured parameters

### Output
- structured JSON response
- human-readable summary

## Security model
- no secrets in repo
- use environment variables or secure injection
- rely on backend services for authentication
- VS Code acts as a client only

## Observability model
- request logging at orchestrator
- client-side minimal logging
- correlation IDs passed through requests

## Scaling strategy
- VS Code is stateless client
- scaling handled by backend services

## Failure handling
- graceful error display in VS Code
- fallback messages for MCP or API failures

## Deployment strategy
- distributed as repo template
- used locally or via dev containers
- versioned updates

## Test strategy
- prompt template validation
- API contract tests
- user workflow testing

## Rollout and rollback
- version-controlled workspace
- rollback by reverting workspace version
