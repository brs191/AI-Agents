# Spec: VS Code FinOps Workspace

## Objective
Provide a VS Code-native workspace that enables engineers and FinOps users to run
AI-powered FinOps workflows using MCP-backed tools and orchestrated agents.

## Business outcome
- Reduce time to analyze cloud spend (hours → minutes)
- Enable self-service FinOps insights for engineering teams
- Standardize cost analysis workflows across teams
- Improve developer productivity with AI-assisted cost intelligence

## Primary users
- Software engineers
- Platform engineers
- FinOps analysts
- Engineering managers

## User scenarios
1. As an engineer, I want to ask "why did cost increase?" directly in VS Code and get a grounded answer.
2. As a FinOps analyst, I want consistent outputs for anomaly investigation.
3. As a manager, I want executive summaries generated from real data.
4. As a platform engineer, I want secure integration without exposing secrets.

## Functional requirements
- Provide VS Code workspace with:
  - MCP configuration (`.vscode/mcp.json`)
  - agent prompt templates
  - skill definitions
- Support workflows:
  - spend summary
  - anomaly investigation
  - forecast review
  - savings plan
- Integrate with LangGraph orchestrator API
- Use Azure Cost MCP server as tool layer
- Provide reusable prompt templates for each workflow
- Support structured JSON outputs

## Non-functional requirements
- fast response times
- deterministic prompt templates
- minimal configuration for users
- secure handling of credentials
- extensible for new MCP servers

## Security and compliance constraints
- no secrets stored in workspace files
- use environment variables or Key Vault-backed injection
- enforce least privilege for MCP server access
- prevent direct destructive actions from prompts

## Success metrics
- users can execute workflows without manual setup
- responses are grounded in MCP tool outputs
- reduction in manual cost analysis effort
- adoption across engineering teams

## Risks
- misuse of prompts leading to incorrect interpretation
- reliance on MCP server availability
- inconsistent developer environments

## Out of scope
- direct cloud resource modification
- full FinOps dashboard UI
