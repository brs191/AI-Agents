# Tasks: VS Code FinOps Workspace

## Phase 1: Workspace setup
- [ ] Create VS Code workspace structure
- [ ] Add `.vscode/mcp.json`
- [ ] Add environment configuration template
- [ ] Add README and usage guide

## Phase 2: Prompt and skills
- [ ] Create prompt templates for:
  - spend summary
  - anomaly investigation
  - forecast review
  - savings plan
- [ ] Define skills structure
- [ ] Add structured output formats

## Phase 3: Integration
- [ ] Integrate with LangGraph orchestrator API
- [ ] Validate MCP tool connectivity
- [ ] Add correlation ID support
- [ ] Add error handling and fallback responses

## Phase 4: Validation
- [ ] Test workflows end-to-end
- [ ] Validate structured outputs
- [ ] Test failure scenarios
- [ ] Validate security constraints

## Release readiness
- [ ] Documentation complete
- [ ] Example prompts included
- [ ] Environment setup instructions verified
- [ ] Version tagging for release
